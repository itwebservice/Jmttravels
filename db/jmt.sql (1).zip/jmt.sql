-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 07, 2023 at 02:22 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jmt`
--

-- --------------------------------------------------------

--
-- Table structure for table `site_seeing_vendor`
--

CREATE TABLE `site_seeing_vendor` (
  `vendor_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `mobile_no` text NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `email_id` text NOT NULL,
  `alternative_email_1` text NOT NULL,
  `alternative_email_2` text NOT NULL,
  `concern_person_name` varchar(300) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `address` text NOT NULL,
  `website` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `state_id` int(11) NOT NULL,
  `side` varchar(6) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `site_seeing_vendor`
--

INSERT INTO `site_seeing_vendor` (`vendor_id`, `city_id`, `vendor_name`, `mobile_no`, `landline_no`, `email_id`, `alternative_email_1`, `alternative_email_2`, `concern_person_name`, `immergency_contact_no`, `opening_balance`, `address`, `website`, `active_flag`, `bank_name`, `account_name`, `account_no`, `branch`, `ifsc_code`, `service_tax_no`, `created_at`, `state_id`, `side`, `pan_no`, `as_of_date`) VALUES
(1, 293, 'Lark Holidays', '+nLvKkvdP4jqlQ==', '', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '', '', '0.00', '', '', 'Active', '', '', '', '', '', '', '2023-02-13 19:04:00', 32, 'Credit', '', '2023-02-13');

-- --------------------------------------------------------

--
-- Table structure for table `sms_email_id`
--

CREATE TABLE `sms_email_id` (
  `email_id_id` int(11) NOT NULL,
  `email_id` varchar(150) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sms_group_entries`
--

CREATE TABLE `sms_group_entries` (
  `id` int(11) NOT NULL,
  `sms_group_id` int(11) NOT NULL,
  `mobile_no_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sms_group_master`
--

CREATE TABLE `sms_group_master` (
  `sms_group_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `sms_group_name` varchar(200) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sms_message_master`
--

CREATE TABLE `sms_message_master` (
  `sms_message_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sms_mobile_no`
--

CREATE TABLE `sms_mobile_no` (
  `mobile_no_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `mobile_no` varchar(200) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sms_sending_log`
--

CREATE TABLE `sms_sending_log` (
  `log_id` int(11) NOT NULL,
  `sms_message_id` int(11) NOT NULL,
  `sms_group_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `state_and_cities`
--

CREATE TABLE `state_and_cities` (
  `id` int(11) NOT NULL,
  `city_name` varchar(23) DEFAULT NULL,
  `city_state` varchar(27) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `state_and_cities`
--

INSERT INTO `state_and_cities` (`id`, `city_name`, `city_state`) VALUES
(1, 'North and Middle Andama', 'Andaman and Nicobar'),
(2, 'South Andaman', 'Andaman and Nicobar'),
(3, 'Nicobar', 'Andaman and Nicobar'),
(4, 'Adilabad', 'Andhra Pradesh'),
(5, 'Anantapur', 'Andhra Pradesh'),
(6, 'Chittoor', 'Andhra Pradesh'),
(7, 'East Godavari', 'Andhra Pradesh'),
(8, 'Guntur', 'Andhra Pradesh'),
(9, 'Hyderabad', 'Andhra Pradesh'),
(10, 'Kadapa', 'Andhra Pradesh'),
(11, 'Karimnagar', 'Andhra Pradesh'),
(12, 'Khammam', 'Andhra Pradesh'),
(13, 'Krishna', 'Andhra Pradesh'),
(14, 'Kurnool', 'Andhra Pradesh'),
(15, 'Mahbubnagar', 'Andhra Pradesh'),
(16, 'Medak', 'Andhra Pradesh'),
(17, 'Nalgonda', 'Andhra Pradesh'),
(18, 'Nellore', 'Andhra Pradesh'),
(19, 'Nizamabad', 'Andhra Pradesh'),
(20, 'Prakasam', 'Andhra Pradesh'),
(21, 'Rangareddi', 'Andhra Pradesh'),
(22, 'Srikakulam', 'Andhra Pradesh'),
(23, 'Vishakhapatnam', 'Andhra Pradesh'),
(24, 'Vizianagaram', 'Andhra Pradesh'),
(25, 'Warangal', 'Andhra Pradesh'),
(26, 'West Godavari', 'Andhra Pradesh'),
(27, 'Anjaw', 'Arunachal Pradesh'),
(28, 'Changlang', 'Arunachal Pradesh'),
(29, 'East Kameng', 'Arunachal Pradesh'),
(30, 'Lohit', 'Arunachal Pradesh'),
(31, 'Lower Subansiri', 'Arunachal Pradesh'),
(32, 'Papum Pare', 'Arunachal Pradesh'),
(33, 'Tirap', 'Arunachal Pradesh'),
(34, 'Dibang Valley', 'Arunachal Pradesh'),
(35, 'Upper Subansiri', 'Arunachal Pradesh'),
(36, 'West Kameng', 'Arunachal Pradesh'),
(37, 'Barpeta', 'Assam'),
(38, 'Bongaigaon', 'Assam'),
(39, 'Cachar', 'Assam'),
(40, 'Darrang', 'Assam'),
(41, 'Dhemaji', 'Assam'),
(42, 'Dhubri', 'Assam'),
(43, 'Dibrugarh', 'Assam'),
(44, 'Goalpara', 'Assam'),
(45, 'Golaghat', 'Assam'),
(46, 'Hailakandi', 'Assam'),
(47, 'Jorhat', 'Assam'),
(48, 'Karbi Anglong', 'Assam'),
(49, 'Karimganj', 'Assam'),
(50, 'Kokrajhar', 'Assam'),
(51, 'Lakhimpur', 'Assam'),
(52, 'Marigaon', 'Assam'),
(53, 'Nagaon', 'Assam'),
(54, 'Nalbari', 'Assam'),
(55, 'North Cachar Hills', 'Assam'),
(56, 'Sibsagar', 'Assam'),
(57, 'Sonitpur', 'Assam'),
(58, 'Tinsukia', 'Assam'),
(59, NULL, 'Bihar'),
(60, 'Araria', 'Bihar'),
(61, 'Aurangabad', 'Bihar'),
(62, 'Banka', 'Bihar'),
(63, 'Begusarai', 'Bihar'),
(64, 'Bhagalpur', 'Bihar'),
(65, 'Bhojpur', 'Bihar'),
(66, 'Buxar', 'Bihar'),
(67, 'Darbhanga', 'Bihar'),
(68, 'Purba Champaran', 'Bihar'),
(69, 'Gaya', 'Bihar'),
(70, 'Gopalganj', 'Bihar'),
(71, 'Jamui', 'Bihar'),
(72, 'Jehanabad', 'Bihar'),
(73, 'Khagaria', 'Bihar'),
(74, 'Kishanganj', 'Bihar'),
(75, 'Kaimur', 'Bihar'),
(76, 'Katihar', 'Bihar'),
(77, 'Lakhisarai', 'Bihar'),
(78, 'Madhubani', 'Bihar'),
(79, 'Munger', 'Bihar'),
(80, 'Madhepura', 'Bihar'),
(81, 'Muzaffarpur', 'Bihar'),
(82, 'Nalanda', 'Bihar'),
(83, 'Nawada', 'Bihar'),
(84, 'Patna', 'Bihar'),
(85, 'Purnia', 'Bihar'),
(86, 'Rohtas', 'Bihar'),
(87, 'Saharsa', 'Bihar'),
(88, 'Samastipur', 'Bihar'),
(89, 'Sheohar', 'Bihar'),
(90, 'Sheikhpura', 'Bihar'),
(91, 'Saran', 'Bihar'),
(92, 'Sitamarhi', 'Bihar'),
(93, 'Supaul', 'Bihar'),
(94, 'Siwan', 'Bihar'),
(95, 'Vaishali', 'Bihar'),
(96, 'Pashchim Champaran', 'Bihar'),
(97, 'Bastar', 'Chhattisgarh'),
(98, 'Bilaspur', 'Chhattisgarh'),
(99, 'Dantewada', 'Chhattisgarh'),
(100, 'Dhamtari', 'Chhattisgarh'),
(101, 'Durg', 'Chhattisgarh'),
(102, 'Jashpur', 'Chhattisgarh'),
(103, 'Janjgir-Champa', 'Chhattisgarh'),
(104, 'Korba', 'Chhattisgarh'),
(105, 'Koriya', 'Chhattisgarh'),
(106, 'Kanker', 'Chhattisgarh'),
(107, 'Kawardha', 'Chhattisgarh'),
(108, 'Mahasamund', 'Chhattisgarh'),
(109, 'Raigarh', 'Chhattisgarh'),
(110, 'Rajnandgaon', 'Chhattisgarh'),
(111, 'Raipur', 'Chhattisgarh'),
(112, 'Surguja', 'Chhattisgarh'),
(113, 'Diu', 'Daman and Diu'),
(114, 'Daman', 'Daman and Diu'),
(115, 'Central Delhi', 'Delhi'),
(116, 'East Delhi', 'Delhi'),
(117, 'New Delhi', 'Delhi'),
(118, 'North Delhi', 'Delhi'),
(119, 'North East Delhi', 'Delhi'),
(120, 'North West Delhi', 'Delhi'),
(121, 'South Delhi', 'Delhi'),
(122, 'South West Delhi', 'Delhi'),
(123, 'West Delhi', 'Delhi'),
(124, 'North Goa', 'Goa'),
(125, 'South Goa', 'Goa'),
(126, 'Ahmedabad', 'Gujarat'),
(127, 'Amreli District', 'Gujarat'),
(128, 'Anand', 'Gujarat'),
(129, 'Banaskantha', 'Gujarat'),
(130, 'Bharuch', 'Gujarat'),
(131, 'Bhavnagar', 'Gujarat'),
(132, 'Dahod', 'Gujarat'),
(133, 'The Dangs', 'Gujarat'),
(134, 'Gandhinagar', 'Gujarat'),
(135, 'Jamnagar', 'Gujarat'),
(136, 'Junagadh', 'Gujarat'),
(137, 'Kutch', 'Gujarat'),
(138, 'Kheda', 'Gujarat'),
(139, 'Mehsana', 'Gujarat'),
(140, 'Narmada', 'Gujarat'),
(141, 'Navsari', 'Gujarat'),
(142, 'Patan', 'Gujarat'),
(143, 'Panchmahal', 'Gujarat'),
(144, 'Porbandar', 'Gujarat'),
(145, 'Rajkot', 'Gujarat'),
(146, 'Sabarkantha', 'Gujarat'),
(147, 'Surendranagar', 'Gujarat'),
(148, 'Surat', 'Gujarat'),
(149, 'Vadodara', 'Gujarat'),
(150, 'Valsad', 'Gujarat'),
(151, NULL, 'Haryana'),
(152, 'Ambala', 'Haryana'),
(153, 'Bhiwani', 'Haryana'),
(154, 'Faridabad', 'Haryana'),
(155, 'Fatehabad', 'Haryana'),
(156, 'Gurgaon', 'Haryana'),
(157, 'Hissar', 'Haryana'),
(158, 'Jhajjar', 'Haryana'),
(159, 'Jind', 'Haryana'),
(160, 'Karnal', 'Haryana'),
(161, 'Kaithal', 'Haryana'),
(162, 'Kurukshetra', 'Haryana'),
(163, 'Mahendragarh', 'Haryana'),
(164, 'Mewat', 'Haryana'),
(165, 'Panchkula', 'Haryana'),
(166, 'Panipat', 'Haryana'),
(167, 'Rewari', 'Haryana'),
(168, 'Rohtak', 'Haryana'),
(169, 'Sirsa', 'Haryana'),
(170, 'Sonepat', 'Haryana'),
(171, 'Yamuna Nagar', 'Haryana'),
(172, 'Palwal', 'Haryana'),
(173, 'Bilaspur', 'Himachal Pradesh'),
(174, 'Chamba', 'Himachal Pradesh'),
(175, 'Hamirpur', 'Himachal Pradesh'),
(176, 'Kangra', 'Himachal Pradesh'),
(177, 'Kinnaur', 'Himachal Pradesh'),
(178, 'Kulu', 'Himachal Pradesh'),
(179, 'Lahaul and Spiti', 'Himachal Pradesh'),
(180, 'Mandi', 'Himachal Pradesh'),
(181, 'Shimla', 'Himachal Pradesh'),
(182, 'Sirmaur', 'Himachal Pradesh'),
(183, 'Solan', 'Himachal Pradesh'),
(184, 'Una', 'Himachal Pradesh'),
(185, 'Anantnag', 'Jammu and Kashmir'),
(186, 'Badgam', 'Jammu and Kashmir'),
(187, 'Bandipore', 'Jammu and Kashmir'),
(188, 'Baramula', 'Jammu and Kashmir'),
(189, 'Doda', 'Jammu and Kashmir'),
(190, 'Jammu', 'Jammu and Kashmir'),
(191, 'Kargil', 'Jammu and Kashmir'),
(192, 'Kathua', 'Jammu and Kashmir'),
(193, 'Kupwara', 'Jammu and Kashmir'),
(194, 'Leh', 'Jammu and Kashmir'),
(195, 'Poonch', 'Jammu and Kashmir'),
(196, 'Pulwama', 'Jammu and Kashmir'),
(197, 'Rajauri', 'Jammu and Kashmir'),
(198, 'Srinagar', 'Jammu and Kashmir'),
(199, 'Samba', 'Jammu and Kashmir'),
(200, 'Udhampur', 'Jammu and Kashmir'),
(201, 'Bokaro', 'Jharkhand'),
(202, 'Chatra', 'Jharkhand'),
(203, 'Deoghar', 'Jharkhand'),
(204, 'Dhanbad', 'Jharkhand'),
(205, 'Dumka', 'Jharkhand'),
(206, 'Purba Singhbhum', 'Jharkhand'),
(207, 'Garhwa', 'Jharkhand'),
(208, 'Giridih', 'Jharkhand'),
(209, 'Godda', 'Jharkhand'),
(210, 'Gumla', 'Jharkhand'),
(211, 'Hazaribagh', 'Jharkhand'),
(212, 'Koderma', 'Jharkhand'),
(213, 'Lohardaga', 'Jharkhand'),
(214, 'Pakur', 'Jharkhand'),
(215, 'Palamu', 'Jharkhand'),
(216, 'Ranchi', 'Jharkhand'),
(217, 'Sahibganj', 'Jharkhand'),
(218, 'Seraikela and Kharsawan', 'Jharkhand'),
(219, 'Pashchim Singhbhum', 'Jharkhand'),
(220, 'Ramgarh', 'Jharkhand'),
(221, 'Bidar', 'Karnataka'),
(222, 'Belgaum', 'Karnataka'),
(223, 'Bijapur', 'Karnataka'),
(224, 'Bagalkot', 'Karnataka'),
(225, 'Bellary', 'Karnataka'),
(226, 'Bangalore Rural Distric', 'Karnataka'),
(227, 'Bangalore Urban Distric', 'Karnataka'),
(228, 'Chamarajnagar', 'Karnataka'),
(229, 'Chikmagalur', 'Karnataka'),
(230, 'Chitradurga', 'Karnataka'),
(231, 'Davanagere', 'Karnataka'),
(232, 'Dharwad', 'Karnataka'),
(233, 'Dakshina Kannada', 'Karnataka'),
(234, 'Gadag', 'Karnataka'),
(235, 'Gulbarga', 'Karnataka'),
(236, 'Hassan', 'Karnataka'),
(237, 'Haveri District', 'Karnataka'),
(238, 'Kodagu', 'Karnataka'),
(239, 'Kolar', 'Karnataka'),
(240, 'Koppal', 'Karnataka'),
(241, 'Mandya', 'Karnataka'),
(242, 'Mysore', 'Karnataka'),
(243, 'Raichur', 'Karnataka'),
(244, 'Shimoga', 'Karnataka'),
(245, 'Tumkur', 'Karnataka'),
(246, 'Udupi', 'Karnataka'),
(247, 'Uttara Kannada', 'Karnataka'),
(248, 'Ramanagara', 'Karnataka'),
(249, 'Chikballapur', 'Karnataka'),
(250, 'Yadagiri', 'Karnataka'),
(251, 'Alappuzha', 'Kerala'),
(252, 'Ernakulam', 'Kerala'),
(253, 'Idukki', 'Kerala'),
(254, 'Kollam', 'Kerala'),
(255, 'Kannur', 'Kerala'),
(256, 'Kasaragod', 'Kerala'),
(257, 'Kottayam', 'Kerala'),
(258, 'Kozhikode', 'Kerala'),
(259, 'Malappuram', 'Kerala'),
(260, 'Palakkad', 'Kerala'),
(261, 'Pathanamthitta', 'Kerala'),
(262, 'Thrissur', 'Kerala'),
(263, 'Thiruvananthapuram', 'Kerala'),
(264, 'Wayanad', 'Kerala'),
(265, 'Alirajpur', 'Madhya Pradesh'),
(266, 'Anuppur', 'Madhya Pradesh'),
(267, 'Ashok Nagar', 'Madhya Pradesh'),
(268, 'Balaghat', 'Madhya Pradesh'),
(269, 'Barwani', 'Madhya Pradesh'),
(270, 'Betul', 'Madhya Pradesh'),
(271, 'Bhind', 'Madhya Pradesh'),
(272, 'Bhopal', 'Madhya Pradesh'),
(273, 'Burhanpur', 'Madhya Pradesh'),
(274, 'Chhatarpur', 'Madhya Pradesh'),
(275, 'Chhindwara', 'Madhya Pradesh'),
(276, 'Damoh', 'Madhya Pradesh'),
(277, 'Datia', 'Madhya Pradesh'),
(278, 'Dewas', 'Madhya Pradesh'),
(279, 'Dhar', 'Madhya Pradesh'),
(280, 'Dindori', 'Madhya Pradesh'),
(281, 'Guna', 'Madhya Pradesh'),
(282, 'Gwalior', 'Madhya Pradesh'),
(283, 'Harda', 'Madhya Pradesh'),
(284, 'Hoshangabad', 'Madhya Pradesh'),
(285, 'Indore', 'Madhya Pradesh'),
(286, 'Jabalpur', 'Madhya Pradesh'),
(287, 'Jhabua', 'Madhya Pradesh'),
(288, 'Katni', 'Madhya Pradesh'),
(289, 'Khandwa', 'Madhya Pradesh'),
(290, 'Khargone', 'Madhya Pradesh'),
(291, 'Mandla', 'Madhya Pradesh'),
(292, 'Mandsaur', 'Madhya Pradesh'),
(293, 'Morena', 'Madhya Pradesh'),
(294, 'Narsinghpur', 'Madhya Pradesh'),
(295, 'Neemuch', 'Madhya Pradesh'),
(296, 'Panna', 'Madhya Pradesh'),
(297, 'Rewa', 'Madhya Pradesh'),
(298, 'Rajgarh', 'Madhya Pradesh'),
(299, 'Ratlam', 'Madhya Pradesh'),
(300, 'Raisen', 'Madhya Pradesh'),
(301, 'Sagar', 'Madhya Pradesh'),
(302, 'Satna', 'Madhya Pradesh'),
(303, 'Sehore', 'Madhya Pradesh'),
(304, 'Seoni', 'Madhya Pradesh'),
(305, 'Shahdol', 'Madhya Pradesh'),
(306, 'Shajapur', 'Madhya Pradesh'),
(307, 'Sheopur', 'Madhya Pradesh'),
(308, 'Shivpuri', 'Madhya Pradesh'),
(309, 'Sidhi', 'Madhya Pradesh'),
(310, 'Singrauli', 'Madhya Pradesh'),
(311, 'Tikamgarh', 'Madhya Pradesh'),
(312, 'Ujjain', 'Madhya Pradesh'),
(313, 'Umaria', 'Madhya Pradesh'),
(314, 'Vidisha', 'Madhya Pradesh'),
(315, 'Ahmednagar', 'Maharashtra'),
(316, 'Akola', 'Maharashtra'),
(317, 'Amrawati', 'Maharashtra'),
(318, 'Aurangabad', 'Maharashtra'),
(319, 'Bhandara', 'Maharashtra'),
(320, 'Beed', 'Maharashtra'),
(321, 'Buldhana', 'Maharashtra'),
(322, 'Chandrapur', 'Maharashtra'),
(323, 'Dhule', 'Maharashtra'),
(324, 'Gadchiroli', 'Maharashtra'),
(325, 'Gondiya', 'Maharashtra'),
(326, 'Hingoli', 'Maharashtra'),
(327, 'Jalgaon', 'Maharashtra'),
(328, 'Jalna', 'Maharashtra'),
(329, 'Kolhapur', 'Maharashtra'),
(330, 'Latur', 'Maharashtra'),
(331, 'Mumbai City', 'Maharashtra'),
(332, 'Mumbai suburban', 'Maharashtra'),
(333, 'Nandurbar', 'Maharashtra'),
(334, 'Nanded', 'Maharashtra'),
(335, 'Nagpur', 'Maharashtra'),
(336, 'Nashik', 'Maharashtra'),
(337, 'Osmanabad', 'Maharashtra'),
(338, 'Parbhani', 'Maharashtra'),
(339, 'Pune', 'Maharashtra'),
(340, 'Raigad', 'Maharashtra'),
(341, 'Ratnagiri', 'Maharashtra'),
(342, 'Sindhudurg', 'Maharashtra'),
(343, 'Sangli', 'Maharashtra'),
(344, 'Solapur', 'Maharashtra'),
(345, 'Satara', 'Maharashtra'),
(346, 'Thane', 'Maharashtra'),
(347, 'Wardha', 'Maharashtra'),
(348, 'Washim', 'Maharashtra'),
(349, 'Yavatmal', 'Maharashtra'),
(350, 'Bishnupur', 'Manipur'),
(351, 'Churachandpur', 'Manipur'),
(352, 'Chandel', 'Manipur'),
(353, 'Imphal East', 'Manipur'),
(354, 'Senapati', 'Manipur'),
(355, 'Tamenglong', 'Manipur'),
(356, 'Thoubal', 'Manipur'),
(357, 'Ukhrul', 'Manipur'),
(358, 'Imphal West', 'Manipur'),
(359, 'East Garo Hills', 'Meghalaya'),
(360, 'East Khasi Hills', 'Meghalaya'),
(361, 'Jaintia Hills', 'Meghalaya'),
(362, 'Ri-Bhoi', 'Meghalaya'),
(363, 'South Garo Hills', 'Meghalaya'),
(364, 'West Garo Hills', 'Meghalaya'),
(365, 'West Khasi Hills', 'Meghalaya'),
(366, 'Aizawl', 'Mizoram'),
(367, 'Champhai', 'Mizoram'),
(368, 'Kolasib', 'Mizoram'),
(369, 'Lawngtlai', 'Mizoram'),
(370, 'Lunglei', 'Mizoram'),
(371, 'Mamit', 'Mizoram'),
(372, 'Saiha', 'Mizoram'),
(373, 'Serchhip', 'Mizoram'),
(374, 'Dimapur', 'Nagaland'),
(375, 'Kohima', 'Nagaland'),
(376, 'Mokokchung', 'Nagaland'),
(377, 'Mon', 'Nagaland'),
(378, 'Phek', 'Nagaland'),
(379, 'Tuensang', 'Nagaland'),
(380, 'Wokha', 'Nagaland'),
(381, 'Zunheboto', 'Nagaland'),
(382, 'Angul', 'Orissa'),
(383, 'Boudh', 'Orissa'),
(384, 'Bhadrak', 'Orissa'),
(385, 'Bolangir', 'Orissa'),
(386, 'Bargarh', 'Orissa'),
(387, 'Baleswar', 'Orissa'),
(388, 'Cuttack', 'Orissa'),
(389, 'Debagarh', 'Orissa'),
(390, 'Dhenkanal', 'Orissa'),
(391, 'Ganjam', 'Orissa'),
(392, 'Gajapati', 'Orissa'),
(393, 'Jharsuguda', 'Orissa'),
(394, 'Jajapur', 'Orissa'),
(395, 'Jagatsinghpur', 'Orissa'),
(396, 'Khordha', 'Orissa'),
(397, 'Kendujhar', 'Orissa'),
(398, 'Kalahandi', 'Orissa'),
(399, 'Kandhamal', 'Orissa'),
(400, 'Koraput', 'Orissa'),
(401, 'Kendrapara', 'Orissa'),
(402, 'Malkangiri', 'Orissa'),
(403, 'Mayurbhanj', 'Orissa'),
(404, 'Nabarangpur', 'Orissa'),
(405, 'Nuapada', 'Orissa'),
(406, 'Nayagarh', 'Orissa'),
(407, 'Puri', 'Orissa'),
(408, 'Rayagada', 'Orissa'),
(409, 'Sambalpur', 'Orissa'),
(410, 'Subarnapur', 'Orissa'),
(411, 'Sundargarh', 'Orissa'),
(412, 'Karaikal', 'Puducherry'),
(413, 'Mahe', 'Puducherry'),
(414, 'Puducherry', 'Puducherry'),
(415, 'Yanam', 'Puducherry'),
(416, 'Amritsar', 'Punjab'),
(417, 'Bathinda', 'Punjab'),
(418, 'Firozpur', 'Punjab'),
(419, 'Faridkot', 'Punjab'),
(420, 'Fatehgarh Sahib', 'Punjab'),
(421, 'Gurdaspur', 'Punjab'),
(422, 'Hoshiarpur', 'Punjab'),
(423, 'Jalandhar', 'Punjab'),
(424, 'Kapurthala', 'Punjab'),
(425, 'Ludhiana', 'Punjab'),
(426, 'Mansa', 'Punjab'),
(427, 'Moga', 'Punjab'),
(428, 'Mukatsar', 'Punjab'),
(429, 'Nawan Shehar', 'Punjab'),
(430, 'Patiala', 'Punjab'),
(431, 'Rupnagar', 'Punjab'),
(432, 'Sangrur', 'Punjab'),
(433, 'Ajmer', 'Rajasthan'),
(434, 'Alwar', 'Rajasthan'),
(435, 'Bikaner', 'Rajasthan'),
(436, 'Barmer', 'Rajasthan'),
(437, 'Banswara', 'Rajasthan'),
(438, 'Bharatpur', 'Rajasthan'),
(439, 'Baran', 'Rajasthan'),
(440, 'Bundi', 'Rajasthan'),
(441, 'Bhilwara', 'Rajasthan'),
(442, 'Churu', 'Rajasthan'),
(443, 'Chittorgarh', 'Rajasthan'),
(444, 'Dausa', 'Rajasthan'),
(445, 'Dholpur', 'Rajasthan'),
(446, 'Dungapur', 'Rajasthan'),
(447, 'Ganganagar', 'Rajasthan'),
(448, 'Hanumangarh', 'Rajasthan'),
(449, 'Juhnjhunun', 'Rajasthan'),
(450, 'Jalore', 'Rajasthan'),
(451, 'Jodhpur', 'Rajasthan'),
(452, 'Jaipur', 'Rajasthan'),
(453, 'Jaisalmer', 'Rajasthan'),
(454, 'Jhalawar', 'Rajasthan'),
(455, 'Karauli', 'Rajasthan'),
(456, 'Kota', 'Rajasthan'),
(457, 'Nagaur', 'Rajasthan'),
(458, 'Pali', 'Rajasthan'),
(459, 'Pratapgarh', 'Rajasthan'),
(460, 'Rajsamand', 'Rajasthan'),
(461, 'Sikar', 'Rajasthan'),
(462, 'Sawai Madhopur', 'Rajasthan'),
(463, 'Sirohi', 'Rajasthan'),
(464, 'Tonk', 'Rajasthan'),
(465, 'Udaipur', 'Rajasthan'),
(466, 'East Sikkim', 'Sikkim'),
(467, 'North Sikkim', 'Sikkim'),
(468, 'South Sikkim', 'Sikkim'),
(469, 'West Sikkim', 'Sikkim'),
(470, 'Ariyalur', 'Tamil Nadu'),
(471, 'Chennai', 'Tamil Nadu'),
(472, 'Coimbatore', 'Tamil Nadu'),
(473, 'Cuddalore', 'Tamil Nadu'),
(474, 'Dharmapuri', 'Tamil Nadu'),
(475, 'Dindigul', 'Tamil Nadu'),
(476, 'Erode', 'Tamil Nadu'),
(477, 'Kanchipuram', 'Tamil Nadu'),
(478, 'Kanyakumari', 'Tamil Nadu'),
(479, 'Karur', 'Tamil Nadu'),
(480, 'Madurai', 'Tamil Nadu'),
(481, 'Nagapattinam', 'Tamil Nadu'),
(482, 'The Nilgiris', 'Tamil Nadu'),
(483, 'Namakkal', 'Tamil Nadu'),
(484, 'Perambalur', 'Tamil Nadu'),
(485, 'Pudukkottai', 'Tamil Nadu'),
(486, 'Ramanathapuram', 'Tamil Nadu'),
(487, 'Salem', 'Tamil Nadu'),
(488, 'Sivagangai', 'Tamil Nadu'),
(489, 'Tiruppur', 'Tamil Nadu'),
(490, 'Tiruchirappalli', 'Tamil Nadu'),
(491, 'Theni', 'Tamil Nadu'),
(492, 'Tirunelveli', 'Tamil Nadu'),
(493, 'Thanjavur', 'Tamil Nadu'),
(494, 'Thoothukudi', 'Tamil Nadu'),
(495, 'Thiruvallur', 'Tamil Nadu'),
(496, 'Thiruvarur', 'Tamil Nadu'),
(497, 'Tiruvannamalai', 'Tamil Nadu'),
(498, 'Vellore', 'Tamil Nadu'),
(499, 'Villupuram', 'Tamil Nadu'),
(500, 'Dhalai', 'Tripura'),
(501, 'North Tripura', 'Tripura'),
(502, 'South Tripura', 'Tripura'),
(503, 'West Tripura', 'Tripura'),
(504, 'Almora', 'Uttarakhand'),
(505, 'Bageshwar', 'Uttarakhand'),
(506, 'Chamoli', 'Uttarakhand'),
(507, 'Champawat', 'Uttarakhand'),
(508, 'Dehradun', 'Uttarakhand'),
(509, 'Haridwar', 'Uttarakhand'),
(510, 'Nainital', 'Uttarakhand'),
(511, 'Pauri Garhwal', 'Uttarakhand'),
(512, 'Pithoragharh', 'Uttarakhand'),
(513, 'Rudraprayag', 'Uttarakhand'),
(514, 'Tehri Garhwal', 'Uttarakhand'),
(515, 'Udham Singh Nagar', 'Uttarakhand'),
(516, 'Uttarkashi', 'Uttarakhand'),
(517, 'Agra', 'Uttar Pradesh'),
(518, 'Allahabad', 'Uttar Pradesh'),
(519, 'Aligarh', 'Uttar Pradesh'),
(520, 'Ambedkar Nagar', 'Uttar Pradesh'),
(521, 'Auraiya', 'Uttar Pradesh'),
(522, 'Azamgarh', 'Uttar Pradesh'),
(523, 'Barabanki', 'Uttar Pradesh'),
(524, 'Badaun', 'Uttar Pradesh'),
(525, 'Bagpat', 'Uttar Pradesh'),
(526, 'Bahraich', 'Uttar Pradesh'),
(527, 'Bijnor', 'Uttar Pradesh'),
(528, 'Ballia', 'Uttar Pradesh'),
(529, 'Banda', 'Uttar Pradesh'),
(530, 'Balrampur', 'Uttar Pradesh'),
(531, 'Bareilly', 'Uttar Pradesh'),
(532, 'Basti', 'Uttar Pradesh'),
(533, 'Bulandshahr', 'Uttar Pradesh'),
(534, 'Chandauli', 'Uttar Pradesh'),
(535, 'Chitrakoot', 'Uttar Pradesh'),
(536, 'Deoria', 'Uttar Pradesh'),
(537, 'Etah', 'Uttar Pradesh'),
(538, 'Kanshiram Nagar', 'Uttar Pradesh'),
(539, 'Etawah', 'Uttar Pradesh'),
(540, 'Firozabad', 'Uttar Pradesh'),
(541, 'Farrukhabad', 'Uttar Pradesh'),
(542, 'Fatehpur', 'Uttar Pradesh'),
(543, 'Faizabad', 'Uttar Pradesh'),
(544, 'Gautam Buddha Nagar', 'Uttar Pradesh'),
(545, 'Gonda', 'Uttar Pradesh'),
(546, 'Ghazipur', 'Uttar Pradesh'),
(547, 'Gorkakhpur', 'Uttar Pradesh'),
(548, 'Ghaziabad', 'Uttar Pradesh'),
(549, 'Hamirpur', 'Uttar Pradesh'),
(550, 'Hardoi', 'Uttar Pradesh'),
(551, 'Mahamaya Nagar', 'Uttar Pradesh'),
(552, 'Jhansi', 'Uttar Pradesh'),
(553, 'Jalaun', 'Uttar Pradesh'),
(554, 'Jyotiba Phule Nagar', 'Uttar Pradesh'),
(555, 'Jaunpur District', 'Uttar Pradesh'),
(556, 'Kanpur Dehat', 'Uttar Pradesh'),
(557, 'Kannauj', 'Uttar Pradesh'),
(558, 'Kanpur Nagar', 'Uttar Pradesh'),
(559, 'Kaushambi', 'Uttar Pradesh'),
(560, 'Kushinagar', 'Uttar Pradesh'),
(561, 'Lalitpur', 'Uttar Pradesh'),
(562, 'Lakhimpur Kheri', 'Uttar Pradesh'),
(563, 'Lucknow', 'Uttar Pradesh'),
(564, 'Mau', 'Uttar Pradesh'),
(565, 'Meerut', 'Uttar Pradesh'),
(566, 'Maharajganj', 'Uttar Pradesh'),
(567, 'Mahoba', 'Uttar Pradesh'),
(568, 'Mirzapur', 'Uttar Pradesh'),
(569, 'Moradabad', 'Uttar Pradesh'),
(570, 'Mainpuri', 'Uttar Pradesh'),
(571, 'Mathura', 'Uttar Pradesh'),
(572, 'Muzaffarnagar', 'Uttar Pradesh'),
(573, 'Pilibhit', 'Uttar Pradesh'),
(574, 'Pratapgarh', 'Uttar Pradesh'),
(575, 'Rampur', 'Uttar Pradesh'),
(576, 'Rae Bareli', 'Uttar Pradesh'),
(577, 'Saharanpur', 'Uttar Pradesh'),
(578, 'Sitapur', 'Uttar Pradesh'),
(579, 'Shahjahanpur', 'Uttar Pradesh'),
(580, 'Sant Kabir Nagar', 'Uttar Pradesh'),
(581, 'Siddharthnagar', 'Uttar Pradesh'),
(582, 'Sonbhadra', 'Uttar Pradesh'),
(583, 'Sant Ravidas Nagar', 'Uttar Pradesh'),
(584, 'Sultanpur', 'Uttar Pradesh'),
(585, 'Shravasti', 'Uttar Pradesh'),
(586, 'Unnao', 'Uttar Pradesh'),
(587, 'Varanasi', 'Uttar Pradesh'),
(588, 'Birbhum', 'West Bengal'),
(589, 'Bankura', 'West Bengal'),
(590, 'Bardhaman', 'West Bengal'),
(591, 'Darjeeling', 'West Bengal'),
(592, 'Dakshin Dinajpur', 'West Bengal'),
(593, 'Hooghly', 'West Bengal'),
(594, 'Howrah', 'West Bengal'),
(595, 'Jalpaiguri', 'West Bengal'),
(596, 'Cooch Behar', 'West Bengal'),
(597, 'Kolkata', 'West Bengal'),
(598, 'Malda', 'West Bengal'),
(599, 'Midnapore', 'West Bengal'),
(600, 'Murshidabad', 'West Bengal'),
(601, 'Nadia', 'West Bengal'),
(602, 'North 24 Parganas', 'West Bengal'),
(603, 'South 24 Parganas', 'West Bengal'),
(604, 'Purulia', 'West Bengal'),
(605, 'Uttar Dinajpur', 'West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `state_master`
--

CREATE TABLE `state_master` (
  `id` int(11) NOT NULL,
  `state_name` varchar(200) NOT NULL,
  `active_flag` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `state_master`
--

INSERT INTO `state_master` (`id`, `state_name`, `active_flag`) VALUES
(1, 'Overseas', 'Active'),
(2, 'Local', 'Active'),
(3, 'Andaman and Nicobar Islands(35)', 'Active'),
(4, 'Andhra Pradesh(28)', 'Active'),
(5, 'Andhra Pradesh (New)(37)', 'Active'),
(6, ' Arunachal Pradesh(12)', 'Active'),
(7, 'Assam(18)', 'Active'),
(8, 'Bihar(10)', 'Active'),
(9, 'Chandigarh(04)', 'Active'),
(10, 'Dadra and Nagar Haveli(26)', 'Active'),
(11, 'Daman and Diu(25)', 'Active'),
(12, 'Delhi(07)', 'Active'),
(13, 'Gujarat(24)', 'Active'),
(14, 'Haryana(06)', 'Active'),
(15, 'Himachal Pradesh(02)', 'Active'),
(16, 'Jammu and Kashmir(01)', 'Active'),
(17, 'Jharkhand(20)', 'Active'),
(18, 'Karnataka(29)', 'Active'),
(19, 'Kerala(32)', 'Active'),
(20, 'Lakshadweep Islands(31)', 'Active'),
(21, 'Madhya Pradesh(23)', 'Active'),
(22, 'Maharashtra(27)', 'Active'),
(23, 'Manipur(14)', 'Active'),
(24, 'Meghalaya(17)', 'Active'),
(25, 'Mizoram(15)', 'Active'),
(26, 'Nagaland(13)', 'Active'),
(27, 'Odisha(21)', 'Active'),
(28, 'Pondicherry(34)', 'Active'),
(29, 'Punjab(03)', 'Active'),
(30, 'Rajasthan(8)', 'Active'),
(31, 'Sikkim(11)', 'Active'),
(32, 'Tamil Nadu(33)', 'Active'),
(33, 'Telangana(36)', 'Active'),
(34, 'Tripura(16)', 'Active'),
(35, 'Uttar Pradesh(09)', 'Active'),
(36, 'Uttarakhand(05)', 'Active'),
(37, 'West Bengal(19)', 'Active'),
(38, 'Goa(30)', 'Active'),
(39, 'Chhattisgarh(22)', 'Active'),
(40, 'Leh Ladakh(38)', 'Active'),
(41, 'Afghanistan', 'Active'),
(42, 'Albania', 'Active'),
(43, 'Algeria', 'Active'),
(44, 'American Samoa', 'Active'),
(45, 'Andorra', 'Active'),
(46, 'Angola', 'Active'),
(47, 'Anguilla', 'Active'),
(48, 'Antarctica', 'Active'),
(49, 'Antigua And Barbuda', 'Active'),
(50, 'Argentina', 'Active'),
(51, 'Armenia', 'Active'),
(52, 'Aruba', 'Active'),
(53, 'Australia', 'Active'),
(54, 'Austria', 'Active'),
(55, 'Azerbaijan', 'Active'),
(56, 'Bahamas', 'Active'),
(57, 'Bahrain', 'Active'),
(58, 'Bangladesh', 'Active'),
(59, 'Barbados', 'Active'),
(60, 'Belarus', 'Active'),
(61, 'Belgium', 'Active'),
(62, 'Belize', 'Active'),
(63, 'Benin', 'Active'),
(64, 'Bermuda', 'Active'),
(65, 'Bhutan', 'Active'),
(66, 'Bolivia', 'Active'),
(67, 'Bosnia And Herzegovina', 'Active'),
(68, 'Botswana', 'Active'),
(69, 'Bouvet Island', 'Active'),
(70, 'Brazil', 'Active'),
(71, 'British Indian Ocean Territory', 'Active'),
(72, 'Brunei Darussalam', 'Active'),
(73, 'Bulgaria', 'Active'),
(74, 'Burkina Faso', 'Active'),
(75, 'Burundi', 'Active'),
(76, 'Cambodia', 'Active'),
(77, 'Cameroon', 'Active'),
(78, 'Canada', 'Active'),
(79, 'Cape Verde', 'Active'),
(80, 'Cayman Islands', 'Active'),
(81, 'Central African Republic', 'Active'),
(82, 'Chad', 'Active'),
(83, 'Chile', 'Active'),
(84, 'China', 'Active'),
(85, 'Christmas Island', 'Active'),
(86, 'Cocos (keeling) Islands', 'Active'),
(87, 'Colombia', 'Active'),
(88, 'Comoros', 'Active'),
(89, 'Congo', 'Active'),
(90, 'Congo, The Democratic Republic Of The', 'Active'),
(91, 'Cook Islands', 'Active'),
(92, 'Costa Rica', 'Active'),
(93, 'Cote D\'ivoire', 'Active'),
(94, 'Croatia', 'Active'),
(95, 'Cuba', 'Active'),
(96, 'Cyprus', 'Active'),
(97, 'Czech Republic', 'Active'),
(98, 'Denmark', 'Active'),
(99, 'Djibouti', 'Active'),
(100, 'Dominica', 'Active'),
(101, 'Dominican Republic', 'Active'),
(102, 'East Timor', 'Active'),
(103, 'Ecuador', 'Active'),
(104, 'Egypt', 'Active'),
(105, 'El Salvador', 'Active'),
(106, 'Equatorial Guinea', 'Active'),
(107, 'Eritrea', 'Active'),
(108, 'Estonia', 'Active'),
(109, 'Ethiopia', 'Active'),
(110, 'Falkland Islands (malvinas)', 'Active'),
(111, 'Faroe Islands', 'Active'),
(112, 'Fiji', 'Active'),
(113, 'Finland', 'Active'),
(114, 'France', 'Active'),
(115, 'French Guiana', 'Active'),
(116, 'French Polynesia', 'Active'),
(117, 'French Southern Territories', 'Active'),
(118, 'Gabon', 'Active'),
(119, 'Gambia', 'Active'),
(120, 'Georgia', 'Active'),
(121, 'Germany', 'Active'),
(122, 'Ghana', 'Active'),
(123, 'Gibraltar', 'Active'),
(124, 'Greece', 'Active'),
(125, 'Greenland', 'Active'),
(126, 'Grenada', 'Active'),
(127, 'Guadeloupe', 'Active'),
(128, 'Guam', 'Active'),
(129, 'Guatemala', 'Active'),
(130, 'Guinea', 'Active'),
(131, 'Guinea-bissau', 'Active'),
(132, 'Guyana', 'Active'),
(133, 'Haiti', 'Active'),
(134, 'Heard Island And Mcdonald Islands', 'Active'),
(135, 'Holy See (vatican City State)', 'Active'),
(136, 'Honduras', 'Active'),
(137, 'Hong Kong', 'Active'),
(138, 'Hungary', 'Active'),
(139, 'Iceland', 'Active'),
(140, 'India', 'Active'),
(141, 'Indonesia', 'Active'),
(142, 'Iran, Islamic Republic Of', 'Active'),
(143, 'Iraq', 'Active'),
(144, 'Ireland', 'Active'),
(145, 'Israel', 'Active'),
(146, 'Italy', 'Active'),
(147, 'Jamaica', 'Active'),
(148, 'Japan', 'Active'),
(149, 'Jordan', 'Active'),
(150, 'Kazakstan', 'Active'),
(151, 'Kenya', 'Active'),
(152, 'Kiribati', 'Active'),
(153, 'Korea, Democratic People\'s Republic Of', 'Active'),
(154, 'Korea, Republic Of', 'Active'),
(155, 'Kosovo', 'Active'),
(156, 'Kuwait', 'Active'),
(157, 'Kyrgyzstan', 'Active'),
(158, 'Lao People\'s Democratic Republic', 'Active'),
(159, 'Latvia', 'Active'),
(160, 'Lebanon', 'Active'),
(161, 'Lesotho', 'Active'),
(162, 'Liberia', 'Active'),
(163, 'Libyan Arab Jamahiriya', 'Active'),
(164, 'Liechtenstein', 'Active'),
(165, 'Lithuania', 'Active'),
(166, 'Luxembourg', 'Active'),
(167, 'Macau', 'Active'),
(168, 'Macedonia, The Former Yugoslav Republic Of', 'Active'),
(169, 'Madagascar', 'Active'),
(170, 'Malawi', 'Active'),
(171, 'Malaysia', 'Active'),
(172, 'Maldives', 'Active'),
(173, 'Mali', 'Active'),
(174, 'Malta', 'Active'),
(175, 'Marshall Islands', 'Active'),
(176, 'Martinique', 'Active'),
(177, 'Mauritania', 'Active'),
(178, 'Mauritius', 'Active'),
(179, 'Mayotte', 'Active'),
(180, 'Mexico', 'Active'),
(181, 'Micronesia, Federated States Of', 'Active'),
(182, 'Moldova, Republic Of', 'Active'),
(183, 'Monaco', 'Active'),
(184, 'Mongolia', 'Active'),
(185, 'Montserrat', 'Active'),
(186, 'Montenegro', 'Active'),
(187, 'Morocco', 'Active'),
(188, 'Mozambique', 'Active'),
(189, 'Myanmar', 'Active'),
(190, 'Namibia', 'Active'),
(191, 'Nauru', 'Active'),
(192, 'Nepal', 'Active'),
(193, 'Netherlands', 'Active'),
(194, 'Netherlands Antilles', 'Active'),
(195, 'New Caledonia', 'Active'),
(196, 'New Zealand', 'Active'),
(197, 'Nicaragua', 'Active'),
(198, 'Niger', 'Active'),
(199, 'Nigeria', 'Active'),
(200, 'Niue', 'Active'),
(201, 'Norfolk Island', 'Active'),
(202, 'Northern Mariana Islands', 'Active'),
(203, 'Norway', 'Active'),
(204, 'Oman', 'Active'),
(205, 'Pakistan', 'Active'),
(206, 'Palau', 'Active'),
(207, 'Palestinian Territory, Occupied', 'Active'),
(208, 'Panama', 'Active'),
(209, 'Papua New Guinea', 'Active'),
(210, 'Paraguay', 'Active'),
(211, 'Peru', 'Active'),
(212, 'Philippines', 'Active'),
(213, 'Pitcairn', 'Active'),
(214, 'Poland', 'Active'),
(215, 'Portugal', 'Active'),
(216, 'Puerto Rico', 'Active'),
(217, 'Qatar', 'Active'),
(218, 'Reunion', 'Active'),
(219, 'Romania', 'Active'),
(220, 'Russian Federation', 'Active'),
(221, 'Rwanda', 'Active'),
(222, 'Saint Helena', 'Active'),
(223, 'Saint Kitts And Nevis', 'Active'),
(224, 'Saint Lucia', 'Active'),
(225, 'Saint Pierre And Miquelon', 'Active'),
(226, 'Saint Vincent And The Grenadines', 'Active'),
(227, 'Samoa', 'Active'),
(228, 'San Marino', 'Active'),
(229, 'Sao Tome And Principe', 'Active'),
(230, 'Saudi Arabia', 'Active'),
(231, 'Senegal', 'Active'),
(232, 'Serbia', 'Active'),
(233, 'Seychelles', 'Active'),
(234, 'Sierra Leone', 'Active'),
(235, 'Singapore', 'Active'),
(236, 'Slovakia', 'Active'),
(237, 'Slovenia', 'Active'),
(238, 'Solomon Islands', 'Active'),
(239, 'Somalia', 'Active'),
(240, 'South Africa', 'Active'),
(241, 'South Georgia And The South Sandwich Islands', 'Active'),
(242, 'Spain', 'Active'),
(243, 'Sri Lanka', 'Active'),
(244, 'Sudan', 'Active'),
(245, 'Suriname', 'Active'),
(246, 'Svalbard And Jan Mayen', 'Active'),
(247, 'Swaziland', 'Active'),
(248, 'Sweden', 'Active'),
(249, 'Switzerland', 'Active'),
(250, 'Syrian Arab Republic', 'Active'),
(251, 'Taiwan, Province Of China', 'Active'),
(252, 'Tajikistan', 'Active'),
(253, 'Tanzania, United Republic Of', 'Active'),
(254, 'Thailand', 'Active'),
(255, 'Togo', 'Active'),
(256, 'Tokelau', 'Active'),
(257, 'Tonga', 'Active'),
(258, 'Trinidad And Tobago', 'Active'),
(259, 'Tunisia', 'Active'),
(260, 'Turkey', 'Active'),
(261, 'Turkmenistan', 'Active'),
(262, 'Turks And Caicos Islands', 'Active'),
(263, 'Tuvalu', 'Active'),
(264, 'Uganda', 'Active'),
(265, 'Ukraine', 'Active'),
(266, 'United Arab Emirates', 'Active'),
(267, 'United Kingdom', 'Active'),
(268, 'United States', 'Active'),
(269, 'United States Minor Outlying Islands', 'Active'),
(270, 'Uruguay', 'Active'),
(271, 'Uzbekistan', 'Active'),
(272, 'Vanuatu', 'Active'),
(273, 'Venezuela', 'Active'),
(274, 'Viet Nam', 'Active'),
(275, 'Virgin Islands, British', 'Active'),
(276, 'Virgin Islands, U.s.', 'Active'),
(277, 'Wallis And Futuna', 'Active'),
(278, 'Western Sahara', 'Active'),
(279, 'Yemen', 'Active'),
(280, 'Zambia', 'Active'),
(281, 'Zimbabwe', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `subgroup_master`
--

CREATE TABLE `subgroup_master` (
  `subgroup_id` int(11) NOT NULL,
  `subgroup_name` varchar(300) NOT NULL,
  `group_id` int(11) NOT NULL,
  `dr_cr` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `subgroup_master`
--

INSERT INTO `subgroup_master` (`subgroup_id`, `subgroup_name`, `group_id`, `dr_cr`) VALUES
(1, 'Capital', 1, 'Cr'),
(2, 'Cash & Cash Equivalents', 2, 'Dr'),
(3, 'Direct Expenses', 3, 'Dr'),
(5, 'Direct Income', 5, 'Cr'),
(6, 'Indirect Income', 6, 'Cr'),
(7, 'Indirect Expenses_Staff', 7, 'Dr'),
(8, 'Indirect Expenses_Finance', 8, 'Dr'),
(9, 'Indirect Expenses_Other', 9, 'Dr'),
(10, 'Long Term Borrowing', 10, 'Cr'),
(11, 'Long Term Loans & Advances', 11, 'Dr'),
(12, 'Long Term Provisions', 12, 'Cr'),
(13, 'Non-current Investments', 13, 'Dr'),
(14, 'Other Current Liabilities', 14, 'Cr'),
(15, 'Reserves & Surplus', 1, 'Cr'),
(16, 'Short Term Borrowings', 16, 'Cr'),
(17, 'Short Term Loans & Advances', 17, 'Dr'),
(18, 'Short Term Provisions', 18, 'Cr'),
(19, 'Expense (Other Direct)', 19, 'Dr'),
(20, 'Trade Receivables', 20, 'Dr'),
(21, 'Unsecured Loan', 21, 'Cr'),
(22, 'Advance from customers', 14, 'Cr'),
(23, 'Advances to Suppliers', 17, 'Dr'),
(24, 'Bank Balances', 2, 'Dr'),
(25, 'Bank Overdraft', 16, 'Cr'),
(26, 'Bus Booking Expenses', 3, 'Dr'),
(27, 'Bus Cancellation Expenses', 3, 'Dr'),
(28, 'Capital Advances', 11, 'Dr'),
(29, 'Capital Redemption Reserve', 1, 'Cr'),
(30, 'Capital Reserves', 1, 'Cr'),
(31, 'Car Rental Booking Expenses', 3, 'Dr'),
(32, 'Car Rental Cancellation Expenses', 3, 'Dr'),
(33, 'Cash in Hand', 2, 'Dr'),
(34, 'Commission from Insurance Services', 5, 'Cr'),
(35, 'Communication Expenses', 9, 'Dr'),
(36, 'Cruise Booking Expenses', 3, 'Dr'),
(37, 'Cruise Cancellation Expenses', 3, 'Dr'),
(38, 'Deffered Payment Liabilities', 10, 'Cr'),
(39, 'Deposits (Liabilities)', 10, 'Cr'),
(40, 'Depreciation ', 9, 'Dr'),
(41, 'Dividend received', 6, 'Cr'),
(42, 'DMC Booking Expenses', 3, 'Dr'),
(43, 'Electricity', 9, 'Dr'),
(44, 'Employee Benefit Expenses', 7, 'Dr'),
(45, 'Excursion Cancellation Expenses', 3, 'Dr'),
(46, 'Excursion Purchased', 3, 'Dr'),
(47, 'Finance Charges', 8, 'Dr'),
(48, 'Flight Booking Expenses', 3, 'Dr'),
(49, 'Flight Cancellation Expenses', 3, 'Dr'),
(50, 'Foreign Exchange Gain', 6, 'Cr'),
(51, 'Foreign Exchange Loss', 9, 'Dr'),
(52, 'Gain/(Loss) on Sale of Investment', 6, 'Cr'),
(53, 'Gain/(Loss) on Sale or disposal of Fixed Assets', 6, 'Cr'),
(54, 'General Reserve', 1, 'Cr'),
(55, 'Hotel Booking Expenses', 3, 'Dr'),
(56, 'Hotel Cancellation Expenses', 3, 'Dr'),
(57, 'Housekeeping & Office Maintenance', 9, 'Dr'),
(58, 'Income received in advance', 14, 'Cr'),
(59, 'Insurance Premium Paid', 9, 'Dr'),
(60, 'Intangible Asset', 4, 'Dr'),
(61, 'Interest Accrued but due', 14, 'Cr'),
(62, 'Interest Accrued but not due', 14, 'Cr'),
(63, 'Interest received', 6, 'Cr'),
(64, 'Invesment in Debentures & Bonds', 13, 'Dr'),
(65, 'Invesment in Equity Shares', 13, 'Dr'),
(66, 'Invesment in Government Securities', 13, 'Dr'),
(67, 'Invesment in Mutual Funds', 13, 'Dr'),
(68, 'Invesment in Preference Shares', 13, 'Dr'),
(69, 'Legal & professional Fees', 9, 'Dr'),
(70, 'Loans & Advances from Related Parties', 10, 'Cr'),
(71, 'Loans & Advances to Related Parties', 11, 'Dr'),
(72, 'Miscelleneous Expenses', 9, 'Dr'),
(73, 'Other Cancellation Charges Paid', 3, 'Dr'),
(74, 'Other Vehicle Rental Expenses', 3, 'Dr'),
(75, 'Petrol & Diesel', 9, 'Dr'),
(76, 'Printing & Stationery Expenses', 9, 'Dr'),
(77, 'Provisions for Gratuity (Long Term)', 12, 'Cr'),
(78, 'Provsion for gratuity (Short Term)', 18, 'Cr'),
(79, 'Purchase Return', 3, 'Dr'),
(80, 'Rates & Taxes', 9, 'Dr'),
(81, 'Rent', 9, 'Dr'),
(82, 'Repairs & Maintenance', 9, 'Dr'),
(83, 'Revaluation Reserve', 1, 'Cr'),
(84, 'Salaries & Wages', 7, 'Dr'),
(85, 'Salary & Other payables', 14, 'Cr'),
(86, 'Sale of Scrap', 6, 'Cr'),
(87, 'Sale of Services', 5, 'Cr'),
(88, 'Sales Promotion Expenses', 9, 'Dr'),
(89, 'Sales Return', 5, 'Dr'),
(90, 'Securities Premium Reserve', 1, 'Cr'),
(91, 'Security Deposits (Liability)', 11, 'Dr'),
(92, 'Security Expenses', 9, 'Dr'),
(93, 'Service Charges Received', 5, 'Cr'),
(94, 'Share Capital', 1, 'Cr'),
(95, 'Sight Seeing Cancellation Expenses', 3, 'Dr'),
(96, 'Sight Seeing Expenses', 3, 'Dr'),
(97, 'Staff Recruitment Expenses', 9, 'Dr'),
(98, 'Staff training Expenses', 9, 'Dr'),
(99, 'Statutory Dues', 14, 'Cr'),
(100, 'Tangible Asset', 4, 'Dr'),
(101, 'Train Ticket Cancellation  Expenses', 3, 'Dr'),
(102, 'Train Ticket Expenses', 3, 'Dr'),
(103, 'Travelling Cost', 9, 'Dr'),
(104, 'Unpaid dividends', 14, 'Cr'),
(105, 'Trade Payable', 14, 'Cr'),
(106, 'Gst', 14, 'Dr'),
(107, 'Vat', 17, 'Dr'),
(108, 'Visa Cancellation Expenses', 3, 'Dr'),
(109, 'Passport Cancellation Expenses', 3, 'Dr'),
(110, 'Dmc Cancellation Expenses', 3, 'Dr'),
(111, 'Equity', 1, 'Cr'),
(112, 'Current Capital Account', 1, 'Cr'),
(113, 'Deposits (Asset)', 11, 'Dr');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_packages`
--

CREATE TABLE `supplier_packages` (
  `package_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `supplier_type` varchar(50) NOT NULL,
  `name` varchar(250) NOT NULL,
  `active_flag` varchar(50) NOT NULL,
  `image_upload_url` varchar(400) NOT NULL,
  `file_prefix` varchar(255) NOT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks_master`
--

CREATE TABLE `tasks_master` (
  `task_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `task_name` text NOT NULL,
  `due_date` datetime NOT NULL,
  `remind` varchar(200) NOT NULL,
  `remind_due_date` datetime NOT NULL,
  `remind_by` varchar(100) NOT NULL,
  `task_type` varchar(200) NOT NULL,
  `task_type_field_id` varchar(100) NOT NULL,
  `extra_note` text NOT NULL,
  `reference_task_id` int(11) NOT NULL,
  `task_status` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  `status_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxation_master`
--

CREATE TABLE `taxation_master` (
  `taxation_id` int(11) NOT NULL,
  `tax_type_id` int(11) NOT NULL,
  `tax_in_percentage` decimal(50,2) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `gl_id` int(11) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tax_conditions`
--

CREATE TABLE `tax_conditions` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tax_conditions`
--

INSERT INTO `tax_conditions` (`id`, `name`) VALUES
(1, 'Place of supply'),
(2, 'Routing'),
(3, 'Payment Mode'),
(4, 'Target Amount'),
(5, 'Supplier'),
(6, 'Customer Type'),
(7, 'Customer'),
(8, 'Product'),
(9, 'Fee Type'),
(10, 'Supplier Type'),
(11, 'Price'),
(12, 'Airline'),
(13, 'Transaction Type'),
(14, 'Booking Cabin'),
(15, 'Service(Itinerary)'),
(16, 'Reissue');

-- --------------------------------------------------------

--
-- Table structure for table `tax_master`
--

CREATE TABLE `tax_master` (
  `entry_id` int(11) NOT NULL,
  `reflection` varchar(10) NOT NULL,
  `name1` varchar(40) NOT NULL,
  `amount1` decimal(50,2) NOT NULL,
  `ledger1` int(11) NOT NULL,
  `name2` varchar(40) NOT NULL,
  `amount2` decimal(50,2) NOT NULL,
  `ledger2` int(11) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tax_master`
--

INSERT INTO `tax_master` (`entry_id`, `reflection`, `name1`, `amount1`, `ledger1`, `name2`, `amount2`, `ledger2`, `status`) VALUES
(1, 'Income', 'CGST', '2.50', 21, 'SGST', '2.50', 119, 'Active'),
(2, 'Income', 'IGST', '5.00', 67, '', '0.00', 0, 'Active'),
(3, 'Income', 'CGST', '9.00', 21, 'SGST', '9.00', 119, 'Active'),
(4, 'Income', 'IGST', '18.00', 67, '', '0.00', 0, 'Active'),
(5, 'Income', 'CGST', '6.00', 21, 'SGST', '6.00', 119, 'Active'),
(6, 'Income', 'IGST', '12.00', 67, '', '0.00', 0, 'Active'),
(7, 'Income', 'CGST', '0.00', 21, 'SGST', '0.00', 119, 'Active'),
(8, 'Income', 'IGST', '0.00', 67, '', '0.00', 0, 'Active'),
(9, 'Income', 'VAT', '5.00', 150, '', '0.00', 0, 'Active'),
(10, 'Expense', 'CGST', '2.50', 145, 'SGST', '2.50', 146, 'Active'),
(11, 'Expense', 'IGST', '5.00', 148, '', '0.00', 0, 'Active'),
(12, 'Expense', 'CGST', '9.00', 145, 'SGST', '9.00', 146, 'Active'),
(13, 'Expense', 'IGST', '18.00', 148, '', '0.00', 0, 'Active'),
(14, 'Expense', 'CGST', '6.00', 145, 'SGST', '6.00', 146, 'Active'),
(15, 'Expense', 'IGST', '12.00', 148, '', '0.00', 0, 'Active'),
(16, 'Expense', 'CGST', '0.00', 145, 'SGST', '0.00', 146, 'Active'),
(17, 'Expense', 'IGST', '0.00', 148, '', '0.00', 0, 'Active'),
(18, 'Expense', 'VAT', '5.00', 149, '', '0.00', 0, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tax_master_rules`
--

CREATE TABLE `tax_master_rules` (
  `rule_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `validity` varchar(10) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `ledger_id` int(11) NOT NULL,
  `travel_type` varchar(30) NOT NULL,
  `calculation_mode` varchar(10) NOT NULL,
  `target_amount` varchar(30) NOT NULL,
  `applicableOn` int(11) NOT NULL,
  `conditions` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tax_master_rules`
--

INSERT INTO `tax_master_rules` (`rule_id`, `entry_id`, `name`, `validity`, `from_date`, `to_date`, `ledger_id`, `travel_type`, `calculation_mode`, `target_amount`, `applicableOn`, `conditions`, `status`, `created_at`) VALUES
(1, 1, 'Output SGST CGST', 'Permanent', '1970-01-01', '1970-01-01', 0, 'All', 'Exclusive', 'Total', 0, '[{\"condition\":\"1\",\"for1\":\"!=\",\"value\":\"22\",\"currency\":\"NA\",\"amount\":\"\"}]', 'Active', '2023-01-27'),
(2, 2, 'IGST', 'Permanent', '1970-01-01', '1970-01-01', 0, 'All', 'Exclusive', 'Basic', 0, '[{\"condition\":\"1\",\"for1\":\"==\",\"value\":\"22\",\"currency\":\"\",\"amount\":\"\"}]', 'Active', '2023-01-27'),
(3, 2, 'IGST', 'Permanent', '1970-01-01', '1970-01-01', 0, 'All', 'Exclusive', 'Basic', 0, '[{\"condition\":\"1\",\"for1\":\"==\",\"value\":\"22\",\"currency\":\"\",\"amount\":\"\"}]', 'Active', '2023-01-30'),
(4, 2, 'IGST', 'Permanent', '1970-01-01', '1970-01-01', 0, 'All', 'Exclusive', 'Basic', 0, '[{\"condition\":\"1\",\"for1\":\"==\",\"value\":\"22\",\"currency\":\"\",\"amount\":\"\"}]', 'Active', '2023-01-30');

-- --------------------------------------------------------

--
-- Table structure for table `tcs_master`
--

CREATE TABLE `tcs_master` (
  `entry_id` int(11) NOT NULL,
  `tax_amount` decimal(50,2) NOT NULL,
  `calc` int(11) NOT NULL,
  `apply` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tcs_master`
--

INSERT INTO `tcs_master` (`entry_id`, `tax_amount`, `calc`, `apply`) VALUES
(1, '5.00', 0, 1),
(2, '5.00', 0, 1),
(3, '5.00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tds_entry_master`
--

CREATE TABLE `tds_entry_master` (
  `payment_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `payment_side` varchar(100) NOT NULL,
  `payment_for` varchar(100) NOT NULL,
  `payment_against` text NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `terms_and_conditions`
--

CREATE TABLE `terms_and_conditions` (
  `terms_and_conditions_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `type` varchar(150) NOT NULL,
  `title` varchar(300) NOT NULL,
  `terms_and_conditions` text NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `dest_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `terms_and_conditions`
--

INSERT INTO `terms_and_conditions` (`terms_and_conditions_id`, `branch_admin_id`, `type`, `title`, `terms_and_conditions`, `active_flag`, `created_at`, `dest_id`) VALUES
(1, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:48:00', 1),
(2, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:48:00', 4),
(3, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:49:00', 5),
(4, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:49:00', 6),
(5, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:49:00', 7),
(6, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:50:00', 34),
(7, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:50:00', 39),
(8, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:50:00', 37),
(9, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:51:00', 33),
(10, 1, 'Package Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:51:00', 9),
(11, 1, 'Receipt', '', '<div><div><b>Payment Policy</b><br></div></div><div><ul><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li></ul></div>', 'Active', '2022-11-23 21:52:00', 0),
(12, 1, 'Invoice', '', '<div><b>Payment Policy</b><br></div><div><ul><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li></ul></div>', 'Active', '2022-11-23 21:52:00', 0),
(13, 1, 'Group Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:53:00', 0),
(14, 1, 'Hotel Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:53:00', 0),
(15, 1, 'Flight Quotation', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div>', 'Active', '2022-11-23 21:53:00', 0),
(16, 1, 'Package Sale', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:53:00', 0),
(17, 1, 'Group Sale', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div><div><b>Cancellation Policy:</b></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div><div><b>Foreign Exchange:</b></div><div><ul><li>Foreign Exchange utilization for the purpose of Land arrangements/ self use will be done from the</li><li>individual BTQ Quota only.</li><li>Payments will be accepted in accordance with the rules and regulations laid down by Reserve Bank of</li><li>India.</li><li>You shall be required to provide such KYC documents as may be requested by Travel Tours at the time</li><li>of booking/ receiving the booking amounts.</li></ul></div><div><b>Booking Amendments :</b></div><div><ul><li>If you wish to transfer from one trip to another or transfer your booking to a third party you must notify</li><li>us at least 40 days prior to the departure date.</li><li>No charges are applied.&nbsp;</li></ul></div>', 'Active', '2022-11-23 21:53:00', 0),
(18, 1, 'Flight E-Ticket', '', '<div><b>Booking &amp; Cancellation Policy:</b><br></div><div><ul><li>In the event of cancellation of tour / travel services due to any avoidable / unavoidable reason/s we must be</li><li>notified of the same in writing. Cancellation charges will be effective from the date we receive advice in</li><li>writing, and cancellation charges would be as follows:</li><li>45 days prior to arrival: 10% of the Tour / service cost</li><li>15 days prior to arrival: 25% of the Tour / service cost</li><li>07 days prior to arrival: 50% of the Tour / service cost</li><li>48 hours prior to arrival OR No Show: No Refund</li></ul></div>', 'Active', '2022-11-23 21:53:00', 0),
(19, 1, 'Package Service Voucher', '', '<b>a</b>', 'Inactive', '2022-11-23 21:54:00', 0),
(20, 1, 'Hotel Service Voucher', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div>', 'Active', '2022-12-12 17:09:00', 0),
(21, 1, 'Package Service Voucher', '', '<div><b>Booking Amount And Final Payment:</b></div><div><ul><li>We require a minimum deposit as booking amounts as per the below chart per person at the time of</li><li>booking.&nbsp;</li><li>Your service provider will require amounts towards the bookings which amounts are non-refundable,</li><li>non-transferable and interest free amounts.&nbsp;</li><li>Final payment for the relevant booking is required no later than 6 weeks prior to departure unless</li><li>otherwise stated on your invoice.&nbsp;</li><li>Some airfares or services must be paid in full at the time of booking.</li></ul></div>', 'Active', '2022-12-12 17:09:00', 0),
(22, 1, 'Package Quotation', '', '<div><ul><li>Accommodation on twin/Double sharing basis in Deluxe hotels.</li><li>Return Air fare</li><li>Extra bed for the extra Adult, Child (above 12 yrs) Child without bed (5-11 Yrs) i.e. Per tour cost paid.</li><li>Internal transfers &amp; sightseeing by AC vehicle some sightseeings by Non AC small vehicles tour Itinerary.</li><li>Food Plan As per tour Itinerary.</li><li>Tour Escort.</li><li>Per day per person 2 ltrs drinking water bottle. (except Infant).</li><li>Porter charges except itinerary.</li><li>Service Charges.</li><li>All meals included (breakfast, lunch, dinner)</li><li>Daily one mineral water</li></ul></div><div><br></div>', 'Active', '2023-01-03 15:31:00', 8);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_master`
--

CREATE TABLE `ticket_master` (
  `ticket_id` int(11) NOT NULL,
  `ticket_reissue` tinyint(1) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `tour_type` varchar(100) NOT NULL,
  `due_date` date NOT NULL,
  `adults` varchar(100) NOT NULL,
  `childrens` varchar(100) NOT NULL,
  `infant` varchar(100) NOT NULL,
  `adult_fair` decimal(50,2) NOT NULL,
  `children_fair` decimal(50,2) NOT NULL,
  `infant_fair` decimal(50,2) NOT NULL,
  `basic_cost` decimal(50,2) NOT NULL,
  `markup_show` decimal(50,2) NOT NULL,
  `markup` decimal(50,2) NOT NULL,
  `basic_cost_discount` decimal(50,2) NOT NULL,
  `yq_tax` decimal(50,2) NOT NULL,
  `other_taxes` decimal(50,2) NOT NULL,
  `service_show` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `service_tax_subtotal` varchar(100) NOT NULL,
  `service_tax_markup` varchar(100) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `ticket_total_cost` decimal(50,2) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `emp_id` int(11) NOT NULL,
  `reflections` text NOT NULL,
  `bsm_values` text NOT NULL,
  `roundoff` decimal(50,2) NOT NULL,
  `canc_policy` text NOT NULL,
  `guest_name` varchar(100) NOT NULL,
  `invoice_pr_id` int(11) NOT NULL,
  `cancel_flag` int(11) NOT NULL,
  `delete_status` int(11) NOT NULL,
  `cancel_type` int(11) NOT NULL,
  `cancel_estimate` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_master_airfile`
--

CREATE TABLE `ticket_master_airfile` (
  `ticket_airfile_id` int(11) NOT NULL,
  `total_cost` decimal(50,2) NOT NULL,
  `basic_cost` decimal(50,2) NOT NULL,
  `yq_tax` decimal(50,2) NOT NULL,
  `other_taxes` decimal(50,2) NOT NULL,
  `issue_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_master_entries`
--

CREATE TABLE `ticket_master_entries` (
  `entry_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `middle_name` varchar(300) NOT NULL,
  `last_name` varchar(300) NOT NULL,
  `birth_date` date NOT NULL,
  `adolescence` varchar(300) NOT NULL,
  `ticket_no` varchar(300) NOT NULL,
  `baggage_info` varchar(100) NOT NULL,
  `gds_pnr` varchar(300) NOT NULL,
  `main_ticket` varchar(300) NOT NULL,
  `passport_no` varchar(500) NOT NULL,
  `passport_issue_date` date NOT NULL,
  `passport_expiry_date` date NOT NULL,
  `id_proof_url` text NOT NULL,
  `pan_card_url` text NOT NULL,
  `status` varchar(100) NOT NULL,
  `seat_no` varchar(300) NOT NULL,
  `meal_plan` varchar(400) NOT NULL,
  `type_of_tour` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_master_entries_airfile`
--

CREATE TABLE `ticket_master_entries_airfile` (
  `entry_id` int(11) NOT NULL,
  `ticket_airfile_id` int(11) NOT NULL,
  `gds_pnr` varchar(100) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `middle_name` varchar(300) NOT NULL,
  `last_name` varchar(300) NOT NULL,
  `adolescence` varchar(300) NOT NULL,
  `ticket_no` varchar(300) NOT NULL,
  `cticket_no` varchar(300) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_master_upload_entries`
--

CREATE TABLE `ticket_master_upload_entries` (
  `entry_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `ticket_url` text NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_payment_master`
--

CREATE TABLE `ticket_payment_master` (
  `payment_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `credit_charges` decimal(50,2) NOT NULL,
  `credit_card_details` varchar(200) NOT NULL,
  `status` varchar(10) NOT NULL,
  `delete_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_refund_entries`
--

CREATE TABLE `ticket_refund_entries` (
  `id` int(11) NOT NULL,
  `refund_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_refund_master`
--

CREATE TABLE `ticket_refund_master` (
  `refund_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_trip_entries`
--

CREATE TABLE `ticket_trip_entries` (
  `entry_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `airline_id` int(11) NOT NULL,
  `departure_datetime` datetime NOT NULL,
  `arrival_datetime` datetime NOT NULL,
  `airlines_name` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `flight_class` varchar(5) NOT NULL,
  `flight_no` varchar(100) NOT NULL,
  `airlin_pnr` varchar(100) NOT NULL,
  `from_city` int(11) NOT NULL,
  `to_city` int(11) NOT NULL,
  `departure_city` varchar(100) NOT NULL,
  `arrival_city` varchar(100) NOT NULL,
  `meal_plan` text NOT NULL,
  `luggage` text NOT NULL,
  `special_note` text NOT NULL,
  `arrival_terminal` varchar(200) NOT NULL,
  `departure_terminal` varchar(200) NOT NULL,
  `sub_category` varchar(100) NOT NULL,
  `no_of_pieces` varchar(100) NOT NULL,
  `aircraft_type` varchar(100) NOT NULL,
  `operating_carrier` varchar(100) NOT NULL,
  `frequent_flyer` varchar(100) NOT NULL,
  `ticket_status` varchar(100) NOT NULL,
  `basic_fare` decimal(50,2) NOT NULL,
  `passenger_id` int(11) NOT NULL,
  `flight_duration` varchar(100) NOT NULL,
  `layover_time` varchar(50) NOT NULL,
  `refund_type` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_trip_entries_airfile`
--

CREATE TABLE `ticket_trip_entries_airfile` (
  `entry_id` int(11) NOT NULL,
  `ticket_airfile_id` int(11) NOT NULL,
  `departure_datetime` datetime NOT NULL,
  `arrival_datetime` datetime NOT NULL,
  `airlines_name` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `flight_no` varchar(100) NOT NULL,
  `from_city` int(11) NOT NULL,
  `to_city` int(11) NOT NULL,
  `departure_city` varchar(100) NOT NULL,
  `arrival_city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_vendor`
--

CREATE TABLE `ticket_vendor` (
  `vendor_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `email_id` text NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `mobile_no` text NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `website` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `side` varchar(6) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ticket_vendor`
--

INSERT INTO `ticket_vendor` (`vendor_id`, `state_id`, `vendor_name`, `email_id`, `contact_person_name`, `immergency_contact_no`, `mobile_no`, `landline_no`, `address`, `opening_balance`, `active_flag`, `website`, `bank_name`, `account_name`, `account_no`, `branch`, `ifsc_code`, `service_tax_no`, `created_at`, `side`, `pan_no`, `as_of_date`) VALUES
(1, 22, 'Akbar Travels', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '+nLvKkvdP4jqlQ==', '', '', '0.00', 'Active', '', '', '', '', '', '', '', '2023-02-13 18:59:18', 'Credit', '', 2023),
(2, 22, 'GoIbibo', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '+nLvKkvdP4jqlQ==', '', '', '0.00', 'Active', '', '', '', '', '', '', '', '2023-02-13 18:59:36', 'Credit', '', 2023),
(3, 22, 'Yatra.com', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '+nLvKkvdP4jqlQ==', '', '', '0.00', 'Active', '', '', '', '', '', '', '', '2023-02-13 19:00:32', 'Credit', '', 2023),
(4, 12, 'Clear Trip', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '+nLvKkvdP4jqlQ==', '', '', '0.00', 'Active', '', '', '', '', '', '', '', '2023-02-13 19:01:00', 'Credit', '', 2023),
(5, 22, 'Ease My Trip', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '+nLvKkvdP4jqlQ==', '', '', '0.00', 'Active', '', '', '', '', '', '', '', '2023-02-13 19:01:27', 'Credit', '', 2023);

-- --------------------------------------------------------

--
-- Table structure for table `tourism_attractions`
--

CREATE TABLE `tourism_attractions` (
  `attr_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `tourist_place` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `image_path` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tourwise_traveler_details`
--

CREATE TABLE `tourwise_traveler_details` (
  `id` int(11) NOT NULL,
  `traveler_group_id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `tour_group_id` varchar(20) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `taxation_type` varchar(100) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `relative_honorofic` varchar(20) NOT NULL,
  `relative_name` varchar(100) NOT NULL,
  `relative_relation` varchar(40) NOT NULL,
  `relative_mobile_no` varchar(30) NOT NULL,
  `s_single_bed_room` int(11) NOT NULL,
  `s_double_bed_room` varchar(50) NOT NULL,
  `s_extra_bed` varchar(50) NOT NULL,
  `s_on_floor` varchar(50) NOT NULL,
  `train_expense` decimal(50,2) NOT NULL,
  `train_service_charge` decimal(50,2) NOT NULL,
  `train_taxation_id` int(11) NOT NULL,
  `train_service_tax` decimal(50,2) NOT NULL,
  `train_service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_train_expense` decimal(50,2) NOT NULL,
  `plane_expense` decimal(50,2) NOT NULL,
  `plane_service_charge` decimal(50,2) NOT NULL,
  `plane_taxation_id` varchar(100) NOT NULL,
  `plane_service_tax` decimal(50,2) NOT NULL,
  `plane_service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_plane_expense` decimal(50,2) NOT NULL,
  `cruise_expense` decimal(50,2) NOT NULL,
  `cruise_service_charge` decimal(50,2) NOT NULL,
  `cruise_taxation_id` int(11) NOT NULL,
  `cruise_service_tax` decimal(50,2) NOT NULL,
  `cruise_service_tax_subtotal` decimal(50,2) NOT NULL,
  `total_cruise_expense` decimal(50,2) NOT NULL,
  `total_travel_expense` decimal(50,2) NOT NULL,
  `visa_country_name` varchar(200) NOT NULL,
  `visa_amount` decimal(50,2) NOT NULL,
  `visa_service_charge` decimal(50,2) NOT NULL,
  `visa_taxation_id` int(11) NOT NULL,
  `visa_service_tax` decimal(50,2) NOT NULL,
  `visa_service_tax_subtotal` decimal(50,2) NOT NULL,
  `visa_total_amount` decimal(50,2) NOT NULL,
  `insuarance_company_name` varchar(200) NOT NULL,
  `insuarance_amount` decimal(50,2) NOT NULL,
  `insuarance_service_charge` decimal(50,2) NOT NULL,
  `insuarance_taxation_id` int(11) NOT NULL,
  `insuarance_service_tax` decimal(50,2) NOT NULL,
  `insuarance_service_tax_subtotal` decimal(50,2) NOT NULL,
  `insuarance_total_amount` decimal(50,2) NOT NULL,
  `train_upload_ticket` varchar(300) NOT NULL,
  `plane_upload_ticket` varchar(300) NOT NULL,
  `cruise_upload_ticket` varchar(200) NOT NULL,
  `adult_expense` decimal(50,2) NOT NULL,
  `child_with_bed` decimal(50,2) NOT NULL,
  `child_without_bed` decimal(50,2) NOT NULL,
  `children_expense` decimal(50,2) NOT NULL,
  `infant_expense` decimal(50,2) NOT NULL,
  `tour_fee` decimal(50,2) NOT NULL,
  `repeater_discount` decimal(50,2) NOT NULL,
  `adjustment_discount` decimal(50,2) NOT NULL,
  `tour_fee_subtotal_1` decimal(50,2) NOT NULL,
  `tour_taxation_id` int(11) NOT NULL,
  `service_tax_per` decimal(50,2) NOT NULL,
  `service_tax` text NOT NULL,
  `tour_fee_subtotal_2` decimal(50,2) NOT NULL,
  `net_total` decimal(50,2) NOT NULL,
  `form_date` varchar(20) NOT NULL,
  `current_booked_seats` varchar(400) NOT NULL,
  `special_request` varchar(600) NOT NULL,
  `balance_due_date` varchar(50) NOT NULL,
  `tour_group_status` varchar(30) NOT NULL,
  `unique_timestamp` varchar(600) NOT NULL,
  `reflections` text NOT NULL,
  `basic_amount` decimal(50,2) NOT NULL,
  `roundoff` decimal(50,2) NOT NULL,
  `bsm_values` text NOT NULL,
  `total_discount` decimal(50,2) NOT NULL,
  `currency_code` int(11) NOT NULL,
  `tcs_tax` decimal(50,2) NOT NULL,
  `tcs_per` decimal(50,2) NOT NULL,
  `invoice_pr_id` int(11) NOT NULL,
  `delete_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tour_budget_entities`
--

CREATE TABLE `tour_budget_entities` (
  `entity_id` int(11) NOT NULL,
  `budget_type_id` int(11) NOT NULL,
  `entity_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tour_budget_type`
--

CREATE TABLE `tour_budget_type` (
  `budget_type_id` int(11) NOT NULL,
  `budget_type` varchar(200) NOT NULL,
  `tour_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tour_budget_type`
--

INSERT INTO `tour_budget_type` (`budget_type_id`, `budget_type`, `tour_type`) VALUES
(1, 'Domestic', 'Group Tour'),
(2, 'International', 'Group Tour'),
(3, 'Domestic', 'Package Tour'),
(4, 'International', 'Package Tour');

-- --------------------------------------------------------

--
-- Table structure for table `tour_city_names`
--

CREATE TABLE `tour_city_names` (
  `id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tour_groups`
--

CREATE TABLE `tour_groups` (
  `group_id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `capacity` varchar(100) NOT NULL,
  `feedback_mail_status` varchar(100) NOT NULL,
  `status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tour_groups`
--

INSERT INTO `tour_groups` (`group_id`, `tour_id`, `from_date`, `to_date`, `capacity`, `feedback_mail_status`, `status`) VALUES
(1, 1, '2023-03-03', '2023-03-07', '400', '', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tour_master`
--

CREATE TABLE `tour_master` (
  `tour_id` int(11) NOT NULL,
  `tour_name` varchar(100) NOT NULL,
  `tour_type` varchar(50) NOT NULL,
  `tour_days` varchar(10) NOT NULL,
  `adult_cost` decimal(50,2) NOT NULL,
  `child_with_cost` decimal(50,2) NOT NULL,
  `child_without_cost` decimal(50,2) NOT NULL,
  `children_cost` decimal(50,2) NOT NULL,
  `infant_cost` decimal(50,2) NOT NULL,
  `with_bed_cost` decimal(50,2) NOT NULL,
  `visa_country_name` varchar(200) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `active_flag` varchar(200) NOT NULL,
  `adnary_url` varchar(200) NOT NULL,
  `inclusions` text NOT NULL,
  `exclusions` text NOT NULL,
  `pdf_url` varchar(200) NOT NULL,
  `dest_id` int(11) NOT NULL,
  `dest_image` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tour_master`
--

INSERT INTO `tour_master` (`tour_id`, `tour_name`, `tour_type`, `tour_days`, `adult_cost`, `child_with_cost`, `child_without_cost`, `children_cost`, `infant_cost`, `with_bed_cost`, `visa_country_name`, `company_name`, `active_flag`, `adnary_url`, `inclusions`, `exclusions`, `pdf_url`, `dest_id`, `dest_image`) VALUES
(1, 'Dubai Tour', 'International', '', '60000.00', '4.00', '0.00', '0.00', '4500.00', '5000.00', '', '', 'Active', '', '<ul class=\"no-marg\" style=\"box-sizing: border-box; margin-bottom: 25px; color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; margin-top: 0px !important; margin-right: 0px !important; margin-left: 0px !important;\"><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Accommodation on twin/Double sharing basis in Deluxe hotels.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Return Air fare</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Extra bed for the extra Adult, Child (above 12 yrs) Child without bed (5-11 Yrs) i.e. Per tour cost paid.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Internal transfers &amp; sightseeing by AC vehicle some sightseeings by Non AC small vehicles tour Itinerary.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Food Plan As per tour Itinerary.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Tour Escort.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Per day per person 2 ltrs drinking water bottle. (except Infant).</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Porter charges except itinerary.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Service Charges.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">All meals included (breakfast, lunch, dinner)</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Daily one mineral water</li></ul><br>', '<ul class=\"no-marg\" style=\"box-sizing: border-box; margin-bottom: 25px; color: rgb(51, 51, 51); font-family: Poppins, sans-serif; font-size: 14px; margin-top: 0px !important; margin-right: 0px !important; margin-left: 0px !important;\"><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Accommodation on twin/Double sharing basis in Deluxe hotels.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Return Air fare</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Extra bed for the extra Adult, Child (above 12 yrs) Child without bed (5-11 Yrs) i.e. Per tour cost paid.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Internal transfers &amp; sightseeing by AC vehicle some sightseeings by Non AC small vehicles tour Itinerary.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Food Plan As per tour Itinerary.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Tour Escort.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Per day per person 2 ltrs drinking water bottle. (except Infant).</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Porter charges except itinerary.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Service Charges.</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">All meals included (breakfast, lunch, dinner)</li><li class=\"mg_tp_10\" style=\"box-sizing: border-box; margin-top: 10px;\">Daily one mineral water</li></ul><br>', '', 39, 885);

-- --------------------------------------------------------

--
-- Table structure for table `to_do_entries`
--

CREATE TABLE `to_do_entries` (
  `id` int(11) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `entity_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `train_master`
--

CREATE TABLE `train_master` (
  `train_id` int(11) NOT NULL,
  `tourwise_traveler_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `from_location` varchar(50) NOT NULL,
  `to_location` varchar(50) NOT NULL,
  `train_no` varchar(50) NOT NULL,
  `amount` decimal(50,2) NOT NULL,
  `seats` varchar(20) NOT NULL,
  `train_priority` varchar(200) NOT NULL,
  `train_class` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_master`
--

CREATE TABLE `train_ticket_master` (
  `train_ticket_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `type_of_tour` varchar(100) NOT NULL,
  `basic_fair` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `delivery_charges` decimal(50,2) NOT NULL,
  `gst_on` varchar(100) NOT NULL,
  `service_tax_subtotal` text NOT NULL,
  `net_total` decimal(50,2) NOT NULL,
  `payment_due_date` date NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `refund_net_total` decimal(50,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `emp_id` int(11) NOT NULL,
  `reflections` text NOT NULL,
  `bsm_values` text NOT NULL,
  `roundoff` varchar(10) NOT NULL,
  `invoice_pr_id` int(11) NOT NULL,
  `cancel_flag` int(11) NOT NULL,
  `delete_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_master_entries`
--

CREATE TABLE `train_ticket_master_entries` (
  `entry_id` int(11) NOT NULL,
  `train_ticket_id` int(11) NOT NULL,
  `honorific` varchar(100) NOT NULL,
  `first_name` varchar(300) NOT NULL,
  `middle_name` varchar(300) NOT NULL,
  `last_name` varchar(300) NOT NULL,
  `birth_date` date NOT NULL,
  `adolescence` varchar(100) NOT NULL,
  `coach_number` varchar(100) NOT NULL,
  `seat_number` varchar(100) NOT NULL,
  `ticket_number` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_master_trip_entries`
--

CREATE TABLE `train_ticket_master_trip_entries` (
  `entry_id` int(11) NOT NULL,
  `train_ticket_id` int(11) NOT NULL,
  `travel_datetime` datetime NOT NULL,
  `travel_from` varchar(300) NOT NULL,
  `travel_to` varchar(300) NOT NULL,
  `train_name` varchar(300) NOT NULL,
  `train_no` varchar(300) NOT NULL,
  `ticket_status` varchar(300) NOT NULL,
  `class` varchar(300) NOT NULL,
  `booking_from` varchar(300) NOT NULL,
  `boarding_at` varchar(300) NOT NULL,
  `arriving_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_master_upload_entries`
--

CREATE TABLE `train_ticket_master_upload_entries` (
  `entry_id` int(11) NOT NULL,
  `train_ticket_id` int(11) NOT NULL,
  `train_ticket_url` text NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_payment_master`
--

CREATE TABLE `train_ticket_payment_master` (
  `payment_id` int(11) NOT NULL,
  `train_ticket_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `credit_charges` decimal(50,2) NOT NULL,
  `credit_card_details` varchar(200) NOT NULL,
  `status` varchar(10) NOT NULL,
  `delete_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_refund_entries`
--

CREATE TABLE `train_ticket_refund_entries` (
  `id` int(11) NOT NULL,
  `refund_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_refund_master`
--

CREATE TABLE `train_ticket_refund_master` (
  `refund_id` int(11) NOT NULL,
  `train_ticket_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `train_ticket_vendor`
--

CREATE TABLE `train_ticket_vendor` (
  `vendor_id` int(11) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `email_id` text NOT NULL,
  `mobile_no` text NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `website` varchar(200) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `state_id` int(11) NOT NULL,
  `side` varchar(6) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transport_agency_master`
--

CREATE TABLE `transport_agency_master` (
  `transport_agency_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `transport_agency_name` varchar(200) NOT NULL,
  `mobile_no` text NOT NULL,
  `landline_no` varchar(100) NOT NULL,
  `email_id` text NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(100) NOT NULL,
  `transport_agency_address` varchar(500) NOT NULL,
  `website` varchar(100) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `state_id` int(11) NOT NULL,
  `side` varchar(6) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transport_agency_master`
--

INSERT INTO `transport_agency_master` (`transport_agency_id`, `city_id`, `transport_agency_name`, `mobile_no`, `landline_no`, `email_id`, `contact_person_name`, `immergency_contact_no`, `transport_agency_address`, `website`, `opening_balance`, `service_tax_no`, `active_flag`, `bank_name`, `account_name`, `account_no`, `branch`, `ifsc_code`, `state_id`, `side`, `pan_no`, `as_of_date`) VALUES
(1, 1311, 'Darshan Tours', '+nLvKkvdP4jqlQ==', '', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '', '', '0.00', '', 'Active', '', '', '', '', '', 22, 'Credit', '', '2023-02-13'),
(2, 1311, 'Gargi Tours', '+nLvKkvdP4jqlQ==', '', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '', '', '0.00', '', 'Active', '', '', '', '', '', 22, 'Credit', '', '2023-02-13');

-- --------------------------------------------------------

--
-- Table structure for table `travelers_details`
--

CREATE TABLE `travelers_details` (
  `traveler_id` int(11) NOT NULL,
  `traveler_group_id` int(11) NOT NULL,
  `m_honorific` varchar(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `birth_date` varchar(20) NOT NULL,
  `age` varchar(20) NOT NULL,
  `adolescence` varchar(20) NOT NULL,
  `passport_no` varchar(200) NOT NULL,
  `passport_issue_date` date NOT NULL,
  `passport_expiry_date` date NOT NULL,
  `handover_adnary` varchar(20) NOT NULL,
  `handover_gift` varchar(20) NOT NULL,
  `id_proof_url` text NOT NULL,
  `pan_card_url` text NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `traveler_personal_info`
--

CREATE TABLE `traveler_personal_info` (
  `personal_info_id` int(11) NOT NULL,
  `tourwise_traveler_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `upcoming_tour_offers_master`
--

CREATE TABLE `upcoming_tour_offers_master` (
  `offer_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(700) NOT NULL,
  `valid_date` date NOT NULL,
  `entry_date` date NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_assigned_roles`
--

CREATE TABLE `user_assigned_roles` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `rank` varchar(50) NOT NULL,
  `priority` varchar(50) NOT NULL,
  `description` varchar(400) NOT NULL,
  `icon` text NOT NULL,
  `title` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_assigned_roles`
--

INSERT INTO `user_assigned_roles` (`id`, `role_id`, `name`, `link`, `rank`, `priority`, `description`, `icon`, `title`) VALUES
(4696, 14, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', 'Dashbaord Testing'),
(4697, 14, 'Tour Master', '', '3', '1', '', 'fa fa-book', ''),
(4698, 14, 'Other Masters', 'other_masters/index.php', '3', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(4699, 14, 'Vehicle', 'transport_agency/bus/transport_agency_bus_master_save.php', '3', '2', 'Here we add transport bus name.', 'fa fa-bus', ''),
(4700, 14, 'Group Tours', 'tours/master/index.php', '3', '2', 'This is tour master', 'fa fa-users', ''),
(4701, 14, 'Package Tours', 'custom_packages/master/index.php', '3', '2', 'This is Customized Packages', 'fa fa-user-plus', ''),
(4702, 14, 'Visa', 'visa_master/index.php', '3', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(4703, 14, 'Excursion', 'paid_services/index.php', '3', '2', 'Tour paid services master', 'fa fa-thumb-tack', ''),
(4704, 14, 'B2B Packages', 'b2b_packages/index.php', '3', '2', 'B2B Packages', 'fa fa-eye', ''),
(4705, 14, 'Supplier Packages', 'supplier_packages/index.php', '3', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(8097, 10, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(8098, 10, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(8099, 10, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(8100, 10, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(8101, 10, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(8426, 12, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', ''),
(8427, 12, 'Admin Master', '', '2', '1', '', 'fa fa-user', ''),
(8428, 12, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', ''),
(8429, 12, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(8430, 12, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(8431, 12, 'Tour Master', '', '3', '1', '', 'fa fa-book', ''),
(8432, 12, 'Other Masters', 'other_masters/index.php', '3', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(8433, 12, 'Supplier Master', '', '4', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(8434, 12, 'Hotels', 'hotels/master/index.php', '4', '2', 'This is hotels master.', 'fa fa-bed', ''),
(8435, 12, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '4', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(8436, 12, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '4', '2', 'This ticket vendor', 'fa fa-plane', ''),
(8437, 12, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '4', '2', 'This ticket vendor', 'fa fa-subway', ''),
(8438, 12, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '4', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(8767, 9, 'Dashboard', 'dashboard/dashboard_main.php', '1', '1', '', 'fa fa-tachometer', ''),
(8768, 9, 'Admin Master', '', '2', '1', '', 'fa fa-user', ''),
(8769, 9, 'Locations And Branches', 'branches_and_locations/index.php', '2', '2', 'This is branmches and locations home', 'fa fa-map-marker', ''),
(8770, 9, 'App Settings', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(8771, 9, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(8772, 9, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(8773, 9, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(8774, 9, 'Terms And Conditions', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(8775, 9, 'Financial Year', 'finance_master/financial_year/index.php', '2', '2', 'Financial Year Master information', 'fa fa-calendar-check-o', ''),
(8776, 9, 'Email CMS', 'cms/email/index.php', '2', '2', 'SMS/EMAIL CMS', 'fa fa-list-ul', ''),
(8777, 9, 'Supplier Master', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(8778, 9, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(8779, 9, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(8780, 9, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(8781, 9, 'Car rental', 'car_rental/vendor/index.php', '3', '2', 'Car Rental agency', 'fa fa-car', ''),
(8782, 9, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(8783, 9, 'Flight Ticket', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-plane', ''),
(8784, 9, 'Excursion', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(8785, 9, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-subway', ''),
(8786, 9, 'Train Ticket', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This ticket vendor', 'fa fa-subway', ''),
(8787, 9, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(8788, 9, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(8789, 9, 'Other Suppliers', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(8790, 9, 'Tour Master', '', '4', '1', '', 'fa fa-book', ''),
(8791, 9, 'Other Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(8792, 9, 'Vehicle', 'transport_agency/bus/transport_agency_bus_master_save.php', '4', '2', 'Here we add transport bus name.', 'fa fa-bus', ''),
(8793, 9, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(8794, 9, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user-plus', ''),
(8795, 9, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(8796, 9, 'Excursion', 'paid_services/index.php', '4', '2', 'Tour paid services master', 'fa fa-thumb-tack', ''),
(8797, 9, 'B2B Packages', 'b2b_packages/index.php', '4', '2', 'B2B Packages', 'fa fa-eye', ''),
(8798, 9, 'Supplier Packages', 'supplier_packages/index.php', '4', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(8799, 9, 'Accounting Master', '', '5', '1', 'Accounting master parent', 'fa fa-money', ''),
(8800, 9, 'Bank Master', 'finance_master/bank_master/index.php', '5', '2', 'Bank Master information', 'fa fa-university', ''),
(8801, 9, 'Cheque Clearance', 'finance_master/cheque_clearance/index.php', '5', '2', 'Chque clearance home', 'fa fa-cc', ''),
(8802, 9, 'TAX Amount(%)', 'finance_master/taxation_master/index.php', '5', '2', 'Taxation Master information', 'fa fa-percent', ''),
(8803, 9, 'Group Master', 'finance_master/group_master/index.php', '5', '2', 'Group Master information', 'fa fa-cog', ''),
(8804, 9, 'Ledger Master', 'finance_master/ledger_master/index.php', '5', '2', 'Ledger Master information', 'fa fa-cog', ''),
(8805, 9, 'SAC Master', 'finance_master/sac_master/index.php', '5', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(8806, 9, 'Journal Entries', 'finance_master/journal_entries/index.php', '5', '2', 'Journal Entries information', 'fa fa-list-ol', ''),
(8807, 9, 'CRM Management', '', '6', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(8808, 9, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '6', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(8809, 9, 'Package Quotation', 'package_booking/quotation/home/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8810, 9, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8811, 9, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8812, 9, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '6', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(8813, 9, 'Tour Checklist', 'checklist/index.php', '6', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(8814, 9, 'Hotel Service Voucher', 'package_booking/service_voucher/hotel_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-file-image-o', ''),
(8815, 9, 'Transport Service Voucher', 'package_booking/service_voucher/transport_voucher/index.php', '6', '2', 'This hotel service voucher screen.', 'fa fa-print', ''),
(8816, 9, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '6', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(8817, 9, 'Visa Status', 'visa_status/index.php', '6', '2', 'This is visa status save.', 'fa fa-cc-visa', ''),
(8818, 9, 'Sale', '#', '7', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(8819, 9, 'Group Tour', 'booking/index.php', '7', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(8820, 9, 'Package Tour', 'package_booking/booking/index.php', '7', '2', 'This is Package Booking home Screen.', 'fa fa-user-plus', ''),
(8821, 9, 'Visa', 'visa_passport_ticket/visa/index.php', '7', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(8822, 9, 'Flight Ticket', 'visa_passport_ticket/ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(8823, 9, 'Train Ticket', 'visa_passport_ticket/train_ticket/index.php', '7', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(8824, 9, 'Hotel', 'hotels/booking/index.php', '7', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(8825, 9, 'Bus', 'bus_booking/booking/index.php', '7', '2', 'Bus bookings', 'fa fa-bus', ''),
(8826, 9, 'Car Rental', 'car_rental/booking/index.php', '7', '2', 'Car Rental booking home', 'fa fa-car', ''),
(8827, 9, 'Passport', 'visa_passport_ticket/passport/index.php', '7', '2', 'Passport master home', 'fa fa-id-card-o', ''),
(8828, 9, 'Forex', 'forex/booking/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(8829, 9, 'Excursion', 'excursion/index.php', '7', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(8830, 9, 'Miscellaneous', 'miscellaneous/index.php', '7', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(8831, 9, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(8832, 9, 'Quotation Request', 'vendor/quotation_request/index.php', '8', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(8833, 9, ' Purchase Management', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(8834, 9, ' Cancel And Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(8835, 9, 'Cancel And Refund', '', '9', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(8836, 9, 'Complete Tour Cancel', 'tour_cancelation_and_refund/cancel_tour_main.php', '9', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(8837, 9, 'Complete Tour Refund', 'tour_cancelation_and_refund/refund_tour/refund_cancelled_tour_group.php', '9', '2', 'This is refund of cancelled tour.', 'fa fa-angle-right', ''),
(8838, 9, 'Group Tour Cancel', 'traveler_cancelation_and_refund/traveler_booking_cancelation_select.php', '9', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(8839, 9, 'Group Tour Refund', 'traveler_cancelation_and_refund/refund_canceled_traveler_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(8840, 9, 'Package Tour Cancel', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '9', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(8841, 9, 'Package Tour Refund', 'package_booking/cancel_and_refund/refund/refund_booking_select.php', '9', '2', 'This is refund select page for cancelation of booking.', 'fa fa-angle-right', ''),
(8842, 9, 'Car Rental Refund ', 'car_rental/refund/index.php', '9', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(8843, 9, 'Visa Can / Ref', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '9', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(8844, 9, 'Passport Can / Ref', 'visa_passport_ticket/passport/cancel_and_refund/index.php', '9', '2', 'Passport cancel and refund', 'fa fa-angle-right', ''),
(8845, 9, 'Flight Ticket Can / Ref', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(8846, 9, 'Train Ticket Can / Ref', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '9', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(8847, 9, 'Hotel Can / Ref', 'hotels/cancel_and_refund/index.php', '9', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(8848, 9, 'Bus Can / Ref', 'bus_booking/refund/index.php', '9', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(8849, 9, 'Excursion Can / Ref', 'excursion/cancel_and_refund/index.php', '9', '2', 'Excursion cancel and refund', 'fa fa-angle-right', ''),
(8850, 9, 'Miscellaneous Can / Ref', 'miscellaneous/cancel_and_refund/index.php', '9', '2', 'Miscellaneous cancel and refund', 'fa fa-angle-right', ''),
(8851, 9, 'Receipt', '#', '10', '1', 'This is payment parent menu', 'fa fa-file-text-o', ''),
(8852, 9, 'Group Tour', 'group_tour/payment/index.php', '10', '2', 'This tourist payment installment update form.', 'fa fa-users', ''),
(8853, 9, 'Package Tour', 'package_booking/payments/index.php', '10', '2', 'This form saves package tour payment information.', 'fa fa-user-plus', ''),
(8854, 9, 'Car Rental', 'car_rental/payment/index.php', '10', '2', 'Car Rental booking payment', 'fa fa-car', ''),
(8855, 9, 'Other Receipts', 'other_receipts/index.php', '10', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(8856, 9, 'Payment', '#', '11', '1', 'This is payment parent menu', 'fa fa-money', ''),
(8857, 9, 'Other Expense', 'other_expense/index.php', '11', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(8858, 9, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '11', '2', 'This is booker incentive module', 'fa fa-star', ''),
(8859, 9, 'Airline Topup', 'flight_supplier/index.php', '11', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(8860, 9, 'Visa Topup', 'visa_supplier/index.php', '11', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(8861, 9, 'Bank', '#', '12', '1', 'This is Bank parent menu', 'fa fa-money', ''),
(8862, 9, 'Bank Voucher', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(8863, 9, 'HR Management', '#', '13', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(8864, 9, 'User Attendance', 'employee/salary_and_attendance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(8865, 9, 'Leave Request', 'leave_magt/leave_request/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8866, 9, 'Leave Management', 'leave_magt/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8867, 9, 'Tasks', 'tasks/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8868, 9, 'User Activities', 'daily_activity/index.php', '13', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(8869, 9, 'User Log', 'employee/user_login/index.php', '13', '2', 'This is user login.', 'fa fa-sign-in', ''),
(8870, 9, 'Performance Rating', 'employee/performance/index.php', '13', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(8871, 9, 'MIS Reports', '#', '14', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(8872, 9, 'Tour Report', 'reports/reports_homepage.php', '14', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(8873, 9, 'Business Report', 'reports/business_reports/index.php', '14', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(8874, 9, 'HR Report', 'reports/staff_mgmt/index.php', '14', '2', 'This is performance report menu', 'fa fa-bar-chart', ''),
(8875, 9, 'Account Report', 'finance_master/reports/index.php', '14', '2', 'Finance Reports master', 'fa fa-usd', ''),
(8876, 9, 'Promotion', '#', '15', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(8877, 9, 'SMS Promotion', 'promotional_sms/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(8878, 9, 'Email Promotion', 'promotional_email/index.php', '15', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(8879, 9, 'SightSeeing Attractions', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '15', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(8880, 9, 'Upcoming Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '15', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(8881, 9, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(8882, 9, 'User Manual', 'user_manual/index.html', '16', '2', 'Documentation home', 'fa fa-info', ''),
(8883, 9, 'Ticket Support', 'support/index.html', '16', '2', 'Support System home', 'fa fa-ticket', ''),
(8884, 9, 'Data Backup', 'backup_installer/index.php', '16', '3', 'Data Backup', 'fa fa-download', ''),
(11442, 8, 'Administration', '', '2', '1', 'Administrator Details', 'fa fa-user', ''),
(11443, 8, 'Branches', 'branches_and_locations/index.php', '2', '2', 'Contains Locations and Branches', 'fa fa-map-marker', ''),
(11444, 8, 'Company Profile', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(11445, 8, 'Business Rules', 'business_rules/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(11446, 8, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(11447, 8, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(11448, 8, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(11449, 8, 'Travel T/C', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(11450, 8, 'Email Drafts', 'cms/email/index.php', '2', '2', 'SMS/EMAIL Drafts', 'fa fa-list-ul', ''),
(11451, 8, 'Tour Checklist', 'checklist/entities/index.php', '2', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(11452, 8, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(11453, 8, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(11454, 8, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(11455, 8, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(11456, 8, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-ship', ''),
(11457, 8, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(11458, 8, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(11459, 8, 'Travel And Tours', '', '4', '1', 'Travel and Tour Details', 'fa fa-book', ''),
(11460, 8, 'Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(11461, 8, 'Transfer', 'b2b_transfer/index.php', '4', '2', 'Here we add transfers.', 'fa fa-bus', ''),
(11462, 8, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(11463, 8, 'Activities', 'b2b_excursion/index.php', '4', '2', 'This Activity Master', 'fa fa-thumb-tack', ''),
(11464, 8, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '5', '2', 'This is booker incentive module', 'fa fa-star', ''),
(11465, 8, 'Airline Topup', 'flight_supplier/index.php', '5', '2', 'This is airline supplier module', 'fa fa-handshake-o', ''),
(11466, 8, 'Visa Topup', 'visa_supplier/index.php', '5', '2', 'This is visa supplier module', 'fa fa-handshake-o', ''),
(11467, 8, 'Other Receipts', 'other_receipts/index.php', '5', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(11468, 8, 'CRM', '', '8', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(11469, 8, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '8', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(11470, 8, 'Supplier Quotation', 'vendor/quotation_request/index.php', '8', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(11471, 8, 'Package Quotation', 'package_booking/quotation/home/index.php', '8', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(11472, 8, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '8', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(11473, 8, 'Hotel Quotation', 'hotel_quotation/index.php', '8', '2', 'This is hotel quotation.', 'fa fa-file-text-o', ''),
(11474, 8, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '8', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(11475, 8, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '8', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(11476, 8, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '8', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(11477, 8, 'Inventory', 'inventory/index.php', '8', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(11478, 8, 'Sales', '#', '9', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(11479, 8, 'Group Tour', 'booking/index.php', '9', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(11480, 8, 'Package Tour', 'package_booking/booking/index.php', '9', '2', 'This is Package Booking home Screen.', 'fa fa-user', ''),
(11481, 8, 'Hotel', 'hotels/booking/index.php', '9', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(11482, 8, 'Flight', 'visa_passport_ticket/ticket/index.php', '9', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(11483, 8, 'Train', 'visa_passport_ticket/train_ticket/index.php', '9', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(11484, 8, 'Visa', 'visa_passport_ticket/visa/index.php', '9', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(11485, 8, 'Bus', 'bus_booking/booking/index.php', '9', '2', 'Bus bookings', 'fa fa-bus', ''),
(11486, 8, 'Car Rental', 'car_rental/booking/index.php', '9', '2', 'Car Rental booking home', 'fa fa-car', ''),
(11487, 8, 'Activity', 'excursion/index.php', '9', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(11488, 8, 'Miscellaneous', 'miscellaneous/index.php', '9', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(11489, 8, 'Forex', 'forex/booking/index.php', '9', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(11490, 8, 'Passport', 'visa_passport_ticket/passport/index.php', '9', '2', 'Passport master home', 'fa fa-id-card-o', ''),
(11491, 8, 'Cancel / Refund', '', '10', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(11492, 8, 'Car Rental Refund ', 'car_rental/refund/index.php', '10', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(11493, 8, 'Purchase', '', '11', '1', '', 'fa fa-handshake-o', ''),
(11494, 8, ' Purchase', 'vendor/dashboard/index.php', '11', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(11495, 8, 'HR', '#', '14', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(11496, 8, 'User Activities', 'daily_activity/index.php', '14', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(11497, 8, 'Performance Rating', 'employee/performance/index.php', '14', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(11498, 8, 'Support', '#', '17', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(11499, 4, 'Administration', '', '2', '1', 'Administrator Details', 'fa fa-user', ''),
(11500, 4, 'Branches', 'branches_and_locations/index.php', '2', '2', 'Contains Locations and Branches', 'fa fa-map-marker', ''),
(11501, 4, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(11502, 4, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(11503, 4, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(11504, 4, 'Suppliers', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(11505, 4, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(11506, 4, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(11507, 4, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(11508, 4, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-ship', ''),
(11509, 4, 'Passport', 'visa_passport_ticket/passport/vendor/index.php', '3', '2', 'This passport vendor', 'fa fa-id-card-o', ''),
(11510, 4, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(11511, 4, 'Travel And Tours', '', '4', '1', 'Travel and Tour Details', 'fa fa-book', ''),
(11512, 4, 'Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(11513, 4, 'Transfer', 'b2b_transfer/index.php', '4', '2', 'Here we add transfers.', 'fa fa-bus', ''),
(11514, 4, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(11515, 4, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user', ''),
(11516, 4, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(11517, 4, 'CRM', '', '8', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(11518, 4, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '8', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(11519, 4, 'Supplier Quotation', 'vendor/quotation_request/index.php', '8', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(11520, 4, 'Package Quotation', 'package_booking/quotation/home/index.php', '8', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(11521, 4, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '8', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(11522, 4, 'Hotel Quotation', 'hotel_quotation/index.php', '8', '2', 'This is hotel quotation.', 'fa fa-file-text-o', ''),
(11523, 4, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '8', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(11524, 4, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '8', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(11525, 4, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '8', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(11526, 4, 'Inventory', 'inventory/index.php', '8', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(11527, 4, 'Sales', '#', '9', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(11528, 4, 'Group Tour', 'booking/index.php', '9', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(11529, 4, 'Package Tour', 'package_booking/booking/index.php', '9', '2', 'This is Package Booking home Screen.', 'fa fa-user', ''),
(11530, 4, 'Hotel', 'hotels/booking/index.php', '9', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(11531, 4, 'Flight', 'visa_passport_ticket/ticket/index.php', '9', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(11532, 4, 'Train', 'visa_passport_ticket/train_ticket/index.php', '9', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(11533, 4, 'Visa', 'visa_passport_ticket/visa/index.php', '9', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(11534, 4, 'Bus', 'bus_booking/booking/index.php', '9', '2', 'Bus bookings', 'fa fa-bus', ''),
(11535, 4, 'Car Rental', 'car_rental/booking/index.php', '9', '2', 'Car Rental booking home', 'fa fa-car', ''),
(11536, 4, 'Activity', 'excursion/index.php', '9', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(11537, 4, 'Miscellaneous', 'miscellaneous/index.php', '9', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(11538, 4, 'Forex', 'forex/booking/index.php', '9', '2', 'Foreign exchange booking', 'fa fa-money', ''),
(11539, 4, 'Passport', 'visa_passport_ticket/passport/index.php', '9', '2', 'Passport master home', 'fa fa-id-card-o', ''),
(11540, 4, 'Tasks', 'tasks/index.php', '14', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(11541, 4, 'User Activities', 'daily_activity/index.php', '14', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(12487, 6, 'Administration', '', '2', '1', 'Administrator Details', 'fa fa-user', ''),
(12488, 6, 'Branches', 'branches_and_locations/index.php', '2', '2', 'Contains Locations and Branches', 'fa fa-map-marker', ''),
(12489, 6, 'Company Profile', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(12490, 6, 'Business Rules', 'business_rules/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(12491, 6, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(12492, 6, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(12493, 6, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(12494, 6, 'Travel T/C', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(12495, 6, 'Email Drafts', 'cms/email/index.php', '2', '2', 'SMS/EMAIL Drafts', 'fa fa-list-ul', ''),
(12496, 6, 'Tour Checklist', 'checklist/entities/index.php', '2', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(12497, 6, 'Suppliers', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(12498, 6, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(12499, 6, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(12500, 6, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(12501, 6, 'Vehicle', 'car_rental/vendor/index.php', '3', '2', 'Vehicle agency', 'fa fa-car', ''),
(12502, 6, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(12503, 6, 'Flight', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This is Flight ticket vendor', 'fa fa-plane', ''),
(12504, 6, 'Activities', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(12505, 6, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-ship', ''),
(12506, 6, 'Train', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This is Train ticket vendor', 'fa fa-subway', ''),
(12507, 6, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(12508, 6, 'Others', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(12509, 6, 'Supplier Contracts', 'supplier_packages/index.php', '3', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(12510, 6, 'Travel And Tours', '', '4', '1', 'Travel and Tour Details', 'fa fa-book', ''),
(12511, 6, 'Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(12512, 6, 'Transfer', 'b2b_transfer/index.php', '4', '2', 'Here we add transfers.', 'fa fa-bus', ''),
(12513, 6, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(12514, 6, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user', ''),
(12515, 6, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(12516, 6, 'Activities', 'b2b_excursion/index.php', '4', '2', 'This Activity Master', 'fa fa-thumb-tack', ''),
(12517, 6, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '5', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(12518, 6, 'Supplier Quotation', 'vendor/quotation_request/index.php', '5', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(12519, 6, 'Package Quotation', 'package_booking/quotation/home/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(12520, 6, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(12521, 6, 'Hotel Quotation', 'hotel_quotation/index.php', '5', '2', 'This is hotel quotation.', 'fa fa-file-text-o', ''),
(12522, 6, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(12523, 6, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(12524, 6, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '5', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(12525, 6, 'Inventory', 'inventory/index.php', '5', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(12526, 6, 'Sales', '#', '6', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(12527, 6, 'Group Tour', 'booking/index.php', '6', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(12528, 6, 'Package Tour', 'package_booking/booking/index.php', '6', '2', 'This is Package Booking home Screen.', 'fa fa-user', ''),
(12529, 6, 'Hotel', 'hotels/booking/index.php', '6', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(12530, 6, 'Flight', 'visa_passport_ticket/ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(12531, 6, 'Visa', 'visa_passport_ticket/visa/index.php', '6', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(12532, 6, 'Bus', 'bus_booking/booking/index.php', '6', '2', 'Bus bookings', 'fa fa-bus', ''),
(12533, 6, 'Car Rental', 'car_rental/booking/index.php', '6', '2', 'Car Rental booking home', 'fa fa-car', ''),
(12534, 6, 'Miscellaneous', 'miscellaneous/index.php', '6', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(12535, 6, 'Cancel / Refund', '', '7', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(12536, 6, 'Complete Group Tour', 'tour_cancelation_and_refund/index.php', '7', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(12537, 6, 'Group Tour', 'traveler_cancelation_and_refund/index.php', '7', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(12538, 6, 'Package Tour', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '7', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(12539, 6, 'Car Rental Refund ', 'car_rental/refund/index.php', '7', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(12540, 6, 'Visa', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '7', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(12541, 6, 'Flight', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '7', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(12542, 6, 'Train', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '7', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(12543, 6, 'Hotel', 'hotels/cancel_and_refund/index.php', '7', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(12544, 6, 'Bus', 'bus_booking/refund/index.php', '7', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(12545, 6, 'Activity', 'excursion/cancel_and_refund/index.php', '7', '2', 'Activity cancel and refund', 'fa fa-angle-right', ''),
(12546, 6, 'Miscellaneous', 'miscellaneous/cancel_and_refund/index.php', '7', '2', 'Miscellaneous cancel and refund', 'fa fa-angle-right', ''),
(12547, 6, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(12548, 6, ' Purchase', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(12549, 6, ' Cancel / Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(12550, 6, 'HR', '#', '9', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(12551, 6, 'Attendance', 'employee/salary_and_attendance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(12552, 6, 'Leaves', 'leave_magt/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(12553, 6, 'Tasks', 'tasks/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(12554, 6, 'User Activities', 'daily_activity/index.php', '9', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(12555, 6, 'Performance Rating', 'employee/performance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(12556, 6, 'Log Register', 'employee/user_login/index.php', '9', '2', 'This is user login.', 'fa fa-sign-in', ''),
(12557, 6, 'Promotion', '#', '10', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(12558, 6, 'SMS', 'promotional_sms/index.php', '10', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(12559, 6, 'Email', 'promotional_email/index.php', '10', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(12560, 6, 'SightSeeing', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '10', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(12561, 6, 'Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '10', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(12562, 6, 'Reports', '#', '11', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(12563, 6, 'Sales', 'reports/reports_homepage.php', '11', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(12564, 6, 'Business', 'reports/business_reports/index.php', '11', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(12565, 6, 'HR', 'reports/staff_mgmt/index.php', '11', '2', 'This is performance report menu', 'fa fa-bar-chart', ''),
(12566, 6, 'Accounts', '', '12', '1', 'Accounting master parent', 'fa fa-money', ''),
(12567, 6, 'Ledgers', 'ledgers/index.php', '12', '2', 'Group Master and Ledger Master information', 'fa fa-cog', ''),
(12568, 6, 'Receipt/Payment/JV', 'finance_master/receipt_payment/index.php', '12', '2', 'Receipt/Payment/JV information', 'fa fa-list-ol', ''),
(12569, 6, 'Bank Vouchers', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(12570, 6, 'Clearance', 'finance_master/cheque_clearance/index.php', '12', '2', 'Cheque clearance home', 'fa fa-cc', ''),
(12571, 6, 'Expenses', 'other_expense/index.php', '12', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(12572, 6, 'SAC Code', 'finance_master/sac_master/index.php', '12', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(12573, 6, 'Other Receipts', 'other_receipts/index.php', '12', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(12574, 6, 'Online Leads', 'online_leads/index.php', '15', '1', 'Social Media Leads Retrieval', 'fa fa-phone-square', ''),
(12575, 6, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(12576, 6, 'Beginners Guide', 'beginners_guide.php', '16', '2', 'Training', 'fa fa-book', ''),
(12577, 6, 'Accounts Guide', 'accounts_guide.php', '16', '2', 'Training', 'fa fa-book', ''),
(12578, 6, 'Training', 'dashboard/dashboard_main.php', '16', '2', 'Training', 'fa fa-laptop', ''),
(12579, 6, 'Data Backup', 'backup_installer/index.php', '16', '2', 'Data Backup', 'fa fa-download', ''),
(12855, 3, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(12856, 3, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(12857, 3, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(12858, 3, 'Suppliers', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(12859, 3, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(12860, 3, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(12861, 3, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(12862, 3, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(12863, 3, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-ship', ''),
(12864, 3, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(12865, 3, 'Supplier Contracts', 'supplier_packages/index.php', '3', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(12866, 3, 'Travel And Tours', '', '4', '1', 'Travel and Tour Details', 'fa fa-book', ''),
(12867, 3, 'Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(12868, 3, 'Transfer', 'b2b_transfer/index.php', '4', '2', 'Here we add transfers.', 'fa fa-bus', ''),
(12869, 3, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(12870, 3, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user', ''),
(12871, 3, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(12872, 3, 'Activities', 'b2b_excursion/index.php', '4', '2', 'This Activity Master', 'fa fa-thumb-tack', ''),
(12873, 3, 'CRM', '', '5', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(12874, 3, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '5', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(12875, 3, 'Package Quotation', 'package_booking/quotation/home/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(12876, 3, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(12877, 3, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(12878, 3, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(12879, 3, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '5', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(12880, 3, 'Inventory', 'inventory/index.php', '5', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(12881, 3, 'Sales', '#', '6', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(12882, 3, 'Group Tour', 'booking/index.php', '6', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(12883, 3, 'Package Tour', 'package_booking/booking/index.php', '6', '2', 'This is Package Booking home Screen.', 'fa fa-user', ''),
(12884, 3, 'Hotel', 'hotels/booking/index.php', '6', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(12885, 3, 'Flight', 'visa_passport_ticket/ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(12886, 3, 'Train', 'visa_passport_ticket/train_ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(12887, 3, 'Visa', 'visa_passport_ticket/visa/index.php', '6', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(12888, 3, 'Bus', 'bus_booking/booking/index.php', '6', '2', 'Bus bookings', 'fa fa-bus', ''),
(12889, 3, 'Car Rental', 'car_rental/booking/index.php', '6', '2', 'Car Rental booking home', 'fa fa-car', ''),
(12890, 3, 'Activity', 'excursion/index.php', '6', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(12891, 3, 'Miscellaneous', 'miscellaneous/index.php', '6', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(12892, 3, 'Cancel / Refund', '', '7', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(12893, 3, 'Car Rental Refund ', 'car_rental/refund/index.php', '7', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(12894, 3, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(12895, 3, 'HR', '#', '9', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(12896, 3, 'Attendance', 'employee/salary_and_attendance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(12897, 3, 'Leaves', 'leave_magt/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(12898, 3, 'Tasks', 'tasks/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(12899, 3, 'User Activities', 'daily_activity/index.php', '9', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(12900, 3, 'Performance Rating', 'employee/performance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(12901, 3, 'Log Register', 'employee/user_login/index.php', '9', '2', 'This is user login.', 'fa fa-sign-in', ''),
(12902, 3, 'Promotion', '#', '10', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(12903, 3, 'Reports', '#', '11', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(12904, 3, 'Sales', 'reports/reports_homepage.php', '11', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(12905, 3, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '12', '2', 'This is booker incentive module', 'fa fa-star', ''),
(12906, 3, 'Other Receipts', 'other_receipts/index.php', '12', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(12907, 3, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(13175, 7, 'Administration', '', '2', '1', 'Administrator Details', 'fa fa-user', ''),
(13176, 7, 'Branches', 'branches_and_locations/index.php', '2', '2', 'Contains Locations and Branches', 'fa fa-map-marker', ''),
(13177, 7, 'Company Profile', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(13178, 7, 'Business Rules', 'business_rules/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(13179, 7, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(13180, 7, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(13181, 7, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(13182, 7, 'Travel T/C', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(13183, 7, 'Email Drafts', 'cms/email/index.php', '2', '2', 'SMS/EMAIL Drafts', 'fa fa-list-ul', ''),
(13184, 7, 'Tour Checklist', 'checklist/entities/index.php', '2', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(13185, 7, 'Suppliers', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(13186, 7, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(13187, 7, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(13188, 7, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(13189, 7, 'Vehicle', 'car_rental/vendor/index.php', '3', '2', 'Vehicle agency', 'fa fa-car', ''),
(13190, 7, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(13191, 7, 'Flight', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This is Flight ticket vendor', 'fa fa-plane', ''),
(13192, 7, 'Activities', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(13193, 7, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-ship', ''),
(13194, 7, 'Train', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This is Train ticket vendor', 'fa fa-subway', ''),
(13195, 7, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(13196, 7, 'Others', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(13197, 7, 'Supplier Contracts', 'supplier_packages/index.php', '3', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(13198, 7, 'Travel And Tours', '', '4', '1', 'Travel and Tour Details', 'fa fa-book', ''),
(13199, 7, 'Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(13200, 7, 'Transfer', 'b2b_transfer/index.php', '4', '2', 'Here we add transfers.', 'fa fa-bus', ''),
(13201, 7, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(13202, 7, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user', ''),
(13203, 7, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(13204, 7, 'Activities', 'b2b_excursion/index.php', '4', '2', 'This Activity Master', 'fa fa-thumb-tack', ''),
(13205, 7, 'CRM', '', '5', '1', 'Backoffice parent menu', 'fa fa-refresh', '');
INSERT INTO `user_assigned_roles` (`id`, `role_id`, `name`, `link`, `rank`, `priority`, `description`, `icon`, `title`) VALUES
(13206, 7, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '5', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(13207, 7, 'Supplier Quotation', 'vendor/quotation_request/index.php', '5', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(13208, 7, 'Package Quotation', 'package_booking/quotation/home/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13209, 7, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13210, 7, 'Hotel Quotation', 'hotel_quotation/index.php', '5', '2', 'This is hotel quotation.', 'fa fa-file-text-o', ''),
(13211, 7, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13212, 7, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13213, 7, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '5', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(13214, 7, 'Inventory', 'inventory/index.php', '5', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(13215, 7, 'Sales', '#', '6', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(13216, 7, 'Group Tour', 'booking/index.php', '6', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(13217, 7, 'Package Tour', 'package_booking/booking/index.php', '6', '2', 'This is Package Booking home Screen.', 'fa fa-user', ''),
(13218, 7, 'Hotel', 'hotels/booking/index.php', '6', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(13219, 7, 'Flight', 'visa_passport_ticket/ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(13220, 7, 'Visa', 'visa_passport_ticket/visa/index.php', '6', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(13221, 7, 'Bus', 'bus_booking/booking/index.php', '6', '2', 'Bus bookings', 'fa fa-bus', ''),
(13222, 7, 'Car Rental', 'car_rental/booking/index.php', '6', '2', 'Car Rental booking home', 'fa fa-car', ''),
(13223, 7, 'Miscellaneous', 'miscellaneous/index.php', '6', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(13224, 7, 'Cancel / Refund', '', '7', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(13225, 7, 'Complete Group Tour', 'tour_cancelation_and_refund/index.php', '7', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(13226, 7, 'Group Tour', 'traveler_cancelation_and_refund/index.php', '7', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(13227, 7, 'Package Tour', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '7', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(13228, 7, 'Car Rental Refund ', 'car_rental/refund/index.php', '7', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(13229, 7, 'Visa', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '7', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(13230, 7, 'Flight', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '7', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(13231, 7, 'Train', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '7', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(13232, 7, 'Hotel', 'hotels/cancel_and_refund/index.php', '7', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(13233, 7, 'Bus', 'bus_booking/refund/index.php', '7', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(13234, 7, 'Activity', 'excursion/cancel_and_refund/index.php', '7', '2', 'Activity cancel and refund', 'fa fa-angle-right', ''),
(13235, 7, 'Miscellaneous', 'miscellaneous/cancel_and_refund/index.php', '7', '2', 'Miscellaneous cancel and refund', 'fa fa-angle-right', ''),
(13236, 7, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(13237, 7, ' Purchase', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(13238, 7, ' Cancel / Refund ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(13239, 7, 'HR', '#', '9', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(13240, 7, 'Attendance', 'employee/salary_and_attendance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(13241, 7, 'Leaves', 'leave_magt/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13242, 7, 'Tasks', 'tasks/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13243, 7, 'User Activities', 'daily_activity/index.php', '9', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(13244, 7, 'Performance Rating', 'employee/performance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13245, 7, 'Log Register', 'employee/user_login/index.php', '9', '2', 'This is user login.', 'fa fa-sign-in', ''),
(13246, 7, 'Promotion', '#', '10', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(13247, 7, 'SMS', 'promotional_sms/index.php', '10', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(13248, 7, 'Email', 'promotional_email/index.php', '10', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(13249, 7, 'SightSeeing', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '10', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(13250, 7, 'Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '10', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(13251, 7, 'Reports', '#', '11', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(13252, 7, 'Sales', 'reports/reports_homepage.php', '11', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(13253, 7, 'Business', 'reports/business_reports/index.php', '11', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(13254, 7, 'HR', 'reports/staff_mgmt/index.php', '11', '2', 'This is performance report menu', 'fa fa-users', ''),
(13255, 7, 'Accounts', 'finance_master/reports/index.php', '11', '2', 'Finance Reports master', 'fa fa-usd', ''),
(13256, 7, 'Accounts', '', '12', '1', 'Accounting master parent', 'fa fa-money', ''),
(13257, 7, 'Ledgers', 'ledgers/index.php', '12', '2', 'Group Master and Ledger Master information', 'fa fa-cog', ''),
(13258, 7, 'Receipt/Payment/JV', 'finance_master/receipt_payment/index.php', '12', '2', 'Receipt/Payment/JV information', 'fa fa-list-ol', ''),
(13259, 7, 'Bank Vouchers', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(13260, 7, 'Clearance', 'finance_master/cheque_clearance/index.php', '12', '2', 'Cheque clearance home', 'fa fa-cc', ''),
(13261, 7, 'Expenses', 'other_expense/index.php', '12', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(13262, 7, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '12', '2', 'This is booker incentive module', 'fa fa-star', ''),
(13263, 7, 'SAC Code', 'finance_master/sac_master/index.php', '12', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(13264, 7, 'Other Receipts', 'other_receipts/index.php', '12', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(13265, 7, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(13266, 7, 'Beginners Guide', 'beginners_guide.php', '16', '2', 'Training', 'fa fa-book', ''),
(13267, 7, 'Accounts Guide', 'accounts_guide.php', '16', '2', 'Training', 'fa fa-book', ''),
(13268, 7, 'Training', 'dashboard/dashboard_main.php', '16', '2', 'Training', 'fa fa-laptop', ''),
(13269, 7, 'Data Backup', 'backup_installer/index.php', '16', '2', 'Data Backup', 'fa fa-download', ''),
(13386, 5, 'Administration', '', '2', '1', 'Administrator Details', 'fa fa-user', ''),
(13387, 5, 'Branches', 'branches_and_locations/index.php', '2', '2', 'Contains Locations and Branches', 'fa fa-map-marker', ''),
(13388, 5, 'Company Profile', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(13389, 5, 'Business Rules', 'business_rules/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(13390, 5, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(13391, 5, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(13392, 5, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(13393, 5, 'Travel T/C', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(13394, 5, 'Email Drafts', 'cms/email/index.php', '2', '2', 'SMS/EMAIL Drafts', 'fa fa-list-ul', ''),
(13395, 5, 'Tour Checklist', 'checklist/entities/index.php', '2', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(13396, 5, 'Suppliers', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(13397, 5, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(13398, 5, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(13399, 5, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(13400, 5, 'Vehicle', 'car_rental/vendor/index.php', '3', '2', 'Vehicle agency', 'fa fa-car', ''),
(13401, 5, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(13402, 5, 'Flight', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This is Flight ticket vendor', 'fa fa-plane', ''),
(13403, 5, 'Activities', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(13404, 5, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-ship', ''),
(13405, 5, 'Train', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This is Train ticket vendor', 'fa fa-subway', ''),
(13406, 5, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(13407, 5, 'Others', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(13408, 5, 'Supplier Contracts', 'supplier_packages/index.php', '3', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(13409, 5, 'Travel And Tours', '', '4', '1', 'Travel and Tour Details', 'fa fa-book', ''),
(13410, 5, 'Masters', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(13411, 5, 'Transfer', 'b2b_transfer/index.php', '4', '2', 'Here we add transfers.', 'fa fa-bus', ''),
(13412, 5, 'Group Tours', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(13413, 5, 'Package Tours', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user', ''),
(13414, 5, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(13415, 5, 'Activities', 'b2b_excursion/index.php', '4', '2', 'This Activity Master', 'fa fa-thumb-tack', ''),
(13416, 5, 'CRM', '', '5', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(13417, 5, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '5', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(13418, 5, 'Supplier Quotation', 'vendor/quotation_request/index.php', '5', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(13419, 5, 'Package Quotation', 'package_booking/quotation/home/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13420, 5, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13421, 5, 'Hotel Quotation', 'hotel_quotation/index.php', '5', '2', 'This is hotel quotation.', 'fa fa-file-text-o', ''),
(13422, 5, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13423, 5, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13424, 5, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '5', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(13425, 5, 'Inventory', 'inventory/index.php', '5', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(13426, 5, 'Sales', '#', '6', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(13427, 5, 'Group Tour', 'booking/index.php', '6', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(13428, 5, 'Package Tour', 'package_booking/booking/index.php', '6', '2', 'This is Package Booking home Screen.', 'fa fa-user', ''),
(13429, 5, 'Hotel', 'hotels/booking/index.php', '6', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(13430, 5, 'Flight', 'visa_passport_ticket/ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(13431, 5, 'Train', 'visa_passport_ticket/train_ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(13432, 5, 'Visa', 'visa_passport_ticket/visa/index.php', '6', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(13433, 5, 'Bus', 'bus_booking/booking/index.php', '6', '2', 'Bus bookings', 'fa fa-bus', ''),
(13434, 5, 'Car Rental', 'car_rental/booking/index.php', '6', '2', 'Car Rental booking home', 'fa fa-car', ''),
(13435, 5, 'Activity', 'excursion/index.php', '6', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(13436, 5, 'Miscellaneous', 'miscellaneous/index.php', '6', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(13437, 5, 'Cancel / Refund', '', '7', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(13438, 5, 'Complete Group Tour', 'tour_cancelation_and_refund/index.php', '7', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(13439, 5, 'Group Tour', 'traveler_cancelation_and_refund/index.php', '7', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(13440, 5, 'Package Tour', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '7', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(13441, 5, 'Car Rental Refund ', 'car_rental/refund/index.php', '7', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(13442, 5, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(13443, 5, ' Purchase', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(13444, 5, 'HR', '#', '9', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(13445, 5, 'Attendance', 'employee/salary_and_attendance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(13446, 5, 'Leaves', 'leave_magt/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13447, 5, 'Tasks', 'tasks/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13448, 5, 'Performance Rating', 'employee/performance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13449, 5, 'Log Register', 'employee/user_login/index.php', '9', '2', 'This is user login.', 'fa fa-sign-in', ''),
(13450, 5, 'Promotion', '#', '10', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(13451, 5, 'SMS', 'promotional_sms/index.php', '10', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(13452, 5, 'Email', 'promotional_email/index.php', '10', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(13453, 5, 'SightSeeing', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '10', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(13454, 5, 'Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '10', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(13455, 5, 'Reports', '#', '11', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(13456, 5, 'Sales', 'reports/reports_homepage.php', '11', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(13457, 5, 'Business', 'reports/business_reports/index.php', '11', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(13458, 5, 'HR', 'reports/staff_mgmt/index.php', '11', '2', 'This is performance report menu', 'fa fa-users', ''),
(13459, 5, 'Accounts', 'finance_master/reports/index.php', '11', '2', 'Finance Reports master', 'fa fa-usd', ''),
(13460, 5, 'Accounts', '', '12', '1', 'Accounting master parent', 'fa fa-money', ''),
(13461, 5, 'Ledgers', 'ledgers/index.php', '12', '2', 'Group Master and Ledger Master information', 'fa fa-cog', ''),
(13462, 5, 'Bank Vouchers', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(13463, 5, 'Clearance', 'finance_master/cheque_clearance/index.php', '12', '2', 'Cheque clearance home', 'fa fa-cc', ''),
(13464, 5, 'Expenses', 'other_expense/index.php', '12', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(13465, 5, 'SAC Code', 'finance_master/sac_master/index.php', '12', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(13466, 5, 'Other Receipts', 'other_receipts/index.php', '12', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(13467, 5, 'B2B', '', '13', '1', 'B2B parent menu', 'fa fa-refresh', ''),
(13468, 5, 'Settings', 'b2b_settings/index.php', '13', '2', 'These are initial b2b settings.', 'fa fa-cogs', ''),
(13469, 5, 'Agent', 'b2b_customer/index.php', '13', '2', 'B2B Customers home.', 'fa fa-user-plus', ''),
(13470, 5, 'Quotation', 'b2b_customer/quotation/index.php', '13', '2', 'B2B Quotations home.', 'fa fa-file-text-o', ''),
(13471, 5, 'Hotel Availability', 'b2b_customer/availability_request/index.php', '13', '2', 'B2B Hotel Availability home.', 'fa fa-file-text-o', ''),
(13472, 5, 'Sale', 'b2b_sale/index.php', '13', '2', 'B2B bookings', 'fa fa-user-plus', ''),
(13473, 5, ' Cancel / Refund ', 'b2b_cancel_refund/index.php', '13', '2', 'Cancel and Refund for B2B sales', 'fa fa-undo', ''),
(13474, 5, 'B2C', '', '14', '1', 'B2C parent menu', 'fa fa-refresh', ''),
(13475, 5, 'Settings', 'b2c/index.php', '14', '2', 'These are initial b2b settings.', 'fa fa-cogs', ''),
(13476, 5, 'Quotation', 'b2c/quotations/index.php', '14', '2', 'B2C Quotations home.', 'fa fa-file-text-o', ''),
(13477, 5, 'Sale', 'b2c/sales/index.php', '14', '2', 'B2C bookings', 'fa fa-user-plus', ''),
(13478, 5, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(13479, 5, 'Beginners Guide', 'beginners_guide.php', '16', '2', 'Training', 'fa fa-book', ''),
(13480, 5, 'Accounts Guide', 'accounts_guide.php', '16', '2', 'Training', 'fa fa-book', ''),
(13481, 5, 'Training', 'dashboard/dashboard_main.php', '16', '2', 'Training', 'fa fa-laptop', ''),
(13482, 5, 'Data Backup', 'backup_installer/index.php', '16', '2', 'Data Backup', 'fa fa-download', ''),
(13483, 2, 'Branches', 'branches_and_locations/index.php', '2', '2', 'Contains Locations and Branches', 'fa fa-map-marker', ''),
(13484, 2, 'Company Profile', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(13485, 2, 'Business Rules', 'business_rules/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(13486, 2, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(13487, 2, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(13488, 2, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(13489, 2, 'Travel T/C', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(13490, 2, 'Email Drafts', 'cms/email/index.php', '2', '2', 'SMS/EMAIL Drafts', 'fa fa-list-ul', ''),
(13491, 2, 'Tour Checklist', 'checklist/entities/index.php', '2', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(13492, 2, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(13493, 2, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(13494, 2, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(13495, 2, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-ship', ''),
(13496, 2, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(13497, 2, 'Travel And Tours', '', '4', '1', 'Travel and Tour Details', 'fa fa-book', ''),
(13498, 2, 'Master', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(13499, 2, 'Package Tour', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user', ''),
(13500, 2, 'Group Tour', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(13501, 2, 'Transfer', 'b2b_transfer/index.php', '4', '2', 'Here we add transfers.', 'fa fa-bus', ''),
(13502, 2, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(13503, 2, 'Activity', 'b2b_excursion/index.php', '4', '2', 'This Activity Master', 'fa fa-thumb-tack', ''),
(13504, 2, 'Ferry/Cruise', 'ferry/index.php', '4', '2', 'This Ferry and Tariff Master', 'fa fa-ship', ''),
(13505, 2, 'Rent a Bike', 'rent_bike/index.php', '4', '2', 'This rent a bike master', 'fa fa-motorcycle', ''),
(13506, 2, 'CRM', '', '5', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(13507, 2, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '5', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(13508, 2, 'Supplier Quotation', 'vendor/quotation_request/index.php', '5', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(13509, 2, 'Package Quotation', 'package_booking/quotation/home/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13510, 2, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13511, 2, 'Hotel Quotation', 'hotel_quotation/index.php', '5', '2', 'This is hotel quotation.', 'fa fa-file-text-o', ''),
(13512, 2, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13513, 2, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13514, 2, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '5', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(13515, 2, 'Inventory', 'inventory/index.php', '5', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(13516, 2, 'Sales', '#', '6', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(13517, 2, 'Package Tour', 'package_booking/booking/index.php', '6', '2', 'This is Package Booking home Screen.', 'fa fa-user', ''),
(13518, 2, 'Group Tour', 'booking/index.php', '6', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(13519, 2, 'Hotel', 'hotels/booking/index.php', '6', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(13520, 2, 'Flight', 'visa_passport_ticket/ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(13521, 2, 'Visa', 'visa_passport_ticket/visa/index.php', '6', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(13522, 2, 'Car Rental', 'car_rental/booking/index.php', '6', '2', 'Car Rental booking home', 'fa fa-car', ''),
(13523, 2, 'Activity', 'excursion/index.php', '6', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(13524, 2, 'Train', 'visa_passport_ticket/train_ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(13525, 2, 'Bus', 'bus_booking/booking/index.php', '6', '2', 'Bus bookings', 'fa fa-bus', ''),
(13526, 2, 'Miscellaneous', 'miscellaneous/index.php', '6', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(13527, 2, 'Cancel / Refund', '', '7', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(13528, 2, 'Package Tour', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '7', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(13529, 2, 'Complete Group Tour', 'tour_cancelation_and_refund/index.php', '7', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(13530, 2, 'Group Tour', 'traveler_cancelation_and_refund/index.php', '7', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(13531, 2, 'Hotel', 'hotels/cancel_and_refund/index.php', '7', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(13532, 2, 'Flight', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '7', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(13533, 2, 'Visa', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '7', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(13534, 2, 'Car Rental Refund ', 'car_rental/refund/index.php', '7', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(13535, 2, 'Activity', 'excursion/cancel_and_refund/index.php', '7', '2', 'Activity cancel and refund', 'fa fa-angle-right', ''),
(13536, 2, 'Train', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '7', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(13537, 2, 'Bus', 'bus_booking/refund/index.php', '7', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(13538, 2, 'Miscellaneous', 'miscellaneous/cancel_and_refund/index.php', '7', '2', 'Miscellaneous cancel and refund', 'fa fa-angle-right', ''),
(13539, 2, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(13540, 2, ' Purchase', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(13541, 2, 'HR', '#', '9', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(13542, 2, 'Attendance', 'employee/salary_and_attendance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(13543, 2, 'Leaves', 'leave_magt/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13544, 2, 'Tasks', 'tasks/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13545, 2, 'Performance Rating', 'employee/performance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13546, 2, 'Log Register', 'employee/user_login/index.php', '9', '2', 'This is user login.', 'fa fa-sign-in', ''),
(13547, 2, 'Promotion', '#', '10', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(13548, 2, 'Reports', '#', '11', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(13549, 2, 'Sales', 'reports/reports_homepage.php', '11', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(13550, 2, 'Business', 'reports/business_reports/index.php', '11', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(13551, 2, 'Analysis', 'reports/analysis_reports/index.php', '11', '2', 'Finance Reports master', 'fa fa-pie-chart', ''),
(13552, 2, 'HR', 'reports/staff_mgmt/index.php', '11', '2', 'This is performance report menu', 'fa fa-users', ''),
(13553, 2, 'Accounts', 'finance_master/reports/index.php', '11', '2', 'Finance Reports master', 'fa fa-usd', ''),
(13554, 2, 'Accounts', '', '12', '1', 'Accounting master parent', 'fa fa-money', ''),
(13555, 2, 'Ledgers', 'ledgers/index.php', '12', '2', 'Group Master and Ledger Master information', 'fa fa-cog', ''),
(13556, 2, 'Receipt/Payment/JV', 'finance_master/receipt_payment/index.php', '12', '2', 'Receipt/Payment/JV information', 'fa fa-list-ol', ''),
(13557, 2, 'Bank Vouchers', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(13558, 2, 'Clearance', 'finance_master/cheque_clearance/index.php', '12', '2', 'Cheque clearance home', 'fa fa-cc', ''),
(13559, 2, 'Expenses', 'other_expense/index.php', '12', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(13560, 2, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '12', '2', 'This is booker incentive module', 'fa fa-star', ''),
(13561, 2, 'SAC Code', 'finance_master/sac_master/index.php', '12', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(13562, 2, 'Other Receipts', 'other_receipts/index.php', '12', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(13563, 1, 'Administration', '', '2', '1', 'Administrator Details', 'fa fa-user', ''),
(13564, 1, 'Branches', 'branches_and_locations/index.php', '2', '2', 'Contains Locations and Branches', 'fa fa-map-marker', ''),
(13565, 1, 'Company Profile', 'app_settings/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(13566, 1, 'Business Rules', 'business_rules/index.php', '2', '2', 'These are initial app settings.', 'fa fa-cogs', ''),
(13567, 1, 'Roles', 'other_masters/roles/index.php', '2', '2', 'This is roles', 'fa fa-user', ''),
(13568, 1, 'Users', 'employee/master/index.php', '2', '2', 'This is employee master', 'fa fa-user-plus', ''),
(13569, 1, 'Privileges', 'privileges/index.php', '2', '2', 'This is form where we assign privileges to both user and branches.', 'fa fa-users', ''),
(13570, 1, 'Customers', 'customer_master/index.php', '2', '2', 'Customers home.', 'fa fa-user', ''),
(13571, 1, 'Travel T/C', 'terms_and_conditions/index.php', '2', '2', 'Terms and conditions home', 'fa fa-list-ul', ''),
(13572, 1, 'Email Drafts', 'cms/email/index.php', '2', '2', 'SMS/EMAIL Drafts', 'fa fa-list-ul', ''),
(13573, 1, 'Tour Checklist', 'checklist/entities/index.php', '2', '2', 'This is group tour and package tour checklist.', 'fa fa-list-ul', ''),
(13574, 1, 'Suppliers', '', '3', '1', 'This is vendor master parent menu.', 'fa fa-handshake-o', ''),
(13575, 1, 'Hotels', 'hotels/master/index.php', '3', '2', 'This is hotels master.', 'fa fa-bed', ''),
(13576, 1, 'Transporter', 'transport_agency/master/index.php', '3', '2', 'This is Transport module master.', 'fa fa-car', ''),
(13577, 1, 'DMC', 'dmc/index.php', '3', '2', 'This is main menu of DMC information.', 'fa fa-truck', ''),
(13578, 1, 'Vehicle', 'car_rental/vendor/index.php', '3', '2', 'Vehicle agency', 'fa fa-car', ''),
(13579, 1, 'Visa', 'visa_passport_ticket/visa/vendor/index.php', '3', '2', 'This visa vendor.', 'fa fa-cc-visa', ''),
(13580, 1, 'Flight', 'visa_passport_ticket/ticket/vendor/index.php', '3', '2', 'This is Flight ticket vendor', 'fa fa-plane', ''),
(13581, 1, 'Activities', 'site_seeing/vendor/index.php', '3', '2', 'This Itinerary vendor', 'fa fa-thumb-tack', ''),
(13582, 1, 'Cruise', 'cruise/index.php', '3', '2', 'This Cruise vendor.', 'fa fa-ship', ''),
(13583, 1, 'Train', 'visa_passport_ticket/train_ticket/vendor/index.php', '3', '2', 'This is Train ticket vendor', 'fa fa-subway', ''),
(13584, 1, 'Insurance', 'insuarance_vendor/index.php', '3', '2', 'This insuarance vendor', 'fa fa-shield', ''),
(13585, 1, 'Others', 'other_vendor/index.php', '3', '2', 'Other vendors master', 'fa fa-arrows', ''),
(13586, 1, 'Supplier Contracts', 'supplier_packages/index.php', '3', '2', 'Supplier Packages', 'fa fa-handshake-o', ''),
(13587, 1, 'Travel And Tours', '', '4', '1', 'Travel and Tour Details', 'fa fa-book', ''),
(13588, 1, 'Master', 'other_masters/index.php', '4', '2', 'Here we add other masters like city, airport.', 'fa fa-paw', ''),
(13589, 1, 'Package Tour', 'custom_packages/master/index.php', '4', '2', 'This is Customized Packages', 'fa fa-user', ''),
(13590, 1, 'Group Tour', 'tours/master/index.php', '4', '2', 'This is tour master', 'fa fa-users', ''),
(13591, 1, 'Transfer', 'b2b_transfer/index.php', '4', '2', 'Here we add transfers.', 'fa fa-bus', ''),
(13592, 1, 'Visa', 'visa_master/index.php', '4', '2', 'Visa Master home.', 'fa fa-cc-visa', ''),
(13593, 1, 'Activity', 'b2b_excursion/index.php', '4', '2', 'This Activity Master', 'fa fa-thumb-tack', ''),
(13594, 1, 'Ferry/Cruise', 'ferry/index.php', '4', '2', 'This Ferry and Tariff Master', 'fa fa-ship', ''),
(13595, 1, 'Rent a Bike', 'rent_bike/index.php', '4', '2', 'This rent a bike master', 'fa fa-motorcycle', ''),
(13596, 1, 'CRM', '', '5', '1', 'Backoffice parent menu', 'fa fa-refresh', ''),
(13597, 1, 'Enquiry', 'attractions_offers_enquiry/enquiry/index.php', '5', '2', 'Here we save enquiry information.', 'fa fa-phone-square', ''),
(13598, 1, 'Supplier Quotation', 'vendor/quotation_request/index.php', '5', '2', 'This vendor quotation request.', 'fa fa-calculator', ''),
(13599, 1, 'Package Quotation', 'package_booking/quotation/home/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13600, 1, 'Group Quotation', 'package_booking/quotation/group_tour/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13601, 1, 'Hotel Quotation', 'hotel_quotation/index.php', '5', '2', 'This is hotel quotation.', 'fa fa-file-text-o', ''),
(13602, 1, 'Flight Quotation', 'package_booking/quotation/car_flight/flight/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13603, 1, 'Car Rental Quotation', 'package_booking/quotation/car_flight/car_rental/index.php', '5', '2', 'This package booking quotation genrator home.', 'fa fa-file-text-o', ''),
(13604, 1, 'ID Proof', 'booking_id_proof/upload_id_proof.php', '5', '2', 'This tourist payment installment update form.', 'fa fa-id-card-o', ''),
(13605, 1, 'Inventory', 'inventory/index.php', '5', '2', 'This is Inventory management.', 'fa fa-list-ul', ''),
(13606, 1, 'Sales', '#', '6', '1', 'This is booking parent menu', 'fa fa-credit-card', ''),
(13607, 1, 'Package Tour', 'package_booking/booking/index.php', '6', '2', 'This is Package Booking home Screen.', 'fa fa-user', ''),
(13608, 1, 'Group Tour', 'booking/index.php', '6', '2', 'This is main group booking homepage.', 'fa fa-users', ''),
(13609, 1, 'Hotel', 'hotels/booking/index.php', '6', '2', 'Here we make new hotel booking hotel.', 'fa fa-bed', ''),
(13610, 1, 'Flight', 'visa_passport_ticket/ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-plane', ''),
(13611, 1, 'Visa', 'visa_passport_ticket/visa/index.php', '6', '2', 'Visa master home', 'fa fa-cc-visa', ''),
(13612, 1, 'Car Rental', 'car_rental/booking/index.php', '6', '2', 'Car Rental booking home', 'fa fa-car', ''),
(13613, 1, 'Activity', 'excursion/index.php', '6', '2', 'Foreign exchange booking', 'fa fa-thumb-tack', ''),
(13614, 1, 'Train', 'visa_passport_ticket/train_ticket/index.php', '6', '2', 'Train or Plane Ticket master home', 'fa fa-subway', ''),
(13615, 1, 'Bus', 'bus_booking/booking/index.php', '6', '2', 'Bus bookings', 'fa fa-bus', ''),
(13616, 1, 'Miscellaneous', 'miscellaneous/index.php', '6', '2', 'Miscellaneous bookings', 'fa fa-bed', ''),
(13617, 1, 'Cancel / Refund', '', '7', '1', 'Here we make new hotel booking hotel.', 'fa fa-ban', ''),
(13618, 1, 'Package Tour', 'package_booking/cancel_and_refund/cancel_booking/cancel_booking.php', '7', '2', 'This is cancel package booking.', 'fa fa-angle-right', ''),
(13619, 1, 'Complete Group Tour', 'tour_cancelation_and_refund/index.php', '7', '2', 'This is cancel tour form.', 'fa fa-angle-right', ''),
(13620, 1, 'Group Tour', 'traveler_cancelation_and_refund/index.php', '7', '2', 'This is cancel traveler form.', 'fa fa-angle-right', ''),
(13621, 1, 'Hotel', 'hotels/cancel_and_refund/index.php', '7', '2', 'Hotel booking cancel and refund', 'fa fa-angle-right', ''),
(13622, 1, 'Flight', 'visa_passport_ticket/ticket/cancel_and_refund/index.php', '7', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(13623, 1, 'Visa', 'visa_passport_ticket/visa/cancel_and_refund/index.php', '7', '2', 'Visa cancel and refund', 'fa fa-angle-right', ''),
(13624, 1, 'Car Rental Refund ', 'car_rental/refund/index.php', '7', '2', 'Car Rental refund booking', 'fa fa-angle-right', ''),
(13625, 1, 'Activity', 'excursion/cancel_and_refund/index.php', '7', '2', 'Activity cancel and refund', 'fa fa-angle-right', ''),
(13626, 1, 'Train', 'visa_passport_ticket/train_ticket/cancel_and_refund/index.php', '7', '2', 'Ticket cancel and refund', 'fa fa-angle-right', ''),
(13627, 1, 'Bus', 'bus_booking/refund/index.php', '7', '2', 'This bus booking refund dashboard.', 'fa fa-angle-right', ''),
(13628, 1, 'Miscellaneous', 'miscellaneous/cancel_and_refund/index.php', '7', '2', 'Miscellaneous cancel and refund', 'fa fa-angle-right', ''),
(13629, 1, 'Purchase', '', '8', '1', '', 'fa fa-handshake-o', ''),
(13630, 1, ' Purchase', 'vendor/dashboard/index.php', '8', '2', 'This vendor payment module dashboard.', 'fa fa-shopping-cart', ''),
(13631, 1, ' Purchase Cancel ', 'vendor/refund/index.php', '8', '2', 'This vendor refund module dashboard.', 'fa fa-undo', ''),
(13632, 1, 'HR', '#', '9', '1', 'This is staff mgmt menu', 'fa fa-users', ''),
(13633, 1, 'Attendance', 'employee/salary_and_attendance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-hand-pointer-o', ''),
(13634, 1, 'Leaves', 'leave_magt/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13635, 1, 'Tasks', 'tasks/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13636, 1, 'Daily Activities', 'daily_activity/index.php', '9', '2', 'This is daily activities.', 'fa fa-calendar-check-o', ''),
(13637, 1, 'Performance Rating', 'employee/performance/index.php', '9', '2', 'Here we add and assign tasks to employee.', 'fa fa-thumb-tack', ''),
(13638, 1, 'Log Register', 'employee/user_login/index.php', '9', '2', 'This is user login.', 'fa fa-sign-in', ''),
(13639, 1, 'Promotion', '#', '10', '1', 'This is promotions parent menu', 'fa fa-bullhorn', ''),
(13640, 1, 'SMS', 'promotional_sms/index.php', '10', '2', 'Here we manage promotional sms.', 'fa fa-mobile', ''),
(13641, 1, 'Email', 'promotional_email/index.php', '10', '2', 'Here we manage promotional sms.', 'fa fa-envelope', ''),
(13642, 1, 'SightSeeing', 'attractions_offers_enquiry/forth_coming_attractions/fouth_coming_attractions_master.php', '10', '2', 'This fourth coming attractions master.', 'fa fa-lightbulb-o', ''),
(13643, 1, 'Offers', 'attractions_offers_enquiry/upcoming_tours/upcoming_tours_offer_master.php', '10', '2', 'Upcoming tour offers parent menu.', 'fa fa-gift', ''),
(13644, 1, 'Flyers', 'flyers/index.php', '10', '2', 'Flyers parent menu.', 'fa fa-file-image-o', ''),
(13645, 1, 'Reports', '#', '11', '1', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(13646, 1, 'Sales', 'reports/reports_homepage.php', '11', '2', 'This is MIS parent menu', 'fa fa-pie-chart', ''),
(13647, 1, 'Business', 'reports/business_reports/index.php', '11', '2', 'This is MIS parent menu', 'fa fa-line-chart', ''),
(13648, 1, 'Analysis', 'reports/analysis_reports/index.php', '11', '2', 'Finance Reports master', 'fa fa-pie-chart', ''),
(13649, 1, 'HR', 'reports/staff_mgmt/index.php', '11', '2', 'This is performance report menu', 'fa fa-users', ''),
(13650, 1, 'Accounts', 'finance_master/reports/index.php', '11', '2', 'Finance Reports master', 'fa fa-usd', ''),
(13651, 1, 'Accounts', '', '12', '1', 'Accounting master parent', 'fa fa-money', ''),
(13652, 1, 'Ledgers', 'ledgers/index.php', '12', '2', 'Group Master and Ledger Master information', 'fa fa-cog', ''),
(13653, 1, 'Receipt/Payment/JV', 'finance_master/receipt_payment/index.php', '12', '2', 'Receipt/Payment/JV information', 'fa fa-list-ol', ''),
(13654, 1, 'Bank Vouchers', 'bank_vouchers/index.php', '12', '2', 'Bank Master information', 'fa fa-university', ''),
(13655, 1, 'Clearance', 'finance_master/cheque_clearance/index.php', '12', '2', 'Cheque clearance home', 'fa fa-cc', ''),
(13656, 1, 'Expenses', 'other_expense/index.php', '12', '2', 'This is other expense home.', 'fa fa-building-o', ''),
(13657, 1, 'Sales Incentive', 'booker_incentive/booker_incentive.php', '12', '2', 'This is booker incentive module', 'fa fa-star', ''),
(13658, 1, 'SAC Code', 'finance_master/sac_master/index.php', '12', '2', 'SAC Master information', 'fa fa-list-ol', ''),
(13659, 1, 'Other Receipts', 'other_receipts/index.php', '12', '2', 'Other receipt resources.', 'fa fa-arrows', ''),
(13660, 1, 'B2B', '', '13', '1', 'B2B parent menu', 'fa fa-refresh', ''),
(13661, 1, 'Settings', 'b2b_settings/index.php', '13', '2', 'These are initial b2b settings.', 'fa fa-cogs', ''),
(13662, 1, 'Agent', 'b2b_customer/index.php', '13', '2', 'B2B Customers home.', 'fa fa-user-plus', ''),
(13663, 1, 'Quotation', 'b2b_customer/quotation/index.php', '13', '2', 'B2B Quotations home.', 'fa fa-file-text-o', ''),
(13664, 1, 'Hotel Availability', 'b2b_customer/availability_request/index.php', '13', '2', 'B2B Hotel Availability home.', 'fa fa-file-text-o', ''),
(13665, 1, 'Sale', 'b2b_sale/index.php', '13', '2', 'B2B bookings', 'fa fa-user-plus', ''),
(13666, 1, ' Cancel / Refund ', 'b2b_cancel_refund/index.php', '13', '2', 'Cancel and Refund for B2B sales', 'fa fa-undo', ''),
(13667, 1, 'B2C', '', '14', '1', 'B2C parent menu', 'fa fa-refresh', ''),
(13668, 1, 'Settings', 'b2c/index.php', '14', '2', 'These are initial b2b settings.', 'fa fa-cogs', ''),
(13669, 1, 'Quotation', 'b2c/quotations/index.php', '14', '2', 'B2C Quotations home.', 'fa fa-file-text-o', ''),
(13670, 1, 'Sale', 'b2c/sales/index.php', '14', '2', 'B2C bookings', 'fa fa-user-plus', ''),
(13671, 1, ' Cancel / Refund ', 'b2c/sales/b2c_cancel_refund/index.php', '14', '2', 'Cancel and Refund for B2C sales', 'fa fa-undo', ''),
(13672, 1, 'Support', '#', '16', '1', 'This is promotions parent menu', 'fa fa-question', ''),
(13673, 1, 'Beginners Guide', 'beginners_guide.php', '16', '2', 'Training', 'fa fa-book', ''),
(13674, 1, 'Accounts Guide', 'accounts_guide.php', '16', '2', 'Training', 'fa fa-book', ''),
(13675, 1, 'Training', 'dashboard/dashboard_main.php', '16', '2', 'Training', 'fa fa-laptop', ''),
(13676, 1, 'Data Backup', 'backup_installer/index.php', '16', '2', 'Data Backup', 'fa fa-download', ''),
(13677, 1, 'Tickets', 'ticket_system/index.php', '16', '2', 'Tickets', 'fa fa-laptop', ''),
(13678, 1, 'Library', '#', '17', '1', 'This is library parent menu', 'fa fa-address-book', ''),
(13679, 1, 'Lightshoot', 'https://chrome.google.com/webstore/detail/lightshot-screenshot-tool/mbniclmhobmnbdlbpiphghaielnnpgdp?hl=en', '17', '2', 'Training', 'fa fa-camera-retro', ''),
(13680, 1, 'Awesome Snapshot', 'https://chrome.google.com/webstore/detail/awesome-screenshot-and-sc/nlipoenfbbikpbjkfpfillcgkoblgpmj', '17', '2', 'Training', 'fa fa-camera', ''),
(13681, 1, 'Photoshop', 'https://itwebservice.in/PhotoshopPortable.zip', '17', '2', 'Training', 'fa fa-picture-o', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `log_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `login_date` date NOT NULL,
  `login_time` time NOT NULL,
  `logout_date` date NOT NULL,
  `logout_time` time NOT NULL,
  `status` varchar(200) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `user_ip` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`log_id`, `login_id`, `login_date`, `login_time`, `logout_date`, `logout_time`, `status`, `remark`, `user_ip`) VALUES
(1, 1, '2023-02-13', '20:25:00', '2023-02-21', '10:27:00', 'Present', '', '::1'),
(2, 1, '2023-02-14', '10:46:00', '0000-00-00', '00:00:00', 'Present', '', '45.117.212.246'),
(3, 1, '2023-02-14', '10:47:00', '0000-00-00', '00:00:00', 'Present', '', '103.232.239.50'),
(4, 1, '2023-02-14', '10:49:00', '0000-00-00', '00:00:00', 'Present', '', '103.232.239.50'),
(5, 1, '2023-02-14', '11:15:00', '0000-00-00', '00:00:00', 'Present', '', '103.134.110.20'),
(6, 1, '2023-02-14', '11:16:00', '0000-00-00', '00:00:00', 'Present', '', '106.195.11.135'),
(7, 1, '2023-02-14', '14:04:00', '0000-00-00', '00:00:00', 'Present', '', '114.143.165.42'),
(8, 1, '2023-02-14', '15:18:00', '0000-00-00', '00:00:00', 'Present', '', '152.57.32.19'),
(9, 1, '2023-02-14', '15:41:00', '0000-00-00', '00:00:00', 'Present', '', '114.143.165.42'),
(10, 1, '2023-02-16', '14:13:00', '2023-02-21', '10:27:00', 'Present', '', '::1'),
(11, 1, '2023-02-21', '10:14:00', '2023-02-21', '10:27:00', 'Present', '', '::1'),
(12, 1, '2023-02-21', '10:27:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(13, 1, '2023-02-21', '11:40:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(14, 1, '2023-02-23', '14:10:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(15, 1, '2023-02-23', '14:34:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(16, 1, '2023-02-24', '10:10:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(17, 1, '2023-02-24', '12:27:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(18, 1, '2023-03-01', '15:48:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(19, 1, '2023-03-02', '11:01:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(20, 1, '2023-03-02', '13:25:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(21, 1, '2023-03-03', '08:52:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(22, 1, '2023-03-04', '10:17:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(23, 1, '2023-03-06', '10:58:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(24, 1, '2023-03-06', '16:17:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(25, 1, '2023-03-07', '14:49:00', '0000-00-00', '00:00:00', 'Present', '', '::1'),
(26, 1, '2023-03-07', '15:23:00', '0000-00-00', '00:00:00', 'Present', '', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_type_master`
--

CREATE TABLE `vehicle_type_master` (
  `entry_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `vehicle_type_master`
--

INSERT INTO `vehicle_type_master` (`entry_id`, `type`) VALUES
(1, 'Private Car'),
(2, 'Saloon Car'),
(3, 'Executive Car'),
(4, 'Private MPV'),
(5, 'Mini Van'),
(6, 'Premier Service'),
(7, 'Business Minivan'),
(8, 'Private Minivan'),
(9, 'Private Luxury Car'),
(10, 'Private Minibus');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_advance_master`
--

CREATE TABLE `vendor_advance_master` (
  `payment_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `vendor_type` varchar(200) NOT NULL,
  `vendor_type_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(222) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(2000) NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `remark` text NOT NULL,
  `bank_id` int(11) NOT NULL,
  `payment_evidence_url` text NOT NULL,
  `clearance_status` varchar(200) NOT NULL,
  `created_at` int(11) NOT NULL,
  `ledger_id` int(11) NOT NULL,
  `delete_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_estimate`
--

CREATE TABLE `vendor_estimate` (
  `estimate_id` int(11) NOT NULL,
  `estimate_type` varchar(100) NOT NULL,
  `estimate_type_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `vendor_type` varchar(100) NOT NULL,
  `vendor_type_id` int(11) NOT NULL,
  `remark` text NOT NULL,
  `basic_cost` decimal(50,2) NOT NULL,
  `non_recoverable_taxes` varchar(100) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `other_charges` decimal(50,2) NOT NULL,
  `service_tax_subtotal` varchar(100) NOT NULL,
  `discount` decimal(50,2) NOT NULL,
  `our_commission` decimal(50,2) NOT NULL,
  `tds` decimal(50,2) NOT NULL,
  `net_total` decimal(50,2) NOT NULL,
  `roundoff` varchar(10) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `invoice_proof_url` varchar(500) NOT NULL,
  `invoice_id` varchar(300) NOT NULL,
  `due_date` date NOT NULL,
  `purchase_date` date NOT NULL,
  `reflections` text NOT NULL,
  `cancel_est_flag` int(11) NOT NULL,
  `delete_status` int(11) NOT NULL,
  `cancel_estimate` text NOT NULL,
  `purchase_return` int(11) NOT NULL,
  `tax_refl` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `vendor_estimate`
--

INSERT INTO `vendor_estimate` (`estimate_id`, `estimate_type`, `estimate_type_id`, `branch_admin_id`, `financial_year_id`, `emp_id`, `vendor_type`, `vendor_type_id`, `remark`, `basic_cost`, `non_recoverable_taxes`, `service_charge`, `other_charges`, `service_tax_subtotal`, `discount`, `our_commission`, `tds`, `net_total`, `roundoff`, `cancel_amount`, `total_refund_amount`, `status`, `created_at`, `invoice_proof_url`, `invoice_id`, `due_date`, `purchase_date`, `reflections`, `cancel_est_flag`, `delete_status`, `cancel_estimate`, `purchase_return`, `tax_refl`) VALUES
(1, 'Package Tour', 1, 1, 1, 1, 'DMC Vendor', 4, '', '110000.00', '', '0.00', '0.00', '', '0.00', '0.00', '0.00', '110000.00', '0.00', '0.00', '0.00', '', '2023-02-13 20:54:00', '', '', '2023-02-13', '2023-02-13', '[{\"purchase_sc\":\"\",\"purchase_commission\":\"\",\"purchase_taxes\":\"\",\"purchase_tds\":\"\"}]', 0, 0, '', 0, '[{\"tax_apply_on\":\"\",\"tax_value\":\"\"}]'),
(2, 'Visa Booking', 1, 1, 1, 1, 'Visa Vendor', 2, '', '7000.00', '', '100.00', '0.00', 'CGST:(2.50%):175.00, SGST:(2.50%):175.00', '0.00', '0.00', '0.00', '7450.00', '0.00', '0.00', '0.00', '', '2023-02-15 17:32:00', '', '', '2023-02-15', '2023-02-15', '[{\"purchase_sc\":\"\",\"purchase_commission\":\"\",\"purchase_taxes\":\"145, 146\",\"purchase_tds\":\"\"}]', 0, 0, '', 0, '[{\"tax_apply_on\":\"1\",\"tax_value\":\"CGST:(2.50%):(145)+SGST:(2.50%):(146)\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_hotel_reply_master`
--

CREATE TABLE `vendor_hotel_reply_master` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `hotel_cost` decimal(50,2) NOT NULL,
  `total_cost` decimal(50,2) NOT NULL,
  `enquiry_spec` varchar(200) NOT NULL,
  `created_at` date NOT NULL,
  `created_by` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_login`
--

CREATE TABLE `vendor_login` (
  `login_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `vendor_type` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `active_flag` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `vendor_login`
--

INSERT INTO `vendor_login` (`login_id`, `username`, `password`, `email`, `vendor_type`, `user_id`, `active_flag`) VALUES
(1, 'Travel Boutique Online (TBO)', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'DMC Vendor', 1, 'Active'),
(2, 'Trip Jack', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'DMC Vendor', 2, 'Active'),
(3, 'Rayna Tours', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'DMC Vendor', 3, 'Active'),
(4, 'Gurunath Travels', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'DMC Vendor', 4, 'Active'),
(5, 'Khanna Holidays', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'DMC Vendor', 5, 'Active'),
(6, 'Book My Tour', '+nLvKkvdP4np', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'DMC Vendor', 6, 'Active'),
(7, 'Lets See Tours & Travels', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'DMC Vendor', 7, 'Active'),
(8, 'Darshan Tours', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Transport Vendor', 1, 'Active'),
(9, 'Gargi Tours', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Transport Vendor', 2, 'Active'),
(10, 'Visa Wale.com', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Visa Vendor', 1, 'Active'),
(11, 'BTW Visa', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Visa Vendor', 2, 'Active'),
(12, 'Akbar Travels', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Ticket Vendor', 1, 'Active'),
(13, 'GoIbibo', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Ticket Vendor', 2, 'Active'),
(14, 'Make My Trip', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'DMC Vendor', 8, 'Active'),
(15, 'Yatra.com', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Ticket Vendor', 3, 'Active'),
(16, 'Clear Trip', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Ticket Vendor', 4, 'Active'),
(17, 'Ease My Trip', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Ticket Vendor', 5, 'Active'),
(18, 'Lark Holidays', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Excursion Vendor', 1, 'Active'),
(19, 'Juzgo Holidays', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'DMC Vendor', 9, 'Active'),
(20, 'Travelebay Thaialnd', '+nLvKkvdP4jqlQ==', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', 'Other Vendor', 1, 'Active'),
(21, 'Om Computers', '+nLvKkvdP4jqlQ==', '', 'Other Vendor', 2, 'Active'),
(22, 'Disha Stationery', '+nLvKkvdP4jqlQ==', '', 'Other Vendor', 3, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_payment_master`
--

CREATE TABLE `vendor_payment_master` (
  `payment_id` int(11) NOT NULL,
  `estimate_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `vendor_type` varchar(100) NOT NULL,
  `vendor_type_id` int(11) NOT NULL,
  `estimate_type` varchar(300) NOT NULL,
  `estimate_type_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `remark` text NOT NULL,
  `bank_id` int(11) NOT NULL,
  `payment_evidence_url` text NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` date NOT NULL,
  `delete_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `vendor_payment_master`
--

INSERT INTO `vendor_payment_master` (`payment_id`, `estimate_id`, `financial_year_id`, `branch_admin_id`, `emp_id`, `vendor_type`, `vendor_type_id`, `estimate_type`, `estimate_type_id`, `payment_date`, `payment_mode`, `payment_amount`, `bank_name`, `transaction_id`, `remark`, `bank_id`, `payment_evidence_url`, `clearance_status`, `created_at`, `delete_status`) VALUES
(1, 1, 1, 1, 1, 'DMC Vendor', 4, 'Package Tour', 1, '2023-02-13', 'NEFT', '10000.00', 'ICICI Bank', '365214', '', 2, '', '', '2023-02-13', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vendor_refund_master`
--

CREATE TABLE `vendor_refund_master` (
  `refund_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `estimate_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_reply_master`
--

CREATE TABLE `vendor_reply_master` (
  `id` int(11) NOT NULL,
  `quotation_for` varchar(200) NOT NULL,
  `request_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `transport_cost` decimal(50,2) NOT NULL,
  `excursion_cost` decimal(50,2) NOT NULL,
  `visa_cost` decimal(50,2) NOT NULL,
  `hotel_cost` decimal(50,2) NOT NULL,
  `total_cost` decimal(50,2) NOT NULL,
  `currency_code` int(11) NOT NULL,
  `enquiry_spec` text NOT NULL,
  `created_at` date NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `enquiry_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_request_master`
--

CREATE TABLE `vendor_request_master` (
  `request_id` int(11) NOT NULL,
  `enquiry_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `quotation_for` varchar(100) NOT NULL,
  `city_id` varchar(200) NOT NULL,
  `vendor_city_id` varchar(100) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `tour_type` varchar(100) NOT NULL,
  `quotation_date` date NOT NULL,
  `airport_pickup` varchar(100) NOT NULL,
  `cab_type` varchar(100) NOT NULL,
  `transfer_type` varchar(100) NOT NULL,
  `enquiry_specification` text NOT NULL,
  `dynamic_fields` text NOT NULL,
  `hotel_entries` text NOT NULL,
  `dmc_entries` text NOT NULL,
  `transport_entries` text NOT NULL,
  `excursion_specification` text NOT NULL,
  `bid_status` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_response_entries`
--

CREATE TABLE `vendor_response_entries` (
  `response_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL,
  `services` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `amount` decimal(50,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_type_master`
--

CREATE TABLE `vendor_type_master` (
  `id` int(11) NOT NULL,
  `vendor_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `vendor_type_master`
--

INSERT INTO `vendor_type_master` (`id`, `vendor_type`) VALUES
(1, 'Hotel Vendor'),
(2, 'Transport Vendor'),
(3, 'Car Rental Vendor'),
(4, 'DMC Vendor'),
(5, 'Visa Vendor'),
(7, 'Ticket Vendor'),
(8, 'Excursion Vendor'),
(9, 'Insurance Vendor'),
(10, 'Train Ticket Vendor'),
(11, 'Other Vendor'),
(12, 'Cruise Vendor');

-- --------------------------------------------------------

--
-- Table structure for table `video_itinerary_master`
--

CREATE TABLE `video_itinerary_master` (
  `entry_id` int(11) NOT NULL,
  `dest_id` int(11) NOT NULL,
  `link` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `video_itinerary_master`
--

INSERT INTO `video_itinerary_master` (`entry_id`, `dest_id`, `link`) VALUES
(1, 1, 'https://www.youtube.com/embed/egNQ7NllqeU'),
(2, 2, 'https://www.youtube.com/embed/Jz67tyKrD84'),
(3, 3, 'https://www.youtube.com/embed/3DdwoaN0dY0'),
(4, 4, 'https://www.youtube.com/embed/wAvTzhN0LlI'),
(5, 5, 'https://www.youtube.com/embed/RFgOQWEvFOk'),
(6, 6, 'https://www.youtube.com/embed/wGquh31e-9o'),
(7, 7, 'https://www.youtube.com/embed/54AYUXM7Shw'),
(8, 8, 'https://www.youtube.com/embed/qfhVnaTKKkA'),
(9, 9, 'https://www.youtube.com/embed/H6qVKPq_42w'),
(10, 10, 'https://www.youtube.com/embed/vddyqaIue_Y'),
(11, 11, 'https://www.youtube.com/embed/DqSEeNzhmac'),
(12, 12, 'https://www.youtube.com/embed/P1GUFKitxCg'),
(13, 13, 'https://www.youtube.com/embed/m0ISTkjEgg8'),
(14, 14, 'https://www.youtube.com/embed/MxT231-KiE0'),
(15, 15, 'https://www.youtube.com/embed/pioeECQa8wg'),
(16, 16, 'https://www.youtube.com/embed/9aM6pglkgAM'),
(17, 17, 'https://www.youtube.com/embed/tj_nUUslxTs'),
(18, 18, 'https://www.youtube.com/embed/ITewL50652M'),
(19, 19, 'https://www.youtube.com/embed/OcPdC6GWmi4'),
(20, 20, 'https://www.youtube.com/embed/a2ClIlBTLVo'),
(21, 21, 'https://www.youtube.com/embed/D-ulrnraysY'),
(22, 22, 'https://www.youtube.com/embed/bMlc1FRcuNQ'),
(23, 23, 'https://www.youtube.com/embed/dVeR4DwnKuI'),
(24, 24, 'https://www.youtube.com/embed/x1N6uI11cxM'),
(25, 25, 'https://www.youtube.com/embed/g1Ztu5esAD4'),
(26, 26, 'https://www.youtube.com/embed/lEHcEU7KqL0'),
(27, 27, 'https://www.youtube.com/embed/RlS-CmqyO04'),
(28, 28, 'https://www.youtube.com/embed/2L9tuXdtiXk'),
(29, 29, 'https://www.youtube.com/embed/bAYPTiPjLTE'),
(30, 30, 'https://www.youtube.com/embed/5FWuVs31nYA'),
(31, 31, 'https://www.youtube.com/embed/bJ7WG-F-5zo'),
(32, 32, 'https://www.youtube.com/embed/rf0NiGRP8Us'),
(33, 33, 'https://www.youtube.com/embed/PLggUE1hRUU'),
(34, 34, 'https://www.youtube.com/embed/hqvMgW9Rno4'),
(35, 35, 'https://www.youtube.com/embed/NlGrayYP0f4'),
(36, 36, 'https://www.youtube.com/embed/J6EaQkZV2fA'),
(37, 37, 'https://www.youtube.com/embed/UUveddLw8hM'),
(38, 38, 'https://www.youtube.com/embed/BC1dIquiSY0'),
(39, 39, 'https://www.youtube.com/embed/VnZpFCsHJmA'),
(40, 40, 'https://www.youtube.com/embed/WbtGj2Ch17M'),
(41, 41, 'https://www.youtube.com/embed/pVkvEOFtPZ8'),
(42, 43, 'https://www.youtube.com/embed/4vbIjXEJHnk'),
(43, 44, 'https://www.youtube.com/embed/GtkDRWfWHXo'),
(44, 45, 'https://www.youtube.com/embed/UlBwl4TrbcU'),
(45, 46, 'https://www.youtube.com/embed/sqx9mu9Oibk'),
(46, 47, 'https://www.youtube.com/embed/MvvK26Xb3F0'),
(47, 48, 'https://www.youtube.com/embed/gY_12ukVkKA'),
(48, 49, 'https://www.youtube.com/embed/2dvrLY43awU'),
(49, 50, 'https://www.youtube.com/embed/YgXI1UOE2hY'),
(50, 51, 'https://www.youtube.com/embed/o7ifyH2dYoo'),
(51, 52, 'https://www.youtube.com/embed/ZpaIIyC25NA'),
(52, 53, 'https://www.youtube.com/embed/pkizhhiMDws'),
(53, 54, 'https://www.youtube.com/embed/cXWoEiXAWH8'),
(54, 55, 'https://www.youtube.com/embed/mq3kV3gTf1k'),
(55, 56, 'https://www.youtube.com/embed/fhvbehlXB8c'),
(56, 57, 'https://www.youtube.com/embed/G8AKgXvTcZs'),
(57, 58, 'https://www.youtube.com/embed/Ync6pQg5Z3g'),
(58, 59, 'https://www.youtube.com/embed/hN3Jmm7k7CA'),
(59, 60, 'https://www.youtube.com/embed/ITDgazDqtow'),
(60, 61, 'https://www.youtube.com/embed/7aPX7Y4OVN4'),
(61, 62, 'https://www.youtube.com/embed/1RjrJA7dQ2E'),
(62, 63, 'https://www.youtube.com/embed/K2JMtgBkXS4'),
(63, 64, 'https://www.youtube.com/embed/_J5KNP6d-uE'),
(64, 65, 'https://www.youtube.com/embed/UUH-gLSHhS0'),
(65, 66, 'https://www.youtube.com/embed/7_MuQ7II2xM'),
(66, 67, 'https://www.youtube.com/embed/nxmrvDhrmfM'),
(67, 68, 'https://www.youtube.com/embed/bNMIwXz_Lbs'),
(68, 69, 'https://www.youtube.com/embed/4jQx4IC1OXo'),
(69, 70, 'https://www.youtube.com/embed/JLUXjtrx2zE'),
(70, 71, 'https://www.youtube.com/embed/qnmWIAhKHec'),
(71, 72, 'https://www.youtube.com/embed/gfOU5jdnttM'),
(72, 73, 'https://www.youtube.com/embed/LKn6uMgoQms'),
(73, 74, 'https://www.youtube.com/embed/LErp6xMIdQQ'),
(74, 75, 'https://www.youtube.com/embed/HdBdhB28yIs'),
(75, 76, 'https://www.youtube.com/embed/lRIBgJi2Jrs');

-- --------------------------------------------------------

--
-- Table structure for table `visa_crm_master`
--

CREATE TABLE `visa_crm_master` (
  `entry_id` int(11) NOT NULL,
  `country_id` varchar(200) NOT NULL,
  `visa_type` varchar(200) NOT NULL,
  `fees` decimal(50,2) NOT NULL,
  `markup` decimal(50,2) NOT NULL,
  `time_taken` varchar(200) NOT NULL,
  `upload_url` varchar(200) NOT NULL,
  `upload_url2` varchar(200) NOT NULL,
  `list_of_documents` text NOT NULL,
  `status` int(11) NOT NULL,
  `upload_url3` varchar(200) NOT NULL,
  `upload_url4` varchar(200) NOT NULL,
  `upload_url5` varchar(200) NOT NULL,
  `fees_b2b` varchar(50) DEFAULT NULL,
  `markup_b2b` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `visa_crm_master`
--

INSERT INTO `visa_crm_master` (`entry_id`, `country_id`, `visa_type`, `fees`, `markup`, `time_taken`, `upload_url`, `upload_url2`, `list_of_documents`, `status`, `upload_url3`, `upload_url4`, `upload_url5`, `fees_b2b`, `markup_b2b`) VALUES
(1, 'Afghanistan', 'Tourist Visa', '1250.00', '1200.00', '30 Days', '../../uploads//Visa_document_required//2022//May//18//1652849070/16.-Extension-of-Consultancy-Agreement.pdf', '../../uploads//Visa_document_required//2022//May//03//1651580543/v8.txt', '<span style=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"color:\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" rgb(119,=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" 119,=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" 119);=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" font-family:=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"open=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" sans\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\",=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" sans-serif;=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" font-size:=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" 16px;=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" background-color:=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" rgb(255,=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" 255,=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\" 255);\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"=\"\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\\\\\\\\\"\\\\\\\\\\\\\\\"\"><font face=\"\\\\\\\\\\\\\\\"trebuchet\" ms,=\"\" sans-serif\\\\\\\\\\\\\\\"=\"\">1. Passport<br>2. Photographs<br>3.Â </font><font face=\"\\\\\\\\\\\\\\\"trebuchet\" ms,=\"\" sans-serif\\\\\\\\\\\\\\\"=\"\">Air tickets</font><br></span>', 1, '', '', '', '1201', '1202'),
(2, 'Albania', 'Tourist Visa', '1000.00', '0.00', '30 Days', '', '', '<div>1. One passport-sized photo no older than six months from the date of application.</div><div>2. Photocopy of a valid travel document, (valid for at least three months more than the period of validity of the requested visa).</div><div>3. Travel health insurance documents for the duration of the visa.</div><div>4. Passport.</div><div>5. Document of round-trip ticket booking.</div><div>6. Hotel booking or documents with information regarding the accommodation for the duration of their stay.</div><div>7. Proof that the foreign citizen has sufficient income (bank statements).</div><div>8. Proof of employment from their country of birth or country of residence. In case of this criteria not being met, the foreign citizen has to provide sufficient evidence that they will return to their country of birth or country of residence.</div> ', 1, '', '', '', NULL, NULL),
(3, 'Algeria', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air Ticket</div><div>4. Old Passport</div><div>5. Bank StatementÂ </div> ', 1, '', '', '', NULL, NULL),
(4, 'American Samoa', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<font face=\\\"\\\\\"trebuchet\\\" ms,=\\\"\\\" sans-serif\\\\\\\"=\\\"\\\">1. Passport<br>2. Photographs<br>3.Â </font><font face=\\\"\\\\\"trebuchet\\\" ms,=\\\"\\\" sans-serif\\\\\\\"=\\\"\\\">Air tickets</font> ', 1, '', '', '', NULL, NULL),
(5, 'Andorra', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<font ms,=\\\"\\\\&quot;\\\\&quot;\\\" sans-serif\\\\\\\\\\\\\\\"=\\\"\\\\&quot;\\\\&quot;\\\">1. Passport<br>2. Photographs<br>3.&nbsp;</font><font ms,=\\\"\\\\&quot;\\\\&quot;\\\" sans-serif\\\\\\\\\\\\\\\"=\\\"\\\\&quot;\\\\&quot;\\\">Air tickets</font> ', 1, '', '', '', NULL, NULL),
(6, 'Angola', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old Passport</div><div>3. Photo</div><div>4. Air Ticket</div><div>5. Bank Statement</div><div>6. ID proof of signatory authority person</div><div>7. Yellow Fever vaccination</div><div>8. Police Clearance Certificate PCC</div> ', 1, '', '', '', NULL, NULL),
(7, 'Anguilla', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Filled out and signed Anguilla tourist visa application form.</div><div>2. Original, signed passport with at least 6 months of remaining validity.</div><div>3. Passport-type photographs: 2</div><div>4. Copy of round trip tickets or confirmed itinerary.</div><div>5. Property papers if possible.</div><div>6. Copies of bank statements from the past 3 months.</div><div>7. Most recent federal tax return, including the taxpayer copy (W-2 form).</div><div>8. A letter from your employer/school (on business letterhead, with contact details), stating that a leave of absence has been granted and that you will be returning to&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; your current job. If you are self-employed, include a copy of your business license and tax return. If you are retired please submit proof of your retirement fund.</div><div>9. Copy of the hotel reservations.</div><div>10. If visiting friends or family, you must provide a letter of invitation with the contact information of the host and visitor, purpose and duration of the visit, confirmation of accommodation including the address, signature, and date. You will also need to provide proof of the host\\\'s status in Anguilla ie. copy of their Anguilla passport\\\'s information page, or, if they are not a citizen of Anguilla, copies of their Anguilla residence permit and their national passport\\\'s information pages.</div> ', 1, '', '', '', NULL, NULL),
(8, 'Antarctica', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Return Ticket&nbsp;<br>', 1, '', '', '', NULL, NULL),
(9, 'Antigua And Barbuda', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. ID Information</div><div>2. Personal Details Scan</div><div>3. Letter from Company or School</div><div>4. Vaccinations</div><div>5. Proof of Lodging</div><div>6. Applicant Photo</div><div>7. Onward Ticket</div><div>8. Bank Record</div> ', 1, '', '', '', NULL, NULL),
(10, 'Argentina', 'Tourist Visa', '0.00', '0.00', '90 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air Ticket</div><div>5. Itinerary</div><div>6. Bank Statement</div><div>7. Income tax returns</div><div>8. Credit card</div><div>9. Authority letter&nbsp;</div><div>10. Credit Card Statement</div><div>11. Covering letter from applicant</div><div>12. Leave sanction letter</div><div>13. Company regeistration.</div><div>14. Hotel Voucher</div><div><br></div> ', 1, '', '', '', NULL, NULL),
(11, 'Armenia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air Ticket</div><div>5. Itinerary</div><div>6. Bank Statement</div><div>7. Authority letter</div><div><br></div> ', 1, '', '', '', NULL, NULL),
(12, 'Aruba', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air Ticket</div><div>5. Itinerary</div><div><br></div>', 1, '', '', '', NULL, NULL),
(13, 'Australia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air Ticket</div><div>5. Itinerary</div><div>6. Authority letter</div><div>7. Pan card</div><div>8. Aadhar Card</div><div>9. Covering letter from applicant</div><div>10. Bank statement</div><div>11. Income tax return</div><div>&nbsp;</div>', 1, '', '', '', NULL, NULL),
(14, 'Austria', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air Ticket</div><div>5. Travel Insurence&nbsp;</div><div>6. Bank statement</div><div>7. Income tax return</div><div>8. Itinerary</div><div>9. Hotel voucher</div><div>10. Covering letter from applicant</div>', 1, '', '', '', NULL, NULL),
(15, 'Azerbaijan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Air Ticket', 1, '', '', '', NULL, NULL),
(16, 'Bahamas', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Old passport</div><div>3. Photo</div><div>4. Air Ticket</div><div>5. Bank statement</div><div>6. Itinerary</div>', 1, '', '', '', NULL, NULL),
(17, 'Bahrain', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Hotel voucher</div><div>5. Covering letter from applicant</div><div>6. Bank statement</div>', 1, '', '', '', NULL, NULL),
(18, 'Bangladesh', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Authority letter</div><div>5. Id proof of signatory authority person</div><div>6. Covering letter from applicant</div><div>7. Bank statement</div><div>8. Hotel voucher</div><div><br></div>', 1, '', '', '', NULL, NULL),
(19, 'Barbados', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Valid passport.</div><div>2. Valid return ticket out of the island.</div><div>3. Entry visa.</div><div>4. Your intended address in Barbados.</div><div>5. Arrival card.</div><div>6. Provide the financial means to support yourself for the duration of your stay.</div><div>7. Birth certificate and marriage certificate.</div><div>8. Cover letter addressed to â€˜Chief Immigration Officerâ€™ bearing a return address, phone number, fax number and email address outlining the purpose of the visit, the proposed date of entry and the duration of the visit.</div><div>9. Copy of appointment letter.</div><div>10. An employment letter or letter from school, college or university.</div>', 1, '', '', '', NULL, NULL),
(20, 'Belarus', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air ticket</div><div>5. Travel insurance</div><div>6. Aids certificate</div><div>7. Visa application form</div><div>8. Covering letter from applicant</div><div>9. Bank statement</div><div>10. Income tax return</div><div>11. Hotel voucher</div><div>12. Itinerary</div><div><br></div>', 1, '', '', '', NULL, NULL),
(21, 'Belgium', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air ticket</div><div>5. Travel insurance</div><div>6. Covering letter from applicant</div><div>7. Bank statement</div><div>8. Income tax return</div><div>9. Hotel voucher</div><div>10. Itinerary</div>', 1, '', '', '', NULL, NULL),
(22, 'Belize', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Old passport</div><div>5. Hotel voucher</div><div>6. Income tax returns</div><div>7. Bank statement</div><div>8. Covering letter from applicant</div>', 1, '', '', '', NULL, NULL),
(23, 'Benin', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Air ticket</div><div>3. Hotel voucher</div><div><br></div>', 1, '', '', '', NULL, NULL),
(24, 'Bermuda', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Fully completed visa application form for Bermuda and essential declaration.&nbsp;</div><div>2. Passport size photographs.&nbsp;&nbsp;</div><div>3. Valid national passport and one copy.&nbsp;</div><div>4. Original of valid visa if you\\\'re citizen of another country and one copy.&nbsp;&nbsp;</div><div>5. Your latest bank statement and one copy.&nbsp;</div><div>6. Confirmation letter from your travel insurance of Bermuda showing the coverage and one copy.&nbsp;&nbsp;</div><div>7. Proof of group travel if you\\\'re travelling in group.&nbsp;&nbsp;</div><div>8. Proof of accommodation booking reservation in Bermuda.&nbsp;&nbsp;</div><div>9. Proof of airline ticket reservation for Bermuda and one copy.</div>', 1, '', '', '', NULL, NULL),
(25, 'Bhutan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Prepare an itinerary of your stay and take a print out of your hotel bookings</div><div>2. Take copies of Passport/ Voter ID card&nbsp;</div><div>3. Passport size photographs</div><div><br></div>', 1, '', '', '', NULL, NULL),
(26, 'Bolivia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air ticket</div><div>5. Income tax return</div><div>6. Bank statement</div><div><br></div>', 1, '', '', '', NULL, NULL),
(27, 'Bosnia And Herzegovina', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air ticket</div><div>5. Income tax return</div><div>6. Bank statement</div><div>7. Hotel voucher</div><div>8. Travel insurance</div>', 1, '', '', '', NULL, NULL),
(28, 'Botswana', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Old passport</div><div>5. Itinerary</div><div>6. Covering letter from applicant</div><div>7. Bank statement</div><div>8. Income tax return</div><div>9. Hotel voucher</div><div>10. Sworn statement&nbsp;</div>', 1, '', '', '', NULL, NULL),
(29, 'Bouvet Island', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Old passport</div><div>5. Itinerary</div><div>6. Covering letter from applicant</div><div>7. Bank statement</div><div>8. Income tax return</div><div>9. Hotel voucher</div><div><br></div>', 1, '', '', '', NULL, NULL),
(30, 'Brazil', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air ticket</div><div>5. Yellow ferver vaccination</div><div>6. Covering letter from applicant</div><div>7. Bank statement</div><div>8. Income tax returns</div><div>9. Hotel voucher</div><div>10. Birth certificate</div><div>11. Itinerary</div>', 1, '', '', '', NULL, NULL),
(31, 'British Indian Ocean Territory', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Visa application form</div><div>2. Passport photo</div><div>3. Passport</div><div>4. Previous passport</div><div>5. Residency proof</div><div>6. Proof of funds</div><div>&nbsp; - Personal bank statement</div><div>&nbsp; - Pay slips from employer</div><div>&nbsp; - Proof of accomodation</div><div>&nbsp; - Audited accounts</div><div>&nbsp; - Tax records</div><div>&nbsp; - Credit card limit<br><br></div><div>7. Current Details</div><div>&nbsp; - Employed:</div><div>&nbsp; - A letter from your employer on company letterhead, with contact details, stating that a leave of absence has been granted, purpose and duration of the trip, and that you will be returning to your current job.</div><div>&nbsp; - Current bank statement of the latest 6 months&nbsp;</div><div>&nbsp; - Income Tax Return (ITR)</div><div>&nbsp; - Original pay slips</div><div>&nbsp;&nbsp;</div><div>&nbsp; - Self Employed:</div><div>&nbsp; - Include a copy of your business license</div><div>&nbsp; - Company bank statement of the latest 6 months</div><div>&nbsp; - Income Tax Return (ITR)</div><div><br></div><div>&nbsp; - Student:</div><div>&nbsp; - Submit an official letter from your school indicating that you are in good standing and that you are registered for the upcoming semester.</div><div>&nbsp; - No Object certificate from School or University.</div><div><br></div><div>&nbsp; - Retired:</div><div>&nbsp; - Submit proof of your retirement fund. Yes.<br><br></div><div>8. Travel itinerary&nbsp;</div><div>9. Hotel Bookings</div>', 1, '', '', '', NULL, NULL),
(32, 'Brunei Darussalam', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Old passport</div><div>5. Covering letter from applicant</div><div>6. Bank statement</div><div>7. Hotel voucher</div><div><br></div>', 1, '', '', '', NULL, NULL),
(33, 'Bulgaria', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Old passport</div><div>5. Copies of all pages of passports in color</div><div><br></div>', 1, '', '', '', NULL, NULL),
(34, 'Burkina Faso', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Old passport</div><div>5. Bank statement</div><div>6. Hotel voucher</div><div><br></div>', 1, '', '', '', NULL, NULL),
(35, 'Burundi', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Old passport</div><div>5. Bank statement</div><div>6. Hotel voucher</div><div><br></div>', 1, '', '', '', NULL, NULL),
(36, 'Cambodia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Old passport</div>', 1, '', '', '', NULL, NULL),
(37, 'Cameroon', 'Tourist Visa', '0.00', '0.00', '21 Days', '', '', '<div>A passport with a validity of at least Six (6) months.</div><div>1 recent Passport Size Photograph, 7 cm X 5 cm or 5 cm X 4 cm (with the name of the applicant on the back).</div><div>An International Certificate of Vaccination against Yellow Fever . However, other vaccines and treatment for malaria are recommended.</div><div>A flight ticket or reservation with the passenger(s) name showing entry and&nbsp; return dates.</div><div>A letter of invitation or a certificate of accommodation by your host legalized by competent local Cameroonian administrative authority.&nbsp;</div><div>The letter of invitation should serve as a guarantee for the accommodation of the applicant and/or the care of the applicant during his stay.&nbsp;</div><div>However Cameroonians of origin who may be unable, for various reasons, to obtain a signed letter of invitation,&nbsp; should download and sign the declaration in honour form.</div><div>Proof of means of subsistence: a signed copy of a bank statement indicating a minimum sum of 3000 dollars. However, Cameroonians of origin who have completed the declaration in honour form are exempted from presenting this document.&nbsp;</div><div>Copy of marriage certificate or declaration of common-law union (for persons who are married or in legal cohabitation).</div><div>Parental authorization for children (ages 0 to 14 ) signed in front of a notary or a commissioner of oath / legalized by administrative authorities, if done in Cameroon.</div><div><br></div><div>Complementary information for visa application for children below 14 years:</div><div><br></div><div>Attach photocopy of the passports of the parents of the child/children requesting a visa</div><div>Attach a copy of the birth certificate of the child/children intending to travel</div><div>A separate visa application form must be filled and signed for each child.</div><div><br></div>', 1, '', '', '', NULL, NULL),
(38, 'Canada', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air ticket</div><div>5. Travel insurance</div><div>6. Covering letter from applicant</div><div>7. Bank statement</div><div>8. Income tax returns</div><div>9. Itierary</div><div><br></div>', 1, '', '', '', NULL, NULL),
(39, 'Cape Verde', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. One completed Cape Verde application</div><div>2. Two passport type photos</div><div>3. Physical passport with 6 months validity beyond trip completion and one blank visa page</div><div>4. Non-USA passport holders must provide a copy of green card or US Visa and I-94</div><div>5. One copy of flight itinerary</div>', 1, '', '', '', NULL, NULL),
(40, 'Cayman Islands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Proof of travel arrnagement&nbsp;&nbsp;', 1, '', '', '', NULL, NULL),
(41, 'Central African Republic', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>', 1, '', '', '', NULL, NULL),
(42, 'Chad', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air ticket</div><div>5. Yellow fever vaccination</div>', 1, '', '', '', NULL, NULL),
(43, 'Chile', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old Passport</div><div>3. Photo</div><div>4. Air ticket</div><div>5. Yellow fever vaccination</div><div>6. Police clearance certificate PCC</div><div>7. Hotel voucher</div><div>8. Itinerary</div><div><br></div>', 1, '', '', '', NULL, NULL),
(44, 'China', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Old passport</div><div>4. Covering letter from applicant</div><div>5. Bank statement</div><div>6. Hotel voucher</div><div>7. Air ticket</div><div>8. Balance certificate</div><div>9. Itinerary</div>', 1, '', '', '', NULL, NULL),
(45, 'Christmas Island', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Original, signed passport with at least 6 months of remaining validity.</div><div>2. Passport-type photographs: 2</div><div>3. Photocopies of the passport and ID card. The applicant must provide photocopies of the original passport and ID card, including a copy of all visas (valid and expired).</div><div>4. Proof of status. Copy of registration certificate/copy of visa and copy of work permit(if available).</div><div>5. Itinerary. Copy of round trip tickets or itinerary.</div><div>6. Medical check report. For staying more than 3 months in Australia or aged over 75 applicants, please enclose a chest X-ray check report and medical check receipt of the applicant from one of the designated hospitals. Other applicants who must submit the documents above please check here for the list of the hospital in different regions.</div><div>7. Bank Statement. Copy of a recent bank statement showing proof of sufficient funds.</div><div>8. Employment Letter. A letter from your employer/school (on business letterhead, with contact details), stating that a leave of absence has been granted and that you will be returning to your current job. If you are self-employed, include a copy of your business license and tax return. If you are retired please submit proof of your retirement fund.</div><div>9. Hotel Reservations.Copy of the Hotel Reservations.</div>', 1, '', '', '', NULL, NULL),
(46, 'Cocos (keeling) Islands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. U.S. passport must be valid for 6 months beyond the intended stay.</div><div>2. Complete the online Visa Application Form.</div><div>3. Please send a clear photocopy of your passport information page, including any amendments or name changes.</div>', 1, '', '', '', NULL, NULL),
(47, 'Colombia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Photo</div><div>3. Air ticket</div><div>4. Old passport</div><div>5. Bank statement</div><div>6. Income tax returns</div>', 1, '', '', '', NULL, NULL),
(48, 'Comoros', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old Passport<br>3. Air ticket<div>4. Photos</div>', 1, '', '', '', NULL, NULL),
(49, 'Congo', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Old passport</div><div>3. Photo</div><div>4. Air ticket</div><div>5. Itinerary</div>', 1, '', '', '', NULL, NULL),
(51, 'Cook Islands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months on entry with one blank visa page</div><div>2. Hold proof of sufficient funds</div><div>3. Hold proof of onward/return flights</div><div>4. Hold all documents required for the next destination</div><div>5. Check the latest immunisation requirements at: http://www.safetravel.ch/</div>', 1, '', '', '', NULL, NULL),
(52, 'Costa Rica', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1.&nbsp; Passport<br>2.&nbsp; Photo<br>3.&nbsp; Air Ticket<br>4.&nbsp; Old passport<br>5.&nbsp; Valid visa copies<br><div>&nbsp;</div>', 1, '', '', '', NULL, NULL),
(53, 'Cote D\'ivoire', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport requirement</div><div>2. Cote dIvoire Visa Application Form</div><div>3. Online Payment</div><div>4. Photo Requirements</div><div>5. Letter Of Invitation</div><div>6. Proof of Travel Arrangements</div><div>7. Hotel Confirmation</div><div>8. Medical Requirements</div>', 1, '', '', '', NULL, NULL),
(54, 'Croatia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', 'NA', 1, '', '', '', NULL, NULL),
(55, 'Cuba', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1.&nbsp; Passport<div>2.&nbsp; Photo<br>3.&nbsp; Air ticket<br>4.&nbsp; Old passport<br>5.&nbsp; Bank Statement</div><div>6.&nbsp; Affidavit</div>', 1, '', '', '', NULL, NULL),
(56, 'Cyprus', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Air ticket<br>2. Travel insurance<br>3. Covering letter form applicant<br>4. Bank Statement<br>5. Income tax returns<br>6. Hotel voucher<br>7. Itinerary<br>8. Passport<br>9. Old passport<br>10. Photo', 1, '', '', '', NULL, NULL),
(57, 'Czech Republic', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel Insurance&nbsp;<br>6. Bank statement<br>7. Income tax return<br>8. Itinerary<br>9. Hotel Voucher<br>10. Cover letter from applicant<br>11. NOC letter from parents to child<br>12. NOC letter from parents/husband<div><br></div>', 1, '', '', '', NULL, NULL),
(58, 'Denmark', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Covering letter from applicant<br>7. Bank statement<br>8. Income tax returns<br>9. Itinerary<br>10. Hotel voucher<br>11. NOC letter from parents/husband&nbsp;', 1, '', '', '', NULL, NULL),
(59, 'Djibouti', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>', 1, '', '', '', NULL, NULL),
(60, 'Dominica', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Balance certificate<br>4. Covering letter from applicant<br>&nbsp;', 1, '', '', '', NULL, NULL),
(61, 'Dominican Republic', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport&nbsp;<br>3. Photo<br>4. Air ticket&nbsp;&nbsp;<br>5. Itinerary<br>6. Police clearance certificate pcc<br>7. Covering letter from applicant<br>8. Bank statement<div><br></div>', 1, '', '', '', NULL, NULL),
(62, 'East Timor', 'Tourist Visa', '0.00', '0.00', '10 Days', '', '', '<div>1. Valid Passport</div><div>2. Passport Photos</div><div>3. Proof of Travel Arrangements</div><div>4. Introduction Letter</div><div>5. Properly Completed East Timor Visa Application Form0</div><div>6. Money Order</div>', 1, '', '', '', NULL, NULL),
(63, 'Ecuador', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Air ticket<br>3. Tarvel insurance</div>', 1, '', '', '', NULL, NULL),
(64, 'Egypt', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<div>3. Air ticket<br>4. Old passport</div><div>5. Covering letter from applicant</div><div>6. Bank statement</div><div>7. Income Tax return<br>8. Hotel voucher<br>9. Itinerary</div>', 1, '', '', '', NULL, NULL),
(65, 'El Salvador', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Travel insurance<br>', 1, '', '', '', NULL, NULL),
(66, 'Equatorial Guinea', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. One completed Equatorial Guinea visa application</div><div>2. One passport type photo</div><div>3. One copy of proof of vaccination for yellow fever</div><div>4. Physical passport with 6 months validity beyond trip completion and one blank visa page</div><div>5. Non-USA passport holders must provide a copy of green card or US Visa and I-94</div><div>6. One copy of flight itinerary</div>', 1, '', '', '', NULL, NULL),
(67, 'Eritrea', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Old passport<br>2. Passport<br>3. Photo<div><br></div>', 1, '', '', '', NULL, NULL),
(68, 'Estonia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1.&nbsp; Passport<br>2.&nbsp; Old Passport<br>3.&nbsp; Photo<br>4.&nbsp; Air ticket<div>5.&nbsp; Travel insurance<br>6.&nbsp; Bank statement<br>7.&nbsp; Income tax return</div><div>8.&nbsp; Marriage certificate<br>9.&nbsp; Relationship proof<br>10. Itinerary<br>11. Hotel voucher<br>12. Cover letter from applicant</div>', 1, '', '', '', NULL, NULL),
(69, 'Ethiopia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Yellow fever vaccination&nbsp;<br>5. Old passport<br>6. Polio vaccination<div>7. Covering letter from applicant<br>8. Bank statement</div><div>9. Hotel voucher<br>&nbsp;</div>', 1, '', '', '', NULL, NULL),
(70, 'Falkland Islands (malvinas)', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. A passport valid for the proposed duration of your stay. No additional period of validity beyond this is required.</div><div>2. A return air ticket</div><div>3. Evidence of accommodation with family/friends/hotel/business&nbsp;&nbsp;</div><div>4. Sufficient funds to cover your stay in the Islands</div>', 1, '', '', '', NULL, NULL),
(71, 'Faroe Islands', 'Tourist Visa', '0.00', '0.00', '21 Days', '', '', '1. Passport<br>2. Old Passport<br>3. Air ticket<br>', 1, '', '', '', NULL, NULL),
(72, 'Fiji', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Air ticket<br>3. Hotel voucher<br>4. Bank statement<br>', 1, '', '', '', NULL, NULL),
(73, 'Finland', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance&nbsp;<br>6. Bank statement<br>7. Income tax return<br>8. Itinerary<br>9. Hotel Voucher<br>10. Covering letter from applicant<br>11. NOC letter from parents/husband', 1, '', '', '', NULL, NULL),
(74, 'France', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax return<br>8. Itinerary<br>9. Hotel voucher<br>10. Covering letter from applicant', 1, '', '', '', NULL, NULL),
(75, 'French Guiana', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months on entry with one blank visa page</div><div>2. Hold proof of sufficient funds in the form of a bank statement or cash</div><div>3. Hold proof of onward/return airline tickets</div><div>4. Hold documents showing proof of purpose of trip</div><div>5. Hold all documents required for the next destination</div><div>6. Hold a visa for the next destination, if required</div><div>7. Confirm with their airline that boarding will be permitted without a visa as these conditions are subject to change</div>', 1, '', '', '', NULL, NULL),
(76, 'French Polynesia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid for at least six months beyond your date of country exit and with one blank visa page</div><div>2. Hold proof of onward and return flights</div><div>3. Hold all documents required for the next destination</div><div>4. Hold documents showing proof of travel purpose (e.g. business cover or support letter, conference registrations, etc.)</div><div>5. Hold proof of sufficient funds relative to your intended length of stay</div><div>6. It is recommended that you confirm with your airline that boarding will be permitted without a visa</div>', 1, '', '', '', NULL, NULL),
(77, 'French Southern Territories', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Invitation letter from your family or friends in France with the address and phone number&nbsp; â€“ if applicable</div><div>2. Bank statement of the last 6 months</div><div>3. Passport copies</div>', 1, '', '', '', NULL, NULL),
(78, 'Gabon', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Bank statement<br>5. Police clearance certificate PCC', 1, '', '', '', NULL, NULL),
(79, 'Gambia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Credit card<br>6. Authority letter<div>7. Visa application form<br>8. Bank statement&nbsp;</div>', 1, '', '', '', NULL, NULL),
(80, 'Georgia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Credit card<br>6. Authority letter<br>7. Visa application form<br>8. Bank statement&nbsp;', 1, '', '', '', NULL, NULL),
(81, 'Germany', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<div>7. Income tax returns</div><div>8. Itinerary<br>9. Covering letter from applicant</div>', 1, '', '', '', NULL, NULL),
(82, 'Ghana', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Yellow fever vaccination<br>5. Old passport<br>6. Bank statement<br>7. Cover letter from applicant<br>8. Income tax returns<br>9. Hotel voucher&nbsp;', 1, '', '', '', NULL, NULL);
INSERT INTO `visa_crm_master` (`entry_id`, `country_id`, `visa_type`, `fees`, `markup`, `time_taken`, `upload_url`, `upload_url2`, `list_of_documents`, `status`, `upload_url3`, `upload_url4`, `upload_url5`, `fees_b2b`, `markup_b2b`) VALUES
(83, 'Gibraltar', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months on entry with one blank visa page</div><div>2. Hold proof of sufficient funds</div><div>3. Hold proof of onward/return flights</div><div>4. Hold all documents required for the next destination</div><div>5. Check the latest immunisation requirements at: http://www.safetravel.ch/</div>', 1, '', '', '', NULL, NULL),
(84, 'Greece', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Hotel voucher<br>10. Covering letter from applicant<div>11. NOC letter from parents/husband</div>', 1, '', '', '', NULL, NULL),
(85, 'Greenland', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Itinerary&nbsp;<br>5. Travel Insurance', 1, '', '', '', NULL, NULL),
(86, 'Grenada', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Travel arrangement', 1, '', '', '', NULL, NULL),
(87, 'Guadeloupe', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months on entry with one blank visa page</div><div>2. Hold proof of sufficient funds</div><div>3. Hold proof of onward/return airline tickets</div><div>4. Hold documents showing proof of purpose of trip&nbsp;</div><div>5. Hold all documents required for the next destination</div><div>6. Confirm with their airline that boarding will be permitted without a visa as these conditions are subject to change</div>', 1, '', '', '', NULL, NULL),
(88, 'Guam', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Be travelling aboard a signatory carrier - included in the application pack</div><div>2. Hold a round-trip, non-refundable and non-transferable ticket</div><div>3. Complete and signed the Form I-736 Guam Visa Waiver information provided by the airline</div><div>4. Not travelling owards to another destination in the United States</div><div>5. Not apply for an extension of stay, adjustment of status or change of non-immigrant status</div><div>6. Hold a passport valid at least six months on entry with two blank visa pages</div><div>7. Hold proof of sufficient funds</div>', 1, '', '', '', NULL, NULL),
(89, 'Guatemala', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Bank statement<br>2. Air ticket<br>3. Passport', 1, '', '', '', NULL, NULL),
(90, 'Guinea', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Bank statement<div><br></div>', 1, '', '', '', NULL, NULL),
(91, 'Guinea-bissau', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket', 1, '', '', '', NULL, NULL),
(92, 'Guyana', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Medical reports<br>6. Police clearance certificate PCC<br><div><br></div>', 1, '', '', '', NULL, NULL),
(93, 'Haiti', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Govt id card', 1, '', '', '', NULL, NULL),
(94, 'Heard Island And Mcdonald Islands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Visa Application Form: Complete application form online for Heard Island and McDonald Islands</div><div>2. Passport Photo: Photo must be no older than 6 months</div><div>3. Passport Copy: A clear scan of the information pages of your signed, machine readable passport.&nbsp;</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Provide the pages of your current passport showing your photo, personal details and passport issue and expiry dates.&nbsp;</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Must be valid for six months beyond the expiry date of the visa.</div><div>4. National Identity: Provide a certified copy of your national identity card/s (other than your passport).&nbsp;</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; You must provide a copy of both sides of each card.</div><div>5. Invitation Letter: A letter from your relative or friend or company inviting you to visit and their relationship to you.&nbsp;</div><div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; The letter could state: the purpose of your visit and length of stay, if you will be staying with them, If this person will be paying for your stay, provide proof of their funds.</div><div>6. Previous Visa: Previous visas if available</div><div>7. Proof of Funds: Proof you have enough money for your stay and to leave, such as</div><div>â€¢ personal bank statements</div><div>â€¢ Pay slips from employer</div><div>â€¢ Proof of accomodation</div><div>â€¢ Audited accounts,</div><div>â€¢ Tax records</div><div>â€¢ Credit card limit.</div><div>8. Proof of Return: Proof that you have reasons to return home such as:</div><div>â€¢ A letter from your employer stating you plan to return to your job</div><div>â€¢ Proof that you study at a school, college or university in your home country</div><div>â€¢ Proof that you have immediate family members in your home country(photos, marriage certificates etc)</div><div>â€¢ Proof that you can return home</div><div>â€¢ Proof that you own a house or other major assets in your home country</div><div>9. Travel itinerary: Travel itinerary (travel reservation to and from the country/area in your name, not a ticket)</div>', 1, '', '', '', NULL, NULL),
(95, 'Holy See (vatican City State)', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid for at least six months beyond your date of country exit and with one blank visa page</div><div>2. Hold proof of onward and return flights</div><div>3. Hold all documents required for the next destination</div><div>4. Hold documents showing proof of travel purpose (e.g. business cover or support letter, conference registrations, etc.)</div><div>5. Hold proof of sufficient funds relative to your intended length of stay</div><div>6. It is recommended that you confirm with your airline that boarding will be permitted without a visa</div>', 1, '', '', '', NULL, NULL),
(96, 'Honduras', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Original Passport with at least 6 months validity and minimum 3 blank pages + all old passports if any</div><div>2. 2 Scanned recent colour photograph. (Photo Specification);</div><div>3. Visa Application forms: completed and signed</div><div>4. Personal Covering letter: explaining purpose of travel to the country</div><div>5. Original Bank Statement: stamped &amp; updated for last 3 months with bank seal</div><div>6. Air tickets: proof of return flight tickets from and back to your home country</div><div>7. Hotel reservation: proof of accommodation for your entire stay</div><div>8. Travel Itinerary: day-wise plan outlining all elements of the trip</div>', 1, '', '', '', NULL, NULL),
(97, 'Hong Kong', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Hotel Voucher<br>2. Air ticket<br>3. Passport', 1, '', '', '', NULL, NULL),
(98, 'Hungary', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old Passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Hotel voucher<br>10. Covering letter from applicants', 1, '', '', '', NULL, NULL),
(99, 'Iceland', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<div>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns</div><div>8. Educational document<br>9. Reason letter<br>10. Itinerary<br>11. Hotel voucher<br>12. Copies of all pages of passport in color<br>13. Covering letter from applicant<br>14. NOC letter from parents/husband<br>&nbsp;</div>', 1, '', '', '', NULL, NULL),
(100, 'India', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old Passport<br>3. Photos', 1, '', '', '', NULL, NULL),
(101, 'Indonesia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Bank statement<br>6. Approval for immigration<br>7. Hotel voucher', 1, '', '', '', NULL, NULL),
(102, 'Iran, Islamic Republic Of', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Medical reports<br>6. Bank statement', 1, '', '', '', NULL, NULL),
(103, 'Iraq', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>', 1, '', '', '', NULL, NULL),
(104, 'Ireland', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1.&nbsp; Passport<br>2.&nbsp; Old passport<br>3.&nbsp; Photo<br>4.&nbsp; Air ticket<br>5.&nbsp; Travel insurance<br>6.&nbsp; Covering&nbsp; letter from applicant<div>7.&nbsp; Bank statement<br>8.&nbsp; Income tax returns&nbsp;<br>9.&nbsp; Hotel voucher<br>10. Balance certificate<br>11. NOC letter from parents/husband<br>12. Itinerary&nbsp;</div>', 1, '', '', '', NULL, NULL),
(105, 'Israel', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Covering letter from applicant<br>7. Bank statement<br>8. Income tax returns&nbsp;<br>9. Aadhar card<br>10. Itinerary<br>11. Hotel voucher&nbsp;', 1, '', '', '', NULL, NULL),
(106, 'Italy', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Internal air ticket<br>7. Bank statement<br>8. Income tax returns<br>9. Itinerary<br>10. Hotel voucher<div>11. Covering letter from applicant<br>12. Credit card</div>', 1, '', '', '', NULL, NULL),
(107, 'Jamaica', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Bank statement<div>6. Income tax returns<br>7. Hotel voucher</div>', 1, '', '', '', NULL, NULL),
(108, 'Japan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Covering letter from applicants<br>6. Bank statement<br>7. Income tax returns<br>8. Hotel voucher<br>9. Itinerary&nbsp;<br>', 1, '', '', '', NULL, NULL),
(109, 'Jordan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Air ticket<br>3. Photo<br>4. Old passport<br>5. Covering letter from applicant<br>6. Hotel voucher<div>7. Bank statement<br><br></div>', 1, '', '', '', NULL, NULL),
(110, 'Kazakstan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Covering letter from applicant<br>6. Bank statement<br>7. Income tax returns<br>8. Hotel voucher<br>9. Itinear&nbsp;<br>', 1, '', '', '', NULL, NULL),
(111, 'Kenya', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<div><br></div>', 1, '', '', '', NULL, NULL),
(112, 'Kiribati', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months beyond the period of intended stay, with two blank visa pages</div><div>2. Hold proof of sufficient funds</div><div>3. Hold proof of onward/return airline tickets</div><div>4. Hold proof of purpose of trip</div><div>5. Hold all documents required for the next destination</div><div>6. Hold a visa for the next country, where applicable</div><div>7. Confirm with their airline that boarding will be permitted without a visa as these conditions are subject to change</div>', 1, '', '', '', NULL, NULL),
(113, 'Korea', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Validity - Six months</div><div>3. A photocopy of duly filled visa application form</div><div>4. Two color photographs</div><div>5. Covering letter from the applicant stating the purpose and duration of the visit</div><div>6. Original confirmed return/onward air ticket</div><div>7. Proof of hotel reservation</div><div>8. Original and photocopy of Income Tax Returns and photocopy of pan card</div><div>9. Original and photocopy of Investment documents</div><div>10. All specified documents</div><div>11. Old passports and visa</div><div>12. Copy of leave letters from employer, school or college</div><div>13. Proof of accommodation during entire stay in al Schengen countries</div><div>14. Salary slip for last 6 months</div><div>15. Income tax returns for last 3 years</div><div>16. Travel insurance</div><div>17. Retirement proof/company registration proof/school college ID and copy</div>', 1, '', '', '', NULL, NULL),
(114, 'Kosovo', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. A completed and signed application form. Persons included in the applicantâ€™s travel document shall submit a separate application form. Minors shall submit an application form signed by a person exercising permanent or temporary parental authority or legal guardianship.</div><div>2. A recent (not older than 1 month) photograph in accordance with the international standards as set out in the International Civil Aviation Organization (ICAO) document 9303 Part 1, 6th edition.</div><div>3. A copy of your travel document. Its validity shall extend at least three months after the intended date of departure from the territory of the Republic of Kosovo. It shall contain at least two blank pages.</div><div>4. documents indicating the purpose of the journey.</div><div>5. documents in relation to accommodation, or proof of sufficient means to cover his/her accommodation;</div><div>6. documents indicating that the applicant possesses sufficient means of subsistence both for the duration of the intended stay and for the return to his country of origin or residence, or for the transit to a third country into which he is certain to be admitted, or that he is in a position to acquire such means lawfully;</div><div>7. Information enabling an assessment of the applicantâ€™s intention to leave the territory of the Republic of Kosovo before the expiry of the visa applied for.</div><div>8. Travel medical insurance valid throughout the territory of the Republic of Kosovo which covers the entire period of the personâ€™s intended stay or transit.</div><div>9. The visa fee payment of 40 EUR that applicants need to pay unless they are holders of diplomatic and official passports; children nder six (6) years old; or school children, students and teachers accompanying and visiting for studying or training purposes.</div>', 1, '', '', '', NULL, NULL),
(115, 'Kuwait', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Pan card', 1, '', '', '', NULL, NULL),
(116, 'Kyrgyzstan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Bank statement<br>6. Covering letter from applicant<br>7. Hotel vocuher&nbsp;', 1, '', '', '', NULL, NULL),
(117, 'Lao Peoples Democratic Republic', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket', 1, '', '', '', NULL, NULL),
(118, 'Latvia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance&nbsp;<br>6. Bank statement</div><div>7. Income tax returns<br>8. Itinerary<br>9. Hotel voucher<br>10. Covering&nbsp; letter from applicant&nbsp;&nbsp;</div>', 1, '', '', '', NULL, NULL),
(119, 'Lebanon', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Authority letter<div>6. Covering letter from applicant<br>7. Income tax returns&nbsp;<br>8. Hotel voucher&nbsp;<br>9. Bank statement&nbsp;</div>', 1, '', '', '', NULL, NULL),
(120, 'Lesotho', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Confirmed paid Return Itinerary or Ticket</div><div>3. Invitation Letter</div><div>4. Introduction Letter</div><div>5. Bank Statement</div><div>6. Immunization Card</div><div>7. Travel Insurance</div><div>8. Other Document</div>', 1, '', '', '', NULL, NULL),
(121, 'Liberia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Travel insurance', 1, '', '', '', NULL, NULL),
(122, 'Libyan Arab Jamahiriya', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Two completed Libya visa applications</div><div>2. Two passport type photos</div><div>3. One copy of proof of vaccination for yellow fever</div><div>4. Physical passport with 6 months validity beyond trip completion and one blank visa page</div><div>5. Non-USA passport holders must provide a copy of green card or US Visa and I-94</div><div>6. Authorization from your host that was provided by the Libya Ministry of Foreign Affairs</div><div>7. One copy of flight itinerary</div>', 1, '', '', '', NULL, NULL),
(123, 'Liechtenstein', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old Passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Internal air ticket<br>7. Bank statement<br>8. Income tax returns<br>9. Itineary&nbsp;<br>&nbsp;', 1, '', '', '', NULL, NULL),
(124, 'Lithuania', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Covering letter from applicant<br>10. Hotel voucher<br>11. NOC letter from parents/husband&nbsp;<br>', 1, '', '', '', NULL, NULL),
(125, 'Luxembourg', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance&nbsp;<br>6. Bank statement<br>7. Income tax returns&nbsp;<br>8. Itinearny<br>', 1, '', '', '', NULL, NULL),
(126, 'Macau', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. A completed Macau Visa Application Form;&nbsp;</div><div>2. Photocopies of the bio data page and used inside pages of a valid passport/travel document.</div><div>3. Document of financial status (e.g. bank statement, deposit in savings account, tax payment receipt, employment certificate, etc.)</div><div>4. Document of transportation to Macao and accommodation arrangement (e.g. round-trip air ticket and hotel room reservation receipts, etc.)</div><div>5. Pages carrying important information in a travel document previously used to come to Macao (if any);</div><div>6. Valid entry visa or residence visa/permit of other countries or regions (if any);</div><div>7. Recent 1.5-inch full face white background color photo.</div><div>8. Proof of purpose of visit, such as:</div><div>Leisure â€“ Tour receipt, itinerary, etc.;</div><div>Family visit â€“ Photocopy of residence/stay document of family in Macao;</div><div>Study â€“ Admission document of a higher institute in Macao;</div><div>Employment â€“ Employment approval document of Macao authorities;</div><div>Residence on dependant basis â€“ Macao identity card of family, document of kinship, etc.;</div><div>Stay as relative of non-resident worker â€“ Approval document of Macao authorities;</div>', 1, '', '', '', NULL, NULL),
(127, 'Macedonia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Bank statement<br>5. Travel insurance', 1, '', '', '', NULL, NULL),
(128, 'Madagascar', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Bank statement<br>5. Air ticket<br>6. Aadhar card<br>7. Pan card<br>8. Covering letter from applicant<br>9. Hotel voucher&nbsp;', 1, '', '', '', NULL, NULL),
(129, 'Malawi', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Bank statement<br>6. Itinerary<br>7. Covering letter from applicant<br>8. Hotel voucher&nbsp;&nbsp;', 1, '', '', '', NULL, NULL),
(130, 'Malaysia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Covering letter from applicant<br>5. Bank statement&nbsp;<br>6. Hotel voucher<br>7. NOC letter from parents/husband<br>8. Itinerary<div>9. Govt id card<br>10. Valid visa copies<br>11. Forex receipt&nbsp;<br>12. Visa application form<br><div><br></div></div>', 1, '', '', '', NULL, NULL),
(131, 'Maldives', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Air ticket<br>3. Bank statement<br>4. Hotel voucher<br>', 1, '', '', '', NULL, NULL),
(132, 'Mali', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br><div>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Bank statement<br><br></div>', 1, '', '', '', NULL, NULL),
(133, 'Malta', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Balance certificate<br>9. Aadhar card<br>10. Itinerary<br>11. Covering letter from applicant<br>12. NOC letter from parents/husband', 1, '', '', '', NULL, NULL),
(134, 'Marshall Islands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket', 1, '', '', '', NULL, NULL),
(135, 'Martinique', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months on entry with two blank visa pages</div><div>2. Hold proof of sufficient funds</div><div>3. Hold proof of onward/return airline tickets</div><div>4. Hold all documents required for the next destination</div><div>5. Confirm with their airline that boarding will be permitted without a visa as these conditions are subject to change</div>', 1, '', '', '', NULL, NULL),
(136, 'Mauritania', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Requires proof of transportation(round-trip ticket),letter of financial solvency from bank, proof of employment and an invitation letter.</div><div>2. A valid passport</div><div>3. Completed and signed applications forms</div><div>4. Passport-sized photographs</div>', 1, '', '', '', NULL, NULL),
(137, 'Mauritius', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Air ticket<br>3. Hotel voucher<br>4. Photo<br>5. Forex receipt<br>6. Credit card', 1, '', '', '', NULL, NULL),
(138, 'Mayotte', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport Requirements</div><div>2. Document Validity</div><div>3. Visa Issuance</div><div>4. Visa Exemptions</div><div>5. TWOV (Transit Without Visa)</div><div>6. Baggage Clearance regulations</div><div>7. Airport tax</div><div>8. Rules of Currency Import &amp; Export:</div>', 1, '', '', '', NULL, NULL),
(139, 'Mexico', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Marriage certificate<br>6. Birth certificate<br>7. Covering letter from applicant<br>8. Bank statement<br>9. Income tax returns', 1, '', '', '', NULL, NULL),
(140, 'Micronesia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Air ticket', 1, '', '', '', NULL, NULL),
(141, 'Moldova', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Original Passport with at least 6 months validity and minimum 3 blank pages + all old passports if any</div><div>2. 2 Scanned recent colour photograph. (Photo Specification);</div><div>3. Visa Application forms: completed and signed</div><div>4. Personal Covering letter: explaining purpose of travel to the country</div><div>5. Proof of Financial subsistence: during the stay in Moldova, at least 30 EUR per day, but not less than 300 EUR for a stay shorter than 10 days (cash, travel checks, credit card, etc.)</div><div>6. Air tickets: proof of return flight tickets from and back to your home country</div><div>7. Hotel reservation: proof of accommodation for your entire stay</div><div>8. Travel Insurance: with minimum coverage of EUR 30000 and valid for entire duration of stay</div>', 1, '', '', '', NULL, NULL),
(142, 'Monaco', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Visa Application Form</div><div>2. Passport Photo</div><div>3. Hotel Bookings</div><div>4. Bank Statement</div><div>5. Travel Insurance</div><div>6. Flight Bookings</div><div>7. Previous Passport</div><div>8. Cover Letter</div><div>9. Passport</div><div>10. Current Details</div>', 1, '', '', '', NULL, NULL),
(143, 'Mongolia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Bank statement<br>6. Income tax returns<br>', 1, '', '', '', NULL, NULL),
(144, 'Montserrat', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Air ticket<br>4. Travel insurance&nbsp;<br>5. Itineanry&nbsp;', 1, '', '', '', NULL, NULL),
(145, 'Montenegro', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Travel insurance<br>6. Bank statement<br>7. Credit card<br>8. Income tax returns<br>9. Itineanry&nbsp;', 1, '', '', '', NULL, NULL),
(146, 'Morocco', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Authority letter&nbsp;<br>7. Covering letter from applicant<br>8. Bank statement<br>9. Income tax returns<br>10. Hotel voucher<br>11. Itineanry&nbsp;', 1, '', '', '', NULL, NULL),
(147, 'Mozambique', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Yellow fever vaccination&nbsp;<br>5. Old passport<br>', 1, '', '', '', NULL, NULL),
(148, 'Myanmar', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Hotel voucher<br>5. Covering letter from applicant<br>', 1, '', '', '', NULL, NULL),
(149, 'Namibia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Yellow fever vaccination&nbsp;<br>6. Covering letter from applicant<br>7. Bank statement<br>8. Income tax returns&nbsp;<br>9. Credit card<br>', 1, '', '', '', NULL, NULL),
(150, 'Nauru', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Completed Nauru visa application form.</div><div>2. A copy of your passport, valid for at least three more months beyond your intended stay in Nauru.</div><div>3. A recent passport photo with a white background.</div><div>4. A hotel reservation or sponsorship from a resident of Nauru.</div><div>5. Copies of your flight bookings to and from Nauru as well as any other Pacific islands you are visiting.</div><div>6. Criminal record certificate.</div><div>7. Certificate of medical fitness.</div><div>8. A certificate of employment/work contract.</div><div>9. A letter of invitation from a Nauruan citizen (for Australian and New Zealand passports only).</div><div>10. International Certificate of Vaccination for Yellow Fever required if arriving from infected area within 5 days.</div>', 1, '', '', '', NULL, NULL),
(151, 'Nepal', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Your nationality before getting Travel Document.</div><div>2. If you have been to Nepal as Refugee before, mention your refugee ID card Number.</div><div>3. If you are visiting Nepal to meet your relatives, please provide the following details:</div><div>4. Name of relative</div><div>5. Address of relative</div><div>6. Nationality of your relative</div><div>7. As Refugee, for how long have you been in this country (mention year and month).</div><div>8. Copy of the Travel Document.</div>', 1, '', '', '', NULL, NULL),
(152, 'Netherlands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<div>4. Air ticket<br>5. Travel insurance<br>6. Income tax returns<br>7. Itinerary<br>8. Hotel voucher<br>9. Covering letter from applicant<br>&nbsp;<br><br></div>', 1, '', '', '', NULL, NULL),
(153, 'Netherlands Antilles', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<span style=\\\"color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255);\\\">1. Passport</span><br style=\\\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255);\\\"><span style=\\\"color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255);\\\">2. Old passport</span><br style=\\\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255);\\\"><span style=\\\"color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255);\\\">3. Photo</span><div style=\\\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: 14px; background-color: rgb(255, 255, 255);\\\">4. Air ticket<br style=\\\"box-sizing: border-box;\\\">5. Travel insurance<br style=\\\"box-sizing: border-box;\\\">6. Income tax returns<br style=\\\"box-sizing: border-box;\\\">7. Itinerary<br style=\\\"box-sizing: border-box;\\\">8. Hotel voucher<br style=\\\"box-sizing: border-box;\\\">9. Covering letter from applicant<br style=\\\"box-sizing: border-box;\\\">&nbsp;</div>', 1, '', '', '', NULL, NULL),
(154, 'New Caledonia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months on entry with one blank visa page</div><div>2. Hold confirmed onward or return flight confirmation</div><div>3. Hold all documents required for the next destination</div><div>4. Hold proof of sufficient funds</div><div>5. Confirm with their airline that boarding will be permitted without a visa</div>', 1, '', '', '', NULL, NULL),
(155, 'New Zealand', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<div>3. Photo<br>4. Air ticket<br>5. Covering letter from applicant<br>6. Bank statement<br>7. Income tax returns</div><div>8. NOC letter from parents/husband</div><div>9. Itinerary<br>10. Hotel voucher&nbsp;</div>', 1, '', '', '', NULL, NULL),
(156, 'Nicaragua', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months on entry with one blank visa page</div><div>2. Hold proof of sufficient funds</div><div>3. Hold proof of onward/return flights</div><div>4. Hold all documents required for the next destination</div><div>5. Check the latest immunization requirements at: http://www.safetravel.ch/</div>', 1, '', '', '', NULL, NULL),
(157, 'Niger', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Yellow fever vaccination<br>2. Covering letter form applicant<br>3. Hotel voucher<br>4. Passport<br>5. Old passport<br>6. Photo<br>7. Air ticket<br>8. Bank statement<br>9. tineanry&nbsp;<br>', 1, '', '', '', NULL, NULL),
(158, 'Nigeria', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Yellow fever vaccination<br>6. Polio vaccination<br>7. Internal air ticket<br>8. ID proof of signatory authority person<div>9. Covering letter from applicant<br>10. Bank statement<br>11. Income tax returns<br>12. Hotel voucher&nbsp; &nbsp;</div>', 1, '', '', '', NULL, NULL),
(159, 'Niue', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months on entry with two blank visa pages</div><div>2. Hold proof of confirmed onward/return airline tickets</div><div>3. Hold proof of sufficient funds in the form of a bank statement or cash</div><div>4. Hold proof of confirmed accommodation</div><div>5. Hold documents showing proof of travel purpose (e.g., business cover or support letter, conference registrations, tour itinerary, etc.)</div><div>6. Hold all documents required for the next destination</div><div>7. Hold a visa for the next destination, if applicable</div><div>8. Confirm with their airline that boarding will be permitted without a visa as these conditions are subject to change</div>', 1, '', '', '', NULL, NULL),
(160, 'Norfolk Island', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport Requirements</div><div>2. Document Validity</div><div>3. Warnings</div><div>4. Visa Issuance</div><div>5. Visa Exemptions</div><div>6. Additional information</div><div><br></div>', 1, '', '', '', NULL, NULL),
(161, 'Northern Mariana Islands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport Requirements</div><div>2. Document Validity</div><div>3. Additional information</div><div>4. Visa Issuance</div><div>5. Additional information</div><div>6. Import regulations</div><div>7. Airport tax</div>', 1, '', '', '', NULL, NULL),
(162, 'Norway', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Covering letter from applicant<br>7. Bank statement<br>8. Income tax returns<br>9. Power of attorney<br>10. Itinerary<br>11. Hotel voucher<br>12. NOC letter from parents/husband&nbsp;', 1, '', '', '', NULL, NULL),
(163, 'Oman', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Aadhar card<br>5. Pan card<br>6. Covering letter from applicant<br>', 1, '', '', '', NULL, NULL),
(164, 'Pakistan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Visisting card&nbsp;', 1, '', '', '', NULL, NULL),
(165, 'Palau', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Air ticket<div><br></div>', 1, '', '', '', NULL, NULL),
(166, 'Palestinian Territory', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Air ticket<br>4. Itinerary&nbsp;', 1, '', '', '', NULL, NULL),
(167, 'Panama', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Covering letter of applicant<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Hotel vocuher&nbsp;<br>', 1, '', '', '', NULL, NULL),
(168, 'Papua New Guinea', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Medical reports<br>6. Itinerary<br>7. Bank statement<br>8. Income tax returns<br>9. Hotel voucher&nbsp;<br>&nbsp;', 1, '', '', '', NULL, NULL),
(169, 'Paraguay', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Police clearance certificate pcc<br>5. Old passport<br>6. Bank statement<div>7. Visa application&nbsp;<br>&nbsp;</div>', 1, '', '', '', NULL, NULL),
(170, 'Peru', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Visa application form<br>6. Bank statement<br>7. Income tax returns&nbsp;', 1, '', '', '', NULL, NULL),
(171, 'Philippines', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Credit card<br>6. Credit card statement<br>7. Covering letter from applicant<br>8. Bank statement<br>9. Forex report<br>10. Income tax returns<br>11. Itinerary<br>12. Hotel voucher&nbsp;&nbsp;', 1, '', '', '', NULL, NULL),
(172, 'Pitcairn', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid at least six months on entry with one blank visa page</div><div>2. Hold proof of sufficient funds relative to your intended length of stay</div><div><br></div>', 1, '', '', '', NULL, NULL),
(173, 'Poland', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Hotel voucher<br>10. Covering letter from applicant<br>11. NOC letter from parnts/husband&nbsp;', 1, '', '', '', NULL, NULL),
(174, 'Portugal', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Hotel voucher<br>10. Covering letter from applicant<br>11. Sponsorship letter&nbsp;<br>', 1, '', '', '', NULL, NULL),
(175, 'Puerto Rico', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>2. Digital Photograph</div><div>3. Application form</div><div>4. Appointment booking confirmation</div><div>5. Letter of Invitation</div><div>6. Business Introduction Letter</div><div>7. Proof of Financial Means</div><div>8. Proof of Residency</div>', 1, '', '', '', NULL, NULL),
(176, 'Qatar', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Pan card<br>4. Air ticket<br>5. Hotel vocuher', 1, '', '', '', NULL, NULL),
(177, 'Reunion', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Two application forms instead of one.</div><div>2. A copy of the spouse\\\'s passport if they are an EU citizen.</div><div>3. A copy of the spouse\\\'s residency permits if they are not an EU citizen</div><div>4. A original copy of the marriage certificate.</div><div>5. Proof of basic german language skill.</div><div>6. Passport copies of both parents.</div><div>7. Birth certificate.</div><div>8. Proof of adoption(If applicable).</div><div>9. Custody decree(If parents are divorced).</div><div>10. Death certificate of parents(If one of the parents has passed away).</div><div>11. Letter of consent from parents.</div>', 1, '', '', '', NULL, NULL),
(178, 'Romania', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Authority letter<br>6. Travel insurance<br>7. Wavier form<div>8. Covering letter from applicant<br>9. Bank statement&nbsp;<br>10. Income tax returns</div><div>11. Hotel voucher<br>12. Credit card<br>13. Itineanry&nbsp;<br><br></div>', 1, '', '', '', NULL, NULL),
(179, 'Russian Federation', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Authority letter<br>6. Covering letter from applicant<div>7. Hotel vocuher</div>', 1, '', '', '', NULL, NULL),
(180, 'Rwanda', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br><br>', 1, '', '', '', NULL, NULL),
(181, 'Saint Helena', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Original Passport valid for 6 months from the date of arrival.</div><div>2. Visa Application Form.</div><div>3. Covering letter mentioning details of the travel.</div><div>4. 2 photos: 35 mm X 50 mm, White background, Matt Finish, face cover 3cm Head to the chin. With a clear view of the neck and shoulders along with the white background.</div><div>5. Confirmed Air Tickets with E-ticket No.</div><div>6. Original saving bank statements for last 3 months updated with bank seal &amp; sign on each and every page showing balance more than INR 30,000 per person.</div><div>7. Confirmed Hotel Bookings.</div>', 1, '', '', '', NULL, NULL),
(182, 'Saint Kitts And Nevis', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. A valid passport with at least 6 months of validity left</div><div>2. Passport pictures from the last three months</div><div>3. Pay the application costs for the visa</div><div>4. A valid passport that will remain valid for at least 6 months after the day you leave St. Kitts and Nevis</div><div>5. Proof that you have sufficient funds to cover all of the costs associated with your trip</div><div>6. A departure voucher or ticket showing when and how you will leave St. Kitts and Nevis</div>', 1, '', '', '', NULL, NULL),
(183, 'Saint Lucia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Original Passport with at least 6 months validity and minimum 3 blank pages + all old passports if any</div><div>2. 2 Scanned recent colour photograph. (Photo Specification);</div><div>3. Visa Application forms: completed and signed</div><div>4. Personal Covering letter: explaining purpose of travel to the country</div><div>5. Original Bank Statement: stamped &amp; updated for last 3 months with bank seal</div><div>6. Air tickets: proof of return flight tickets from and back to your home country</div><div>7. Hotel reservation: proof of accommodation for your entire stay</div><div>8. Travel Itinerary: day-wise plan outlining all elements of the trip</div>', 1, '', '', '', NULL, NULL),
(184, 'Saint Pierre And Miquelon', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport must be valid for a minimum of 6 months</div><div>2. Valid ID card(if required)</div><div>3. Original birth certificate (if required)</div>', 1, '', '', '', NULL, NULL),
(185, 'Saint Vincent And The Grenadines', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. General documents</div><div>2. Birth,Death,Burial certificates</div><div>3. Marriage, Divorce certificates</div><div>4. Adoption certificates</div><div>5. Identity card</div><div>6. Police, court,prison records</div><div>7. Military records</div><div>8. Passports &amp; other travel documents</div><div>9. Other records</div><div>10. Visa issuing posts</div><div>11. Visa services</div><div><br></div>', 1, '', '', '', NULL, NULL),
(186, 'Samoa', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Original Passport with at least 6 months validity and minimum 3 blank pages + all old passports if any</div><div>2. 2 Scanned recent colour photograph. (Photo Specification);</div><div>3. Confirmed return flight ticket</div><div>4. Accommodation proof (hotel booking or invitation letter if visiting relative/friend)</div><div>5. Sufficient financial funds (while in Samoa)</div><div>6. Supporting documents relating to Business trip</div>', 1, '', '', '', NULL, NULL),
(187, 'San Marino', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid for at least six months beyond your date of country exit and with one blank visa page</div><div>2. Hold proof of onward and return flights</div><div>3. Hold all documents required for the next destination</div><div>4. Hold documents showing proof of travel purpose (e.g. business cover or support letter, conference registrations, etc.)</div><div>5. Hold proof of sufficient funds relative to your intended length of stay</div><div>6. It is recommended that you confirm with your airline that boarding will be permitted without a visa</div>', 1, '', '', '', NULL, NULL),
(188, 'Sao Tome And Principe', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a biometric passport valid for at least six months with at least one blank visa page</div><div>2. Hold proof of onward and return flights</div><div>3. Hold all documents required for the next destination</div><div>4. Hold proof of sufficient funds relative to your intended length of stay</div><div>5. Confirm with your airline prior to your travel date that boarding will be permitted without a visa</div>', 1, '', '', '', NULL, NULL),
(189, 'Saudi Arabia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<div>5. Travel insurance&nbsp;<br>6. Covering letter from applicant<br>7. Hotel voucher<br>8. Bank statement<br>9. Bonafide letter&nbsp;</div>', 1, '', '', '', NULL, NULL),
(190, 'Senegal', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br><div>4. Air ticket<br>5. Bank statement</div><div>6. Hotel vocuher</div>', 1, '', '', '', NULL, NULL),
(191, 'Serbia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br><div>2. Old passport<br>3. Photo</div><div>4. Air ticket<br>5. Income tax returns<br>6. Travel insurance<br>7. Covering letter of applicants<br>8. Bank statements<br>9. Itinerary<br>10. Hotel vocuher&nbsp;&nbsp;</div>', 1, '', '', '', NULL, NULL),
(192, 'Seychelles', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Air ticket<br>3. Bank statement<div><br><br><br></div>', 1, '', '', '', NULL, NULL),
(193, 'Sierra Leone', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport</div><div>&nbsp; 1.1. With 6 months validity</div><div>&nbsp; 1.2. Must be original and signed</div><div>&nbsp; 1.3. With a blank page for entry stamp</div><div>2. Photographs</div><div>&nbsp; 2.1. 2*2 inches</div><div>&nbsp; 2.2. Must be in color with front view and a plain background</div><div>3. Proof of travel</div><div>&nbsp; 3.1 Requires a copy of your flight itinerary</div><div>&nbsp; 3.2 A copy of your airline ticket showing entry and exit from sierra leone&nbsp;&nbsp;</div>', 1, '', '', '', NULL, NULL),
(194, 'Singapore', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Covering letter from applicant&nbsp;<br>5. Bank statement<br>6. Hotel vocuher<br>', 1, '', '', '', NULL, NULL),
(195, 'Slovakia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<div>7. Income tax returns<br>8. Itinerary<br>9. Hotel voucher<br>10. Covering letter from applicant</div><div>11. Sponsorship letter<br>12. NOC letter from parents to child</div>', 1, '', '', '', NULL, NULL),
(196, 'Slovenia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Hotel voucher<br>10. Visa application form<br>11. Covering letter from applicant<div>12. NOC letter from parents to child</div><div>13. Marriage certificate&nbsp;</div>', 1, '', '', '', NULL, NULL),
(197, 'Solomon Islands', 'Tourist Visa', '0.00', '0.00', '30 Days ', '', '', '1. Passport<br>2. Photo<br>3. Bank statement<br>4. Air ticket<br>5. Itinerary&nbsp;<br>6. Hotel vocuher&nbsp;', 1, '', '', '', NULL, NULL),
(198, 'Somalia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>', 1, '', '', '', NULL, NULL),
(199, 'South Africa', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<div>3. Photo<br>4. Air ticket<br>5. Yellow fever vaccination&nbsp;<br>6. Visa application form<br>7. Covering letter from applicant<br>8. Bank statement<br>9. Hotel voucher<br>10. NOC letter&nbsp; from parents to child&nbsp;<br>11. Relationship proof<br>12. Itinenary&nbsp;</div>', 1, '', '', '', NULL, NULL),
(200, 'South Georgia And The South Sandwich Islands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Visa application form</div><div>2. Passport photo</div><div>3. Passport</div><div>4. Previous passport</div><div>5. Residency proof</div><div>6. Proof of funds&nbsp;</div><div>7. Current details</div><div>8. Travel Itinerary</div><div>9. Hotel bookings</div><div><br></div>', 1, '', '', '', NULL, NULL),
(201, 'Spain', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Hotel voucher<br>10. Covering letter from applicant<br>11. Copies of all pages of passport<br>12. NOC letter from parents to child&nbsp;<br>13. Marriage certificate&nbsp;', 1, '', '', '', NULL, NULL),
(202, 'Sri Lanka', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Air ticket&nbsp;', 1, '', '', '', NULL, NULL),
(203, 'Sudan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Medical report&nbsp;', 1, '', '', '', NULL, NULL),
(204, 'Suriname', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Yellow fever vaccination<div>7. Medical report<br>8. Bank statement</div>', 1, '', '', '', NULL, NULL);
INSERT INTO `visa_crm_master` (`entry_id`, `country_id`, `visa_type`, `fees`, `markup`, `time_taken`, `upload_url`, `upload_url2`, `list_of_documents`, `status`, `upload_url3`, `upload_url4`, `upload_url5`, `fees_b2b`, `markup_b2b`) VALUES
(205, 'Svalbard And Jan Mayen', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Cover letter from the Application Portal, signed by the applicant. If the applicant is a minor, the</div><div>cover letter must be signed by the parent(s) or legal guardian.</div><div>2. One (1) passport photo, not older than six (6) months, in color with a light background, 35 â€“ 40 mm</div><div>in width.</div><div>3. Passport (both new and old), valid at least three (3) months after the intended date of departure from</div><div>the Schengen area, containing at least two blank pages, and issued within the previous 10 years.</div><div>4. Copy of passport(s) (all used pages including the bio data page)</div><div>5. Original invitation letter dated and signed by the inviter/sponsor in Svalbard/ Spitsbergen, stating</div><div>the purpose and duration of the visit, the relation with the applicant and any other information about</div><div>the applicants visit (not older than three (3) months).</div><div>6. Original Guarantee Form for Visits filled out by the inviter/sponsor in Svalbard and stamped by</div><div>Norwegian authorities + 1 copy (if the applicant does not have sufficient financial means to cover the</div><div>cost of travel).</div><div>7. Copy of inviter/sponsor passport</div><div>8. A valid travel medical insurance for the duration of the intended stay in the Schengen area with a</div><div>minimum coverage of EURO 30.000</div><div>9. Flight booking of roundtrip air ticket to Svalbard (Longyearbyen), and other travels within the</div><div>Schengen area, if applicable. Do not purchase the ticket until a visa has been granted.</div><div>10. Minors (under 18 years of age):</div><div>- student card and/or original letter from the school, mentioning:</div><div>o full address, telephone number(s) of the school</div><div>o name and function of the person giving permission</div><div>o approval for leave of absence</div><div>- Proof of relationship or guardianship.</div><div>- When applicant is travelling alone, or only with one parent: letter of permission to travel signed</div><div>by both parents or legal guardians, and copy of the passport of the parent not travelling.</div><div>11. Letter granting Power of Attorney (optional for applicants who want the sponsor or other person to</div><div>represent them in the case).</div><div>12. If applicable, a written explanation as to why the applicant cannot present any or some of the</div><div>documents</div>', 1, '', '', '', NULL, NULL),
(206, 'Swaziland', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport requirements</div><div>2. Proof of travel arrangements</div><div>3. Special instructions</div>', 1, '', '', '', NULL, NULL),
(207, 'Sweden', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Relationship proof<br>10. Covering letter from applicants<br>11. Hotel vocuher', 1, '', '', '', NULL, NULL),
(208, 'Switzerland', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Travel insurance<br>6. Bank statement<br>7. Income tax returns<br>8. Itinerary<br>9. Hotel voucher<br>10. Covering letter from applicant&nbsp;', 1, '', '', '', NULL, NULL),
(209, 'Syrian Arab Republic', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Guarantee letter&nbsp;<br>5. Old passport', 1, '', '', '', NULL, NULL),
(210, 'Taiwan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Covering letter from applicant<br>6. Bank statement<br>7. Income tax returns<br>8. Itinenry&nbsp;', 1, '', '', '', NULL, NULL),
(211, 'Tajikistan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Air ticket<br>3. Photo<br>', 1, '', '', '', NULL, NULL),
(212, 'Tanzania', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br><div>2. Photo<br>3. Air ticket<br>4. Yellow fever vaccination<br>5. Covering letter from applicant</div><div>6. Bank statement<br>7. Itinerary&nbsp;</div>', 1, '', '', '', NULL, NULL),
(213, 'Thailand', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Bank statement<br>5. Covering letter from applicant<br>6. Hotel voucher<br>&nbsp;', 1, '', '', '', NULL, NULL),
(214, 'Togo', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Your passport, with a validity of at least another six months from the end of your stay and at least two blank pages.</div><div>2. Photocopies of the first two pages of your passport.</div><div>3. The Togo visa application form</div><div>4. Two recent passport-size pictures, with the following requirements:</div><div>5. Dimensions: 4.5 x 3.5 cm</div><div>6. White background</div><div>7. Neutral facial expression</div><div>8. Your face and head must be fully visible (headgear only accepted for religious purposes, provided it does not obstruct the face)</div><div>9. Proof you have purchased or booked a return flight ticket.</div><div>10. Travel insurance for the duration of your stay, or proof you have paid a repatriation deposit</div><div>11. Yellow Fever Certificate or the vaccination notebook</div><div>12. Proof of accommodation in Togo, such as a hotel reservation</div>', 1, '', '', '', NULL, NULL),
(215, 'Tokelau', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport validity</div><div>2. Blank visa pages</div><div>3. Tokelau visa application form</div><div>4. Original, signed United State passport</div><div>5. (2) passport photographs</div><div>6. An itinerary of your trip</div><div>7. Proof of yellow fever vaccine</div><div><br></div>', 1, '', '', '', NULL, NULL),
(216, 'Tonga', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Passport with minimum six months validity beyond intended stay and with two blank pages</div><div>2. 2 Scanned recent colour photograph. (Photo Specification);</div><div>3. Confirmed return flight ticket</div><div>4. Hotel Reservation or Invitation letter (If visiting family or friends)</div><div>5. Updated bank statement of last three months</div><div>6. Invitation letter from the host company (For Business Visa)</div><div>7. Birth Certificate for children</div><div>8. Enough funds to support the entire trip to Tanzania</div>', 1, '', '', '', NULL, NULL),
(217, 'Trinidad And Tobago', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a Machine Readable passport valid at least six months on entry with one blank visa page</div><div>2. Hold proof of sufficient funds in the form of a bank statement or cash</div><div>3. Hold proof of onward/return airline tickets</div><div>4. Hold documents showing proof of purpose of trip</div><div>5. Hold all documents required for the next destination</div><div>6. Hold a visa for the next destination, if required</div><div>7. Confirm with their airline that boarding will be permitted without a visa as these conditions are subject to change</div>', 1, '', '', '', NULL, NULL),
(218, 'Tunisia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>', 1, '', '', '', NULL, NULL),
(219, 'Turkey', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Travel insurance</div><div>6. Income tax returns<br>7. Covering letter from applicants<br>8. Bank statements<br>9. Hotel vocuher&nbsp;</div>', 1, '', '', '', NULL, NULL),
(220, 'Turkmenistan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Bank statement<div><br></div>', 1, '', '', '', NULL, NULL),
(221, 'Turks And Caicos Islands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid for at least six months beyond your date of country exit and with one blank visa page</div><div>2. Hold proof of onward and return flights</div><div>3. Hold all documents required for the next destination</div><div>4. Hold documents showing proof of travel purpose (e.g. business cover or support letter, conference registrations, etc.)</div><div>5. Hold proof of sufficient funds relative to your intended length of stay</div><div>6. It is recommended that you confirm with your airline that boarding will be permitted without a visa</div>', 1, '', '', '', NULL, NULL),
(222, 'Tuvalu', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photos<br>3. Air ticket', 1, '', '', '', NULL, NULL),
(223, 'Uganda', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br><div>2. Photo<br>3. Air ticket</div>', 1, '', '', '', NULL, NULL),
(224, 'Ukraine', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket<br>4. Old passport<br>5. Travel insurance&nbsp;<br>6. Bank statement<br>7. Income tax returns<br>8. Itineanry&nbsp;&nbsp;', 1, '', '', '', NULL, NULL),
(225, 'United Arab Emirates', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<font face=\\\"\\\\\\\\\\\\trebuchet\\\\\\\">1. Passport<br>2. Photo<br>3. Air ticket<br>4. Pan card<br>5. Profession proof</font>', 1, '', '', '', NULL, NULL),
(226, 'United Kingdom', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<div>4. Air ticket<br>5. Covering letter from applicant<br>6. Bank statement&nbsp;</div><div>7. Income tax returns<br>8. Itinerary<br>9. Hotel vocuher&nbsp;<br><br></div>', 1, '', '', '', NULL, NULL),
(227, 'United States', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Old passport<br>3. Photo<br>4. Bank statement</div><div>5. Income tax returns<br>6. Itineanry&nbsp;</div>', 1, '', '', '', NULL, NULL),
(228, 'Uruguay', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Credit card</div><div>6. Medical report<br>7. Bank statement</div><div>8. Income tax returns&nbsp;<br>9. Itinerary&nbsp;</div>', 1, '', '', '', NULL, NULL),
(229, 'Uzbekistan', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Photo<br>3. Air ticket<br>4. Hotel voucher</div>', 1, '', '', '', NULL, NULL),
(230, 'Vanuatu', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Photo<br>3. Air ticket<br>4. Hotel vocuher</div>', 1, '', '', '', NULL, NULL),
(231, 'Venezuela', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Medical report<br>6. Bank statement&nbsp;', 1, '', '', '', NULL, NULL),
(232, 'Vietnam', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Photo<br>3. Air ticket<br><br></div>', 1, '', '', '', NULL, NULL),
(233, 'Virgin Islands', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Hold a passport valid for at least six months beyond your date of country exit and with one blank visa page</div><div>2. Hold proof of onward and return flights</div><div>3. Hold all documents required for the next destination</div><div>4. Hold documents showing proof of travel purpose (e.g. business cover or support letter, conference registrations, etc.)</div><div>5. Hold proof of sufficient funds relative to your intended length of stay</div><div>6. It is recommended that you confirm with your airline that boarding will be permitted without a visa</div>', 1, '', '', '', NULL, NULL),
(234, 'Wallis And Futuna', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Original passport with at least 6-month validity.</div><div>2. A scanned copy of passport bio page.</div><div>3. Online visa application forms.</div><div>4. 2 Recent passport-size photos: 35 X 45 mm, white background Matt finish, 80% face size.</div><div>5. Return ticket.</div><div>6. Previous Yemen visa - if applicable.</div><div>7. Original saving bank statements last 6 months updated with a healthy balance.</div><div>8. Enough blank pages in your passport to fit the required entry visa.</div><div>9. Bank Statement.&nbsp; Copies of bank statements from the past 3 months.</div><div>10. Confirmation of round-trip airline ticket or airline ticket to another destination.</div><div>11. Medical travel insurance (Schengen). with a minimum coverage of â‚¬30,000 and validity for all Schengen states.</div><div>12. Employment Letter. A letter from your employer/school (on business letterhead, with contact details), stating that a leave of absence has been granted and that you will be returning to your current job. If you are self-employed, include a copy of your business license and tax return. If you are retired please submit proof of your retirement fund.</div><div>13. Pay Stubs. Copies of 3 most recent pay stubs.</div><div>14. Hotel Reservations. Copy of the Hotel Reservations.</div><div>15. Personal Invitation. If visiting friends or family, you must provide letter of invitation with the contact information of the host and visitor,&nbsp;</div><div>purpose and duration of the visit, confirmation of accommodation including the address, signature and date.&nbsp;</div><div>You will also need to provide proof of the host\\\'s status in Wallis Futuna Islands ie.&nbsp;</div><div>copy of their Wallis Futuna Islands passport\\\'s information page, or, if they are not a citizen of Wallis Futuna Islands,&nbsp;</div><div>copies of their Wallis Futuna Islands residence permit and their national passport\\\'s information pages.</div>', 1, '', '', '', NULL, NULL),
(235, 'Western Sahara', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '<div>1. Visa Application Form</div><div>2. Passport Photo</div><div>3. Passport</div><div>4. Passport Copy</div><div>5. Residency Proof</div><div>6. Hotel Bookings(Hotel Itinerary)</div><div>7. Flight Bookings</div><div>8. Travel Insurance</div><div>9. Current Details</div><div>10. Invitation Letter</div><div><br></div>', 1, '', '', '', NULL, NULL),
(236, 'Yemen', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Old passport<br>3. Photo<br>4. Air ticket<br>5. Approval from ministry&nbsp;', 1, '', '', '', NULL, NULL),
(237, 'Zambia', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<div>2. Photo<br>3. Air ticket<br>4. Yellow fever vaccination</div>', 1, '', '', '', NULL, NULL),
(238, 'Zimbabwe', 'Tourist Visa', '0.00', '0.00', '30 Days', '', '', '1. Passport<br>2. Photo<br>3. Air ticket', 1, '', '', '', NULL, NULL),
(239, 'Algeria', 'Student Visa', '3000.00', '400.00', '2days', '../../uploads//Visa_document_required//2022//Jan//28//1643362222/cache_data.txt', '../../uploads//Visa_document_required//2022//Jan//28//1643362178/Way Explorers_Package&amp;Group tourQuotation.pdf', 'dghd', 1, '', '', '', NULL, NULL),
(240, 'Afghanistan', 'Multi-Entry Long Term Visa: 90 Days', '3000.00', '200.00', '3days', '../../uploads//Visa_document_required//2023//Feb//08//1675856789/text1.txt', '../../uploads//Visa_document_required//2023//Feb//08//1675856793/text2.txt', 'ok', 1, '../../uploads//Visa_document_required//2023//Feb//08//1675856797/text3.txt', '../../uploads//Visa_document_required//2023//Feb//08//1675856800/text4.txt', '../../uploads//Visa_document_required//2023//Feb//08//1675856804/text5.txt', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `visa_master`
--

CREATE TABLE `visa_master` (
  `visa_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `visa_issue_amount` decimal(50,2) NOT NULL,
  `service_charge` decimal(50,2) NOT NULL,
  `service_tax_subtotal` varchar(500) NOT NULL,
  `due_date` date NOT NULL,
  `visa_total_cost` decimal(50,2) NOT NULL,
  `cancel_amount` decimal(50,2) NOT NULL,
  `total_refund_amount` decimal(50,2) NOT NULL,
  `markup` decimal(50,2) NOT NULL,
  `markup_tax` varchar(500) NOT NULL,
  `reflections` text NOT NULL,
  `roundoff` varchar(10) NOT NULL,
  `created_at` date NOT NULL,
  `emp_id` int(11) NOT NULL,
  `service_show` decimal(50,2) NOT NULL,
  `markup_show` decimal(50,2) NOT NULL,
  `bsm_values` text NOT NULL,
  `currency_code` int(11) NOT NULL,
  `invoice_pr_id` int(11) NOT NULL,
  `cancel_flag` int(11) NOT NULL,
  `delete_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `visa_master`
--

INSERT INTO `visa_master` (`visa_id`, `customer_id`, `branch_admin_id`, `financial_year_id`, `visa_issue_amount`, `service_charge`, `service_tax_subtotal`, `due_date`, `visa_total_cost`, `cancel_amount`, `total_refund_amount`, `markup`, `markup_tax`, `reflections`, `roundoff`, `created_at`, `emp_id`, `service_show`, `markup_show`, `bsm_values`, `currency_code`, `invoice_pr_id`, `cancel_flag`, `delete_status`) VALUES
(1, 4, 1, 1, '7000.00', '670.00', 'IGST:(5.00%):33.50', '2023-02-15', '7704.00', '0.00', '0.00', '0.00', '', '[{\"hotel_sc\":\"\",\"hotel_markup\":\"\",\"hotel_taxes\":\"67\",\"hotel_markup_taxes\":\"\",\"hotel_tds\":\"\",\"tax_apply_on\":\"2\",\"tax_value\":\"IGST:(5.00%):(67)\",\"markup_tax_value\":\"\"}]', '0.50', '2023-02-15', 1, '0.00', '0.00', '[{\"basic\":\"\",\"service\":\"\",\"markup\":\"\"}]', 68, 1, 0, 0),
(2, 5, 1, 1, '5000.00', '0.00', 'CGST:(2.50%):125.00, SGST:(2.50%):125.00', '2023-03-01', '5355.00', '0.00', '0.00', '100.00', 'CGST:(2.50%):2.50, SGST:(2.50%):2.50', '[{\"hotel_sc\":\"\",\"hotel_markup\":\"\",\"hotel_taxes\":\"\",\"hotel_markup_taxes\":\"\",\"hotel_tds\":\"\",\"tax_apply_on\":\"1\",\"tax_value\":\"CGST:(2.50%):(21)+SGST:(2.50%):(119)\",\"markup_tax_value\":\"CGST:(2.50%):(21)+SGST:(2.50%):(119)\"}]', '0.00 ', '2023-03-01', 1, '0.00', '0.00', '[{\"basic\":\"\",\"service\":\"\",\"markup\":\"\"}]', 68, 2, 0, 0),
(3, 5, 1, 1, '350000.00', '0.00', 'CGST:(2.50%):8750.00, SGST:(2.50%):8750.00', '2023-03-03', '367503.00', '0.00', '0.00', '3.00', 'IGST:(5.00%):0.15', '[{\"hotel_sc\":\"\",\"hotel_markup\":\"\",\"hotel_taxes\":\"\",\"hotel_markup_taxes\":\"\",\"hotel_tds\":\"\",\"tax_apply_on\":\"1\",\"tax_value\":\"CGST:(2.50%):(21)+SGST:(2.50%):(119)\",\"markup_tax_value\":\"IGST:(5.00%):(67)\"}]', '-0.15     ', '2023-03-03', 1, '0.00', '0.00', '[{\"basic\":\"\",\"service\":\"\",\"markup\":\"\"}]', 68, 3, 0, 0),
(4, 5, 1, 1, '1000.00', '0.00', 'CGST:(2.50%):25.00, SGST:(2.50%):25.00', '2023-03-07', '1050.00', '0.00', '0.00', '0.00', 'CGST:(2.50%):0.00, SGST:(2.50%):0.00', '[{\"hotel_sc\":\"\",\"hotel_markup\":\"\",\"hotel_taxes\":\"21, 119\",\"hotel_markup_taxes\":\"21, 119\",\"hotel_tds\":\"\",\"tax_apply_on\":\"1\",\"tax_value\":\"CGST:(2.50%):(21)+SGST:(2.50%):(119)\",\"markup_tax_value\":\"CGST:(2.50%):(21)+SGST:(2.50%):(119)\"}]', '0.00', '2023-03-07', 1, '0.00', '0.00', '[{\"basic\":\"\",\"service\":\"\",\"markup\":\"\"}]', 68, 4, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `visa_master_entries`
--

CREATE TABLE `visa_master_entries` (
  `entry_id` int(11) NOT NULL,
  `visa_id` int(11) NOT NULL,
  `honorific` varchar(100) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `birth_date` date NOT NULL,
  `adolescence` varchar(100) NOT NULL,
  `visa_country_name` varchar(200) NOT NULL,
  `visa_type` varchar(200) NOT NULL,
  `passport_id` varchar(200) NOT NULL,
  `issue_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `nationality` varchar(200) NOT NULL,
  `received_documents` text NOT NULL,
  `status` varchar(100) NOT NULL,
  `appointment_date` date NOT NULL,
  `passport_no` varchar(300) NOT NULL,
  `passport_issue_date` date NOT NULL,
  `passport_expiry_date` date NOT NULL,
  `id_proof_url` text NOT NULL,
  `pan_card_url` text NOT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `start_date` varchar(100) DEFAULT NULL,
  `end_date` varchar(100) DEFAULT NULL,
  `pass_status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `visa_master_entries`
--

INSERT INTO `visa_master_entries` (`entry_id`, `visa_id`, `honorific`, `first_name`, `middle_name`, `last_name`, `birth_date`, `adolescence`, `visa_country_name`, `visa_type`, `passport_id`, `issue_date`, `expiry_date`, `nationality`, `received_documents`, `status`, `appointment_date`, `passport_no`, `passport_issue_date`, `passport_expiry_date`, `id_proof_url`, `pan_card_url`, `mother_name`, `father_name`, `start_date`, `end_date`, `pass_status`) VALUES
(1, 1, '', 'Pushkraj', '', 'Travobi', '1990-02-08', 'Adult', 'Albania', 'Transit Visa', '67877', '2023-01-30', '2023-03-02', 'hjh', '', '', '2023-02-15', '', '0000-00-00', '0000-00-00', '', '', NULL, NULL, NULL, '2023-3-10', 'Cancelled'),
(2, 2, '', 'nikhil', 'r', 'inani', '2023-03-07', 'Adult', 'India', 'Tourist Visa', '1554566', '2023-01-03', '2023-06-30', 'INDIA', '', '', '2023-03-01', '', '0000-00-00', '0000-00-00', '../../uploads//Visa_field//2023//Mar//07//1678182393/pdf-sample.pdf', '', 'r', 'r', NULL, '2023-3-10', 'Completed'),
(3, 2, '', 'shubham', 's', 'patil', '2023-03-08', 'Adult', 'India', 'Tourist Visa', '121212', '2022-10-01', '2023-04-01', 'INR', '', '', '2023-03-02', '', '0000-00-00', '0000-00-00', '../../uploads//Visa_field//2023//Mar//03//1677816046/Yellow_&_Black_Modern_We_Are_Hiring_Instagram_Post.jpg', '', 'j', 'j', NULL, '2023-3-10', 'Unused'),
(4, 3, '', 'Rohini', '', 'Gurunath', '2000-02-28', 'Adult', 'Afghanistan', 'Tourist Visa', '12212', '2023-03-02', '2023-03-07', 'INR', '', '', '2023-03-03', '', '0000-00-00', '0000-00-00', '', '', NULL, NULL, '04-03-2022', '08-03-2023', 'Unused'),
(5, 3, '', 'nikhil', 'r', 'inani', '2000-03-02', 'Adult', 'Afghanistan', 'Tourist Visa', '654321', '2023-03-02', '2023-04-05', 'IND', '', '', '2023-03-03', '', '0000-00-00', '0000-00-00', '', '', NULL, NULL, '04-03-2023', '08-03-2023', 'Unused'),
(6, 4, '', 'Rohini', '', 'Gurunath', '2023-03-10', 'Adult', 'India', 'Tourist Visa', 'rtty654321', '2023-03-09', '2023-03-10', 'INDIA', '', '', '2023-03-07', '', '0000-00-00', '0000-00-00', '', '', '', '', '07-03-2023', '30-03-2023', 'Unused');

-- --------------------------------------------------------

--
-- Table structure for table `visa_payment_master`
--

CREATE TABLE `visa_payment_master` (
  `payment_id` int(11) NOT NULL,
  `visa_id` int(11) NOT NULL,
  `branch_admin_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(50,2) NOT NULL,
  `payment_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(400) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `credit_charges` decimal(50,2) NOT NULL,
  `credit_card_details` varchar(200) NOT NULL,
  `status` varchar(10) NOT NULL,
  `delete_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `visa_payment_master`
--

INSERT INTO `visa_payment_master` (`payment_id`, `visa_id`, `branch_admin_id`, `financial_year_id`, `payment_date`, `payment_amount`, `payment_mode`, `bank_name`, `transaction_id`, `bank_id`, `clearance_status`, `credit_charges`, `credit_card_details`, `status`, `delete_status`) VALUES
(1, 1, 1, 1, '2023-02-15', '0.00', '', '', '', 0, '', '0.00', '', '', 0),
(2, 2, 1, 1, '2023-03-01', '100.00', 'Cash', '', '', 0, '', '0.00', '', '', 0),
(3, 3, 1, 1, '2023-03-03', '0.00', '', '', '', 0, '', '0.00', '', '', 0),
(4, 4, 1, 1, '2023-03-07', '0.00', '', '', '', 0, '', '0.00', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `visa_refund_entries`
--

CREATE TABLE `visa_refund_entries` (
  `id` int(11) NOT NULL,
  `refund_id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `visa_refund_master`
--

CREATE TABLE `visa_refund_master` (
  `refund_id` int(11) NOT NULL,
  `visa_id` int(11) NOT NULL,
  `financial_year_id` int(11) NOT NULL,
  `refund_amount` decimal(50,2) NOT NULL,
  `refund_date` date NOT NULL,
  `refund_mode` varchar(200) NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `transaction_id` varchar(300) NOT NULL,
  `clearance_status` varchar(100) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `visa_status_entries`
--

CREATE TABLE `visa_status_entries` (
  `id` int(11) NOT NULL,
  `booking_type` varchar(300) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `doc_status` varchar(300) NOT NULL,
  `traveler_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `visa_type_master`
--

CREATE TABLE `visa_type_master` (
  `visa_type_id` int(11) NOT NULL,
  `visa_type` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `visa_type_master`
--

INSERT INTO `visa_type_master` (`visa_type_id`, `visa_type`) VALUES
(1, 'Tourist Visa'),
(2, 'Business Visa'),
(3, 'Student Visa'),
(4, 'Exchange visitor Visa'),
(5, 'Transit Visa'),
(6, '30 Days Tourist Visa'),
(7, '96 Hour Transit Visa'),
(8, '90 Day Visit Visa'),
(9, 'Single Entry Long Term Visa: 90 Days'),
(10, 'Multi-Entry Long Term Visa: 90 Days'),
(11, 'Multi-Entry Short Term Visa: 30 Days');

-- --------------------------------------------------------

--
-- Table structure for table `visa_vendor`
--

CREATE TABLE `visa_vendor` (
  `vendor_id` int(11) NOT NULL,
  `vendor_name` varchar(300) NOT NULL,
  `email_id` text NOT NULL,
  `contact_person_name` varchar(200) NOT NULL,
  `immergency_contact_no` varchar(200) NOT NULL,
  `mobile_no` text NOT NULL,
  `landline_no` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `website` varchar(200) NOT NULL,
  `opening_balance` decimal(50,2) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `active_flag` varchar(100) NOT NULL,
  `service_tax_no` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `city_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `side` varchar(6) NOT NULL,
  `pan_no` varchar(200) NOT NULL,
  `as_of_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `visa_vendor`
--

INSERT INTO `visa_vendor` (`vendor_id`, `vendor_name`, `email_id`, `contact_person_name`, `immergency_contact_no`, `mobile_no`, `landline_no`, `address`, `website`, `opening_balance`, `bank_name`, `account_name`, `account_no`, `branch`, `ifsc_code`, `active_flag`, `service_tax_no`, `created_at`, `city_id`, `state_id`, `side`, `pan_no`, `as_of_date`) VALUES
(1, 'Visa Wale.com', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '+nLvKkvdP4jqlQ==', '', '', '', '0.00', '', '', '', '', '', 'Active', '', '2023-02-13 18:58:00', 1311, 22, 'Credit', '', '2023-02-13'),
(2, 'BTW Visa', 'szC3cRKBfNO007VIPWMauvvVUs3YeSY=', '', '', '+nLvKkvdP4jqlQ==', '', '', '', '0.00', '', '', '', '', '', 'Active', '', '2023-02-13 18:59:00', 1311, 22, 'Credit', '', '2023-02-13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sms_email_id`
--
ALTER TABLE `sms_email_id`
  ADD PRIMARY KEY (`email_id_id`);

--
-- Indexes for table `sms_group_entries`
--
ALTER TABLE `sms_group_entries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms_mobile_no`
--
ALTER TABLE `sms_mobile_no`
  ADD PRIMARY KEY (`mobile_no_id`);

--
-- Indexes for table `subgroup_master`
--
ALTER TABLE `subgroup_master`
  ADD PRIMARY KEY (`subgroup_id`);

--
-- Indexes for table `supplier_packages`
--
ALTER TABLE `supplier_packages`
  ADD PRIMARY KEY (`package_id`);

--
-- Indexes for table `tasks_master`
--
ALTER TABLE `tasks_master`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `tax_master`
--
ALTER TABLE `tax_master`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `tax_master_rules`
--
ALTER TABLE `tax_master_rules`
  ADD PRIMARY KEY (`rule_id`);

--
-- Indexes for table `tcs_master`
--
ALTER TABLE `tcs_master`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `terms_and_conditions`
--
ALTER TABLE `terms_and_conditions`
  ADD PRIMARY KEY (`terms_and_conditions_id`);

--
-- Indexes for table `ticket_master`
--
ALTER TABLE `ticket_master`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `ticket_master_entries`
--
ALTER TABLE `ticket_master_entries`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `ticket_master_entries_airfile`
--
ALTER TABLE `ticket_master_entries_airfile`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `ticket_payment_master`
--
ALTER TABLE `ticket_payment_master`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `ticket_trip_entries`
--
ALTER TABLE `ticket_trip_entries`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `tourwise_traveler_details`
--
ALTER TABLE `tourwise_traveler_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_groups`
--
ALTER TABLE `tour_groups`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `tour_master`
--
ALTER TABLE `tour_master`
  ADD PRIMARY KEY (`tour_id`);

--
-- Indexes for table `train_ticket_master`
--
ALTER TABLE `train_ticket_master`
  ADD PRIMARY KEY (`train_ticket_id`);

--
-- Indexes for table `train_ticket_master_entries`
--
ALTER TABLE `train_ticket_master_entries`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `train_ticket_payment_master`
--
ALTER TABLE `train_ticket_payment_master`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `travelers_details`
--
ALTER TABLE `travelers_details`
  ADD PRIMARY KEY (`traveler_id`);

--
-- Indexes for table `user_assigned_roles`
--
ALTER TABLE `user_assigned_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor_estimate`
--
ALTER TABLE `vendor_estimate`
  ADD PRIMARY KEY (`estimate_id`);

--
-- Indexes for table `vendor_payment_master`
--
ALTER TABLE `vendor_payment_master`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `vendor_reply_master`
--
ALTER TABLE `vendor_reply_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor_request_master`
--
ALTER TABLE `vendor_request_master`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `vendor_type_master`
--
ALTER TABLE `vendor_type_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video_itinerary_master`
--
ALTER TABLE `video_itinerary_master`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `visa_crm_master`
--
ALTER TABLE `visa_crm_master`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `visa_master`
--
ALTER TABLE `visa_master`
  ADD PRIMARY KEY (`visa_id`);

--
-- Indexes for table `visa_master_entries`
--
ALTER TABLE `visa_master_entries`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `visa_payment_master`
--
ALTER TABLE `visa_payment_master`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `visa_type_master`
--
ALTER TABLE `visa_type_master`
  ADD PRIMARY KEY (`visa_type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
