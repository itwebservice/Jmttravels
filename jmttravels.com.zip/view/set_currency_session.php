<?php
include '../crm/model/model.php';
$_SESSION['session_currency_id'] = $_POST['currency_id'];
?>           
